/* =========================================================
   background.js — Jobrow service worker
   Applications stay in chrome.storage. Export and import
   move them to a spreadsheet file and back.
   ========================================================= */

"use strict";

const CSV_HEADERS = [
    "Date Applied",
    "Company",
    "Role",
    "Job link",
    "Where",
    "Your price",
    "Resume",
    "Status",
    "Notes",
];

chrome.runtime.onInstalled.addListener((details) => {
    ensureAlarm();
    if (details.reason === "install") {
        chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
    }
    refreshBadge();
});

chrome.runtime.onStartup.addListener(() => {
    ensureAlarm();
    refreshBadge();
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "jobrow-followup") refreshBadge();
});

function ensureAlarm() {
    chrome.alarms.create("jobrow-followup", { periodInMinutes: 360 });
}

let promptWindowId = null;

chrome.windows.onRemoved.addListener((windowId) => {
    if (windowId === promptWindowId) promptWindowId = null;
});

async function promptSave(data) {
    await chrome.storage.session.set({
        pendingDraft: {
            jobTitle: data.jobTitle || "",
            companyName: data.companyName || "",
            salary: data.salary || "",
            location: data.location || "",
            url: data.url || "",
            offeredAt: Date.now(),
        },
    });

    if (promptWindowId != null) {
        try {
            await chrome.windows.update(promptWindowId, { focused: true });
            chrome.runtime.sendMessage({ action: "draftReady" }).catch(() => {});
            return { ok: true };
        } catch {
            promptWindowId = null;
        }
    }

    const created = await chrome.windows.create({
        url: chrome.runtime.getURL("popup.html?preview=1"),
        type: "popup",
        width: 440,
        height: 700,
        focused: true,
    });
    promptWindowId = created.id;
    return { ok: true };
}

chrome.action.onClicked.addListener((tab) => {
    if (tab.url && (tab.url.startsWith("http://") || tab.url.startsWith("https://"))) {
        chrome.scripting.executeScript(
            { target: { tabId: tab.id }, files: ["content_script.js"] },
            () => {
                if (chrome.runtime.lastError) {
                    console.warn("Could not inject:", chrome.runtime.lastError.message);
                } else {
                    chrome.tabs.sendMessage(tab.id, { action: "toggleJobTracker" });
                }
            }
        );
    }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const reply = (promise) => {
        promise
            .then((result) => sendResponse(result))
            .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
        return true;
    };

    if (message.action === "ensureContentScript") {
        chrome.scripting.executeScript(
            { target: { tabId: message.tabId }, files: ["content_script.js"] },
            () => {
                sendResponse({ injected: !chrome.runtime.lastError });
            }
        );
        return true;
    }

    if (message.action === "promptSave") return reply(promptSave(message.data || {}));
    if (message.action === "saveApplication") return reply(saveApplication(message.data || {}));
    if (message.action === "getHistory") return reply(getHistory().then((history) => ({ ok: true, history })));
    if (message.action === "getStats") return reply(getStats());
    if (message.action === "checkDuplicate") return reply(checkDuplicate(message.url));
    if (message.action === "markFollowedUp") return reply(markFollowedUp(message.id));
    if (message.action === "updateApplication") return reply(updateApplication(message.data || {}));
    if (message.action === "deleteApplication") return reply(deleteApplication(message.id));
    if (message.action === "exportData") return reply(exportData(message.format));
    if (message.action === "importData") return reply(importData(message.text || ""));
    return undefined;
});

function localDate(date = new Date()) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
}

function parseAppDate(value) {
    const text = String(value ?? "").trim();
    const iso = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) return new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
    const months = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
    const pretty = text.match(/^(\d{1,2})-([A-Za-z]{3})-(\d{2})$/);
    if (pretty && months[pretty[2].toLowerCase()] != null) {
        return new Date(2000 + Number(pretty[3]), months[pretty[2].toLowerCase()], Number(pretty[1]));
    }
    const parsed = new Date(text);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function needsFollowUp(app) {
    if (app.followedUp) return false;
    if ((app.status || "Applied") !== "Applied") return false;
    const date = parseAppDate(app.applicationDate) || parseAppDate(app.savedAt);
    if (!date) return false;
    const cutoff = new Date();
    cutoff.setHours(0, 0, 0, 0);
    cutoff.setDate(cutoff.getDate() - 7);
    const day = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    return day <= cutoff;
}

async function getHistory() {
    const { history = [] } = await chrome.storage.local.get("history");
    return history;
}

async function saveApplication(data) {
    const role = String(data.jobTitle || "").trim();
    if (!role) throw new Error("Add the role before saving.");

    const { history = [] } = await chrome.storage.local.get("history");
    history.unshift({
        id: crypto.randomUUID(),
        applicationDate: localDate(),
        jobTitle: role,
        companyName: String(data.companyName || "").trim(),
        url: String(data.url || "").trim(),
        location: String(data.location || "").trim(),
        salary: String(data.salary || "").trim(),
        resumeUsed: String(data.resumeUsed || "").trim(),
        status: String(data.status || "Applied").trim() || "Applied",
        notes: String(data.notes || "").trim(),
        source: String(data.source || "").trim(),
        savedAt: new Date().toISOString(),
        followedUp: false,
    });
    if (history.length > 500) history.length = 500;
    await chrome.storage.local.set({ history });
    refreshBadge();
    return { ok: true };
}

async function updateApplication(data) {
    const role = String(data.jobTitle || "").trim();
    if (!role) throw new Error("Add the role before saving.");
    const { history = [] } = await chrome.storage.local.get("history");
    const app = history.find((item) => item.id === data.id);
    if (!app) throw new Error("That application is no longer saved.");
    app.jobTitle = role;
    app.companyName = String(data.companyName || "").trim();
    app.location = String(data.location || "").trim();
    app.salary = String(data.salary || "").trim();
    app.status = String(data.status || "Applied").trim() || "Applied";
    app.notes = String(data.notes || "").trim();
    app.followedUp = app.status !== "Applied";
    await chrome.storage.local.set({ history });
    refreshBadge();
    return { ok: true };
}

async function deleteApplication(id) {
    const { history = [] } = await chrome.storage.local.get("history");
    const next = history.filter((item) => item.id !== id);
    if (next.length === history.length) throw new Error("That application is no longer saved.");
    await chrome.storage.local.set({ history: next });
    refreshBadge();
    return { ok: true };
}

async function markFollowedUp(id) {
    const { history = [] } = await chrome.storage.local.get("history");
    const app = history.find((item) => item.id === id);
    if (!app) throw new Error("That application is no longer saved.");
    app.status = "Follow-up";
    app.followedUp = true;
    await chrome.storage.local.set({ history });
    refreshBadge();
    return { ok: true };
}

async function checkDuplicate(url) {
    if (!url) return { isDuplicate: false };
    const history = await getHistory();
    const match = history.find((app) => app.url === url);
    if (!match) return { isDuplicate: false };
    return {
        isDuplicate: true,
        existingApp: {
            jobTitle: match.jobTitle,
            companyName: match.companyName,
            savedAt: match.savedAt,
        },
    };
}

async function getStats() {
    const { dailyGoal = 5 } = await chrome.storage.local.get("dailyGoal");
    const history = await getHistory();
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());

    let todayCount = 0;
    let weekCount = 0;
    let needFollowUp = 0;
    const statusBreakdown = {};
    const sources = {};

    history.forEach((app) => {
        const date = parseAppDate(app.applicationDate) || parseAppDate(app.savedAt);
        const status = app.status || "Applied";
        if (date && date.getFullYear() === today.getFullYear() && date.getMonth() === today.getMonth() && date.getDate() === today.getDate()) {
            todayCount += 1;
        }
        if (date && date >= weekStart) weekCount += 1;
        if (needsFollowUp(app)) needFollowUp += 1;
        statusBreakdown[status] = (statusBreakdown[status] || 0) + 1;
        const source = app.source || "Other";
        sources[source] = (sources[source] || 0) + 1;
    });

    const recentApps = history.map((app) => ({
        id: app.id,
        jobTitle: app.jobTitle,
        companyName: app.companyName,
        location: app.location || "",
        salary: app.salary || "",
        notes: app.notes || "",
        status: app.status || "Applied",
        applicationDate: app.applicationDate || "",
        needsFollowUp: needsFollowUp(app),
    }));

    return {
        ok: true,
        dailyGoal,
        totalApps: history.length,
        todayCount,
        weekCount,
        needFollowUp,
        statusBreakdown,
        sources,
        recentApps,
    };
}

async function refreshBadge() {
    try {
        const stats = await getStats();
        const count = stats.needFollowUp || 0;
        await chrome.action.setBadgeBackgroundColor({ color: "#e8442f" });
        await chrome.action.setBadgeText({ text: count > 0 ? String(Math.min(count, 99)) : "" });
    } catch (err) {
        console.warn("Badge update failed:", err);
    }
}

function csvCell(value) {
    const text = String(value ?? "");
    if (/[",\n\r]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
    return text;
}

function toCsv(history) {
    const lines = [CSV_HEADERS.join(",")];
    history.forEach((app) => {
        lines.push([
            app.applicationDate,
            app.companyName,
            app.jobTitle,
            app.url,
            app.location,
            app.salary,
            app.resumeUsed,
            app.status,
            app.notes,
        ].map(csvCell).join(","));
    });
    return lines.join("\r\n");
}

function parseCsv(text) {
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    const source = String(text).replace(/^\uFEFF/, "");

    for (let i = 0; i < source.length; i += 1) {
        const char = source[i];
        const next = source[i + 1];
        if (quoted && char === '"' && next === '"') {
            cell += '"';
            i += 1;
        } else if (char === '"') {
            quoted = !quoted;
        } else if (char === "," && !quoted) {
            row.push(cell);
            cell = "";
        } else if ((char === "\n" || char === "\r") && !quoted) {
            if (char === "\r" && next === "\n") i += 1;
            row.push(cell);
            cell = "";
            if (row.some((value) => value.trim() !== "")) rows.push(row);
            row = [];
        } else {
            cell += char;
        }
    }
    row.push(cell);
    if (row.some((value) => value.trim() !== "")) rows.push(row);
    return rows;
}

function headerKey(label) {
    const key = String(label || "").trim().toLowerCase();
    const map = {
        "date applied": "applicationDate",
        date: "applicationDate",
        company: "companyName",
        role: "jobTitle",
        "job title": "jobTitle",
        "job link": "url",
        url: "url",
        jd: "url",
        where: "location",
        location: "location",
        "your price": "salary",
        salary: "salary",
        price: "salary",
        resume: "resumeUsed",
        status: "status",
        notes: "notes",
        id: "id",
    };
    return map[key] || "";
}

function applicationsFromCsv(text) {
    const rows = parseCsv(text);
    if (!rows.length) return [];
    const keys = rows[0].map(headerKey);
    if (!keys.includes("jobTitle") && !keys.includes("companyName")) {
        throw new Error("The file needs a header row with Role or Company.");
    }
    return rows.slice(1).map((row) => {
        const app = {};
        keys.forEach((key, index) => {
            if (key) app[key] = String(row[index] || "").trim();
        });
        return app;
    }).filter((app) => app.jobTitle || app.companyName);
}

function applicationsFromJson(text) {
    const parsed = JSON.parse(text);
    const list = Array.isArray(parsed) ? parsed : parsed.applications;
    if (!Array.isArray(list)) throw new Error("The JSON file has no applications list.");
    return list.map((app) => ({
        id: app.id,
        applicationDate: app.applicationDate || "",
        jobTitle: app.jobTitle || "",
        companyName: app.companyName || "",
        url: app.url || "",
        location: app.location || "",
        salary: app.salary || "",
        resumeUsed: app.resumeUsed || "",
        status: app.status || "Applied",
        notes: app.notes || "",
        source: app.source || "",
        savedAt: app.savedAt || "",
        followedUp: Boolean(app.followedUp),
    })).filter((app) => app.jobTitle || app.companyName);
}

async function exportData(format) {
    const history = await getHistory();
    if (format === "json") {
        return {
            ok: true,
            filename: "jobrow-backup.json",
            mime: "application/json",
            text: JSON.stringify({ version: 1, applications: history }, null, 2),
        };
    }
    return {
        ok: true,
        filename: "jobrow.csv",
        mime: "text/csv",
        text: toCsv(history),
    };
}

async function importData(text) {
    const trimmed = String(text || "").trim();
    if (!trimmed) throw new Error("That file is empty.");
    const incoming = trimmed.startsWith("{") || trimmed.startsWith("[")
        ? applicationsFromJson(trimmed)
        : applicationsFromCsv(trimmed);
    if (!incoming.length) throw new Error("No applications were found in that file.");

    const history = await getHistory();
    let added = 0;
    let updated = 0;

    incoming.forEach((app) => {
        const match = history.find((item) => (
            (app.id && item.id === app.id) || (app.url && item.url === app.url)
        ));
        if (match) {
            match.applicationDate = app.applicationDate || match.applicationDate;
            match.jobTitle = app.jobTitle || match.jobTitle;
            match.companyName = app.companyName || match.companyName;
            match.url = app.url || match.url;
            match.location = app.location || match.location;
            match.salary = app.salary || match.salary;
            match.resumeUsed = app.resumeUsed || match.resumeUsed;
            match.status = app.status || match.status;
            match.notes = app.notes || match.notes;
            match.followedUp = app.status === "Follow-up" || app.followedUp || match.followedUp;
            updated += 1;
            return;
        }
        history.push({
            id: app.id || crypto.randomUUID(),
            applicationDate: app.applicationDate || localDate(),
            jobTitle: app.jobTitle || "",
            companyName: app.companyName || "",
            url: app.url || "",
            location: app.location || "",
            salary: app.salary || "",
            resumeUsed: app.resumeUsed || "",
            status: app.status || "Applied",
            notes: app.notes || "",
            source: app.source || "",
            savedAt: app.savedAt || new Date().toISOString(),
            followedUp: app.status === "Follow-up" || Boolean(app.followedUp),
        });
        added += 1;
    });

    if (history.length > 500) history.length = 500;
    await chrome.storage.local.set({ history });
    refreshBadge();
    return { ok: true, added, updated };
}
