# Install Jobrow

1. Download this folder, or clone the repository.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked** and choose the folder that contains `manifest.json`.
5. Pin **Jobrow**.
6. Open a job page and save a role. Use Setup → Download CSV when you want a spreadsheet.

To update a local copy, replace the folder and click the reload icon on the Jobrow card.
