/* =========================================================
   popup.js — Jobrow popup
   • Save, Board, Setup
   • Scrapes the open job page
   • Writes the row to the Google Sheet Jobrow created
   ========================================================= */

"use strict";

// ─── DOM refs: Track tab ──────────────────────────────────
const $jobTitle = document.getElementById("jobTitle");
const $companyName = document.getElementById("companyName");
const $location = document.getElementById("location");
const $salary = document.getElementById("salary");
const $pageUrl = document.getElementById("pageUrl");
const $dateTime = document.getElementById("dateTime");
const $resumeSelect = document.getElementById("resumeSelect");
const $appStatus = document.getElementById("appStatus");
const $notes = document.getElementById("notes");
const $form = document.getElementById("trackerForm");
const $saveBtn = document.getElementById("saveBtn");
const $status = document.getElementById("status");
const $dupWarning = document.getElementById("duplicateWarning");
const $dupDetails = document.getElementById("duplicateDetails");

// ─── DOM refs: Dashboard tab ──────────────────────────────
const $goalCount = document.getElementById("goalCount");
const $goalTotal = document.getElementById("goalTotal");
const $goalRingFill = document.getElementById("goalRingFill");
const $goalMotivate = document.getElementById("goalMotivate");
const $statTotal = document.getElementById("statTotal");
const $statWeek = document.getElementById("statWeek");
const $statFollowUp = document.getElementById("statFollowUp");
const $barHigh = document.getElementById("barHigh");
const $barMedium = document.getElementById("barMedium");
const $barLow = document.getElementById("barLow");
const $countHigh = document.getElementById("countHigh");
const $countMedium = document.getElementById("countMedium");
const $countLow = document.getElementById("countLow");
const $sourceChips = document.getElementById("sourceChips");
const $recentList = document.getElementById("recentList");
const $boardSearch = document.getElementById("boardSearch");
const $boardFilters = document.getElementById("boardFilters");

// ─── DOM refs: Tabs & navigation ─────────────────────────
const $tabs = document.querySelectorAll(".tab");
const $tabContents = {
    track: document.getElementById("tabTrack"),
    dashboard: document.getElementById("tabDashboard"),
    settings: document.getElementById("tabSettings")
};
const $settingsBtn = document.getElementById("settingsBtn");
const $closeTrackerBtn = document.getElementById("closeTrackerBtn");
const $refreshBtn = document.getElementById("refreshBtn");

// ─── DOM refs: Settings tab ───────────────────────────────
const $newResumeName = document.getElementById("newResumeName");
const $newResumeFile = document.getElementById("newResumeFile");
const $newResumeFileText = document.getElementById("newResumeFileText");
const $addResumeBtn = document.getElementById("addResumeBtn");
const $addResumeStatus = document.getElementById("addResumeStatus");
const $resumeLibraryList = document.getElementById("resumeLibraryList");
const $resumeLibraryEmpty = document.getElementById("resumeLibraryEmpty");
const $exportCsvBtn = document.getElementById("exportCsvBtn");
const $exportJsonBtn = document.getElementById("exportJsonBtn");
const $importFile = document.getElementById("importFile");
const $importFileText = document.getElementById("importFileText");
const $settingsDailyGoal = document.getElementById("settingsDailyGoal");
const $saveGoalBtn = document.getElementById("saveGoalBtn");
const $settingsStatus = document.getElementById("settingsStatus");

// ─── DOM refs: Tailored resume ────────────────────────────
const $tailoredResumeFile = document.getElementById("tailoredResumeFile");
const $tailoredResumeFileText = document.getElementById("tailoredResumeFileText");

// ═══════════════════════════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════════════════════════

function extractDomain(url) {
    try { return new URL(url).hostname.replace(/^www\./, ""); }
    catch { return ""; }
}

/** Retry wrapper for chrome.runtime.sendMessage to handle transient SW wake-up errors */
async function sendMessageWithRetry(msg, retries = 3, delay = 300) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await chrome.runtime.sendMessage(msg);
            return response;
        } catch (err) {
            if (i < retries - 1) {
                await new Promise(r => setTimeout(r, delay));
            } else {
                throw err;
            }
        }
    }
}

function formatDateTime(date) {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const d = String(date.getDate()).padStart(2, "0");
    const m = months[date.getMonth()];
    const y = String(date.getFullYear()).slice(-2); // get last 2 digits

    const hh = String(date.getHours()).padStart(2, "0");
    const mm = String(date.getMinutes()).padStart(2, "0");

    return `${d}-${m}-${y} ${hh}:${mm}`;
}

function formatDateOnly(date) {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const d = String(date.getDate()).padStart(2, "0");
    const m = months[date.getMonth()];
    const y = String(date.getFullYear()).slice(-2);

    return `${d}-${m}-${y}`;
}

function downloadText(filename, mime, text) {
    const blob = new Blob([text], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
}

async function exportFile(format) {
    const result = await sendMessageWithRetry({ action: "exportData", format });
    if (!result?.ok) throw new Error(result?.error || "Could not export.");
    downloadText(result.filename, result.mime, result.text);
}

function showStatus(message, type = "success") {
    $status.textContent = message;
    $status.className = `status ${type} visible`;
    setTimeout(() => $status.classList.remove("visible"), 4000);
}

function setLoading(loading) {
    $saveBtn.disabled = loading;
    $saveBtn.querySelector(".btn-text").style.display = loading ? "none" : "";
    $saveBtn.querySelector(".btn-loader").style.display = loading ? "inline-flex" : "none";
}

function timeAgo(dateStr) {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
}

// ═══════════════════════════════════════════════════════════
//  TAB SWITCHING
// ═══════════════════════════════════════════════════════════

$tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
        $tabs.forEach((t) => t.classList.remove("active"));
        tab.classList.add("active");
        const target = tab.dataset.tab;
        Object.values($tabContents).forEach((c) => c.classList.remove("active"));
        $tabContents[target].classList.add("active");
        if (target === "dashboard") loadDashboard();
        if (target === "settings") loadSettingsTab();
    });
});

// Settings button → open welcome wizard
$settingsBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
});

// Refresh button
if ($refreshBtn) {
    $refreshBtn.addEventListener("click", async () => {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return;

        // Add a quick spinning animation to the icon
        const svg = $refreshBtn.querySelector("svg");
        if (svg) svg.style.animation = "spin 1s linear infinite";

        $pageUrl.value = tab.url || "";
        checkDuplicate(tab.url);

        try {
            // Always try to re-inject just in case the page navigation cleared our content script
            await chrome.runtime.sendMessage({ action: "ensureContentScript", tabId: tab.id });
            await new Promise((r) => setTimeout(r, 250));
            const data = await messageScraper(tab.id);
            applyScrapedData(data, tab.title);
            
            // Manually set a success status directly if desired
            const prevStatus = $status.textContent;
            const prevClass = $status.className;
            $status.textContent = "Data Refreshed!";
            $status.className = "status success visible";
            setTimeout(() => {
                $status.classList.remove("visible");
                setTimeout(() => {
                    $status.textContent = prevStatus;
                    $status.className = prevClass;
                }, 250);
            }, 2000);
        } catch {
            $jobTitle.value = tab.title || "";
        } finally {
            if (svg) svg.style.animation = "";
        }
    });
}

// Close button → sends postMessage to parent window to hide iframe
if ($closeTrackerBtn) {
    $closeTrackerBtn.addEventListener("click", () => {
        window.parent.postMessage({ action: "closeJobTracker" }, "*");
    });
}

// Theme Toggle
const $themeToggleBtn = document.getElementById("themeToggleBtn");
const $sunIcon = document.querySelector(".sun-icon");
const $moonIcon = document.querySelector(".moon-icon");

function applyTheme(theme) {
    document.body.dataset.theme = theme;
    if (theme === "light") {
        $sunIcon.style.display = "block";
        $moonIcon.style.display = "none";
    } else {
        $sunIcon.style.display = "none";
        $moonIcon.style.display = "block";
    }
}

$themeToggleBtn.addEventListener("click", () => {
    const newTheme = document.body.dataset.theme === "light" ? "dark" : "light";
    applyTheme(newTheme);
    chrome.storage.local.set({ theme: newTheme });
});

// Header button downloads the CSV.
const $openSheetBtn = document.getElementById("openSheetBtn");
$openSheetBtn.addEventListener("click", async () => {
    try {
        await exportFile("csv");
        showStatus("CSV downloaded. Import it in Google Sheets with File → Import.", "success");
    } catch (err) {
        showStatus(err.message, "error");
    }
});

// Show filename when user picks a file in the settings resume form
$newResumeFile.addEventListener("change", () => {
    const f = $newResumeFile.files[0];
    $newResumeFileText.textContent = f ? f.name : "Choose PDF file…";
});

// Show filename for tailored resume in track tab
$tailoredResumeFile.addEventListener("change", () => {
    const f = $tailoredResumeFile.files[0];
    $tailoredResumeFileText.textContent = f ? f.name : "Choose PDF (optional)…";
});

// Setup drag and drop for file uploads
function setupDragAndDrop(labelElement, fileInputElement, textElement, defaultText) {
    if (!labelElement) return;
    
    labelElement.addEventListener("dragover", (e) => {
        e.preventDefault();
        labelElement.classList.add("drag-over");
    });

    labelElement.addEventListener("dragleave", (e) => {
        e.preventDefault();
        labelElement.classList.remove("drag-over");
    });

    labelElement.addEventListener("drop", (e) => {
        e.preventDefault();
        labelElement.classList.remove("drag-over");
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            const f = e.dataTransfer.files[0];
            if (f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf")) {
                fileInputElement.files = e.dataTransfer.files;
                textElement.textContent = f.name;
                // Dispatch change event to handle any specific file uploading logics elsewhere
                fileInputElement.dispatchEvent(new Event("change"));
            } else {
                showStatus("Please drop a valid PDF file.", "error");
            }
        }
    });
}

setupDragAndDrop(
    document.getElementById("newResumeFileLabel"),
    $newResumeFile,
    $newResumeFileText,
    "Choose PDF file…"
);

setupDragAndDrop(
    document.getElementById("tailoredResumeLabel"),
    $tailoredResumeFile,
    $tailoredResumeFileText,
    "Choose PDF (optional)…"
);

// ═══════════════════════════════════════════════════════════
//  RESUME LIBRARY — Stored as [{name, driveUrl}] in resumeLibrary
// ═══════════════════════════════════════════════════════════

async function getResumeLibrary() {
    const { resumeLibrary = [] } = await chrome.storage.local.get("resumeLibrary");
    return resumeLibrary;
}

async function saveResumeLibrary(library) {
    await chrome.storage.local.set({ resumeLibrary: library });
}

async function populateResumeDropdown() {
    const library = await getResumeLibrary();
    $resumeSelect.innerHTML = "";

    // ── "Tailored Resume" always first ──
    const tailoredEl = document.createElement("option");
    tailoredEl.value = "__tailored__";
    tailoredEl.textContent = "📎 Tailored Resume (upload PDF)";
    $resumeSelect.appendChild(tailoredEl);

    // ── General resumes from library ──
    library.forEach((r) => {
        const el = document.createElement("option");
        el.value = r.name;
        el.textContent = r.name;
        $resumeSelect.appendChild(el);
    });

    // ── "+ Add in Settings" at end ──
    const addEl = document.createElement("option");
    addEl.value = "__add_new__";
    addEl.textContent = "+ Add Resume in Settings →";
    $resumeSelect.appendChild(addEl);

    if (library.length > 0) {
        $resumeSelect.value = library[0].name;
    } else {
        $resumeSelect.value = "__tailored__";
    }

    // Restore file picker visibility on repopulate
    updateTailoredVisibility();
}

function updateTailoredVisibility() {
    const isTailored = $resumeSelect.value === "__tailored__";
    const $label = document.getElementById("tailoredResumeLabel");
    if ($label) $label.style.display = isTailored ? "flex" : "none";
}

$resumeSelect.addEventListener("change", () => {
    if ($resumeSelect.value === "__add_new__") {
        // Switch to Settings tab
        $tabs.forEach((t) => t.classList.remove("active"));
        document.querySelector('.tab[data-tab="settings"]').classList.add("active");
        Object.values($tabContents).forEach((c) => c.classList.remove("active"));
        $tabContents.settings.classList.add("active");
        loadSettingsTab();
        // Reset to tailored option
        $resumeSelect.value = "__tailored__";
    }
    updateTailoredVisibility();
});

// ═══════════════════════════════════════════════════════════
//  SETTINGS TAB
// ═══════════════════════════════════════════════════════════

async function loadSettingsTab() {
    const { dailyGoal = 5 } = await chrome.storage.local.get("dailyGoal");
    $settingsDailyGoal.value = dailyGoal;
    await renderResumeLibrary();
}

async function renderResumeLibrary() {
    const library = await getResumeLibrary();
    $resumeLibraryList.innerHTML = "";

    if (library.length === 0) {
        $resumeLibraryEmpty.style.display = "flex";
        return;
    }
    $resumeLibraryEmpty.style.display = "none";

    // Setup drag and drop state for reordering
    let draggedItemIdx = null;

    library.forEach((resume, idx) => {
        const item = document.createElement("div");
        item.className = "resume-library-item";
        item.draggable = true; // Make item draggable
        item.dataset.idx = idx; // Store original index on element
        
        item.innerHTML = `
            <div class="resume-library-drag-handle" title="Drag to reorder" style="cursor: grab; margin-right: 8px; color: var(--text-muted); display: flex; align-items: center;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
            </div>
            <div class="resume-library-info">
                <div class="resume-library-name">${escapeHtml(resume.name)}</div>
                ${resume.driveUrl
                    ? `<a class="resume-library-link" href="${escapeHtml(resume.driveUrl)}" target="_blank">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                        Open in Drive
                       </a>`
                    : `<span class="resume-library-no-link">Saved in Jobrow</span>`}
            </div>
            <div class="resume-library-actions">
                <button class="resume-delete-btn" data-idx="${idx}" title="Remove">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                </button>
            </div>
        `;
        
        // Drag events for reordering
        item.addEventListener("dragstart", (e) => {
            draggedItemIdx = parseInt(item.dataset.idx);
            item.classList.add("dragging");
            e.dataTransfer.effectAllowed = "move";
            e.dataTransfer.setData("text/plain", draggedItemIdx); // needed for Firefox
        });

        item.addEventListener("dragend", () => {
            item.classList.remove("dragging");
            draggedItemIdx = null;
        });

        item.addEventListener("dragover", (e) => {
            e.preventDefault(); // Necessary to allow dropping
            e.dataTransfer.dropEffect = "move";
            const bounding = item.getBoundingClientRect();
            const offset = bounding.y + (bounding.height / 2);
            if (e.clientY - offset > 0) {
                item.style.borderBottom = "2px solid var(--primary)";
                item.style.borderTop = "";
            } else {
                item.style.borderTop = "2px solid var(--primary)";
                item.style.borderBottom = "";
            }
        });

        item.addEventListener("dragleave", () => {
            item.style.borderTop = "";
            item.style.borderBottom = "";
        });

        item.addEventListener("drop", async (e) => {
            e.preventDefault();
            item.style.borderTop = "";
            item.style.borderBottom = "";
            
            if (draggedItemIdx === null) return;
            const targetIdx = parseInt(item.dataset.idx);
            
            if (draggedItemIdx !== targetIdx) {
                const lib = await getResumeLibrary();
                
                // Adjust target index if dropping below the midpoint
                const bounding = item.getBoundingClientRect();
                const offset = bounding.y + (bounding.height / 2);
                let dropTargetIdx = targetIdx;
                if (e.clientY - offset > 0) {
                    dropTargetIdx++;
                }

                if (draggedItemIdx < dropTargetIdx) {
                    dropTargetIdx--;
                }
                
                // Move item in array
                const [movedItem] = lib.splice(draggedItemIdx, 1);
                lib.splice(dropTargetIdx, 0, movedItem);
                
                await saveResumeLibrary(lib);
                await renderResumeLibrary();
                await populateResumeDropdown();
            }
        });

        $resumeLibraryList.appendChild(item);
    });

    // Delete button handlers
    $resumeLibraryList.querySelectorAll(".resume-delete-btn").forEach((btn) => {
        btn.addEventListener("click", async () => {
            const idx = parseInt(btn.dataset.idx);
            const lib = await getResumeLibrary();
            lib.splice(idx, 1);
            await saveResumeLibrary(lib);
            await renderResumeLibrary();
            await populateResumeDropdown();
        });
    });
}

$addResumeBtn.addEventListener("click", async () => {
    const name = $newResumeName.value.trim();
    if (!name) { $newResumeName.focus(); return; }
    const file = $newResumeFile.files[0];

    const lib = await getResumeLibrary();
    const existing = lib.findIndex((resume) => resume.name === name);
    const entry = { name, fileName: file ? file.name : "" };
    if (existing >= 0) lib[existing] = { ...lib[existing], ...entry };
    else lib.push(entry);
    await saveResumeLibrary(lib);

    $newResumeName.value = "";
    $newResumeFile.value = "";
    $newResumeFileText.textContent = "Choose PDF file…";
    $addResumeStatus.textContent = "Resume saved.";
    $addResumeStatus.className = "upload-status success";
    setTimeout(() => { $addResumeStatus.textContent = ""; $addResumeStatus.className = "upload-status"; }, 3000);

    await renderResumeLibrary();
    await populateResumeDropdown();
});

$exportCsvBtn.addEventListener("click", async () => {
    try {
        await exportFile("csv");
        $settingsStatus.textContent = "CSV downloaded.";
        $settingsStatus.className = "status success visible";
    } catch (err) {
        $settingsStatus.textContent = err.message;
        $settingsStatus.className = "status error visible";
    }
});

$exportJsonBtn.addEventListener("click", async () => {
    try {
        await exportFile("json");
        $settingsStatus.textContent = "Backup downloaded.";
        $settingsStatus.className = "status success visible";
    } catch (err) {
        $settingsStatus.textContent = err.message;
        $settingsStatus.className = "status error visible";
    }
});

$importFile.addEventListener("change", async () => {
    const file = $importFile.files[0];
    if (!file) return;
    $importFileText.textContent = file.name;
    try {
        const text = await file.text();
        const result = await sendMessageWithRetry({ action: "importData", text });
        if (!result?.ok) throw new Error(result?.error || "Could not import.");
        $settingsStatus.textContent = `Imported ${result.added} new and updated ${result.updated}.`;
        $settingsStatus.className = "status success visible";
        loadDashboard();
    } catch (err) {
        $settingsStatus.textContent = err.message;
        $settingsStatus.className = "status error visible";
    } finally {
        $importFile.value = "";
    }
});

$saveGoalBtn.addEventListener("click", async () => {
    const dailyGoal = parseInt($settingsDailyGoal.value, 10) || 5;
    await chrome.storage.local.set({ dailyGoal });
    $settingsStatus.textContent = "Daily goal saved.";
    $settingsStatus.className = "status success visible";
    setTimeout(() => $settingsStatus.classList.remove("visible"), 3000);
});

// ═══════════════════════════════════════════════════════════
//  INIT — Check first-time, scrape data, check duplicates
// ═══════════════════════════════════════════════════════════

async function init() {
    const { theme } = await chrome.storage.local.get("theme");
    if (theme) applyTheme(theme);

    await populateResumeDropdown();

    // Set date/time
    const now = new Date();
    $dateTime.value = formatDateTime(now);

    const preview = new URLSearchParams(location.search).get("preview") === "1";
    if (preview && await loadPendingDraft()) return;

    // Get active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || tab.url.startsWith("chrome-extension://")) return;

    $pageUrl.value = tab.url || "";

    // Check for duplicate URL
    checkDuplicate(tab.url);

    // Try to scrape
    try {
        const data = await messageScraper(tab.id);
        applyScrapedData(data, tab.title);
    } catch {
        try {
            await sendMessageWithRetry({ action: "ensureContentScript", tabId: tab.id });
            await new Promise((r) => setTimeout(r, 250));
            const data = await messageScraper(tab.id);
            applyScrapedData(data, tab.title);
        } catch {
            $jobTitle.value = tab.title || "";
        }
    }
}

function messageScraper(tabId) {
    return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, { action: "scrapeJobData" }, (response) => {
            if (chrome.runtime.lastError || !response) reject(chrome.runtime.lastError);
            else resolve(response);
        });
    });
}

function applyScrapedData(data, fallbackTitle) {
    const role = (data.jobTitle || "").trim();
    if (role) $jobTitle.value = role;
    else if (fallbackTitle && !/\|/.test(fallbackTitle)) $jobTitle.value = fallbackTitle;
    if (data.companyName) $companyName.value = data.companyName.trim();
    if (data.location) $location.value = data.location.trim();
    if (data.salary) $salary.value = data.salary.trim();
    if (data.url) $pageUrl.value = data.url;
}

async function loadPendingDraft() {
    const { pendingDraft } = await chrome.storage.session.get("pendingDraft");
    if (!pendingDraft) return false;
    applyScrapedData(pendingDraft, "");
    document.getElementById("previewNote")?.classList.add("visible");
    checkDuplicate(pendingDraft.url);
    return true;
}

// ═══════════════════════════════════════════════════════════
//  DUPLICATE URL CHECK
// ═══════════════════════════════════════════════════════════

async function checkDuplicate(url) {
    try {
        const result = await sendMessageWithRetry({ action: "checkDuplicate", url });
        if (result && result.isDuplicate) {
            const app = result.existingApp;
            $dupDetails.textContent = `You saved "${app.jobTitle}" at ${app.companyName || "—"} on ${new Date(app.savedAt).toLocaleDateString()}.`;
            $dupWarning.style.display = "flex";
        }
    } catch { /* ignore */ }
}

// ═══════════════════════════════════════════════════════════
//  FORM SUBMISSION
// ═══════════════════════════════════════════════════════════

$form.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (!$jobTitle.value.trim()) {
        showStatus("Add the role before saving.", "error");
        return;
    }

    setLoading(true);

    const selectedResume = $resumeSelect.value;
    const isTailored = selectedResume === "__tailored__";
    let resumeUsed = "";
    if (isTailored) {
        const tailoredFile = $tailoredResumeFile.files[0];
        resumeUsed = tailoredFile ? tailoredFile.name.replace(/\.pdf$/i, "") : "Tailored";
    } else if (selectedResume !== "__add_new__") {
        resumeUsed = selectedResume;
    }

    const payload = {
        jobTitle: $jobTitle.value.trim(),
        companyName: $companyName.value.trim(),
        url: $pageUrl.value,
        location: $location.value.trim(),
        salary: $salary.value.trim(),
        resumeUsed,
        source: extractDomain($pageUrl.value),
        status: $appStatus.value,
        notes: $notes.value.trim(),
    };

    try {
        const result = await sendMessageWithRetry({ action: "saveApplication", data: payload });
        if (!result?.ok) {
            showStatus(result?.error || "Could not save this role.", "error");
            return;
        }

        showStatus("Saved in Jobrow.", "success");
        
        // Close the iframe tracker upon successful save
        setTimeout(() => {
            window.parent.postMessage({ action: "closeJobTracker" }, "*");
        }, 1500); // Give user time to see success message

        // Refresh dashboard stats silently
        loadDashboard();
    } catch (err) {
        console.error("Save error:", err);
        showStatus("❌  Failed to save. Check console.", "error");
    } finally {
        setLoading(false);
    }
});

// ═══════════════════════════════════════════════════════════
//  DASHBOARD — counts come from the Jobrow sheet
// ═══════════════════════════════════════════════════════════

async function loadDashboard() {
    try {
        const { dailyGoal = 5 } = await chrome.storage.local.get("dailyGoal");
        const stats = await chrome.runtime.sendMessage({ action: "getStats" });
        if (!stats) return;

        stats.dailyGoal = stats.dailyGoal || dailyGoal;

        const pct = Math.min(stats.todayCount / stats.dailyGoal, 1);
        const circumference = 2 * Math.PI * 42;
        $goalRingFill.style.strokeDashoffset = circumference * (1 - pct);
        $goalCount.textContent = stats.todayCount;
        $goalTotal.textContent = stats.dailyGoal;

        if (stats.sheetError) {
            $goalMotivate.textContent = stats.sheetError;
        } else if (stats.todayCount === 0) {
            $goalMotivate.textContent = "Open a job page and save the role.";
        } else if (stats.todayCount < stats.dailyGoal) {
            const remaining = stats.dailyGoal - stats.todayCount;
            $goalMotivate.textContent = `${remaining} more to hit today's goal.`;
        } else {
            $goalMotivate.textContent = "Today's goal is done.";
        }

        $statTotal.textContent = stats.totalApps;
        $statWeek.textContent = stats.weekCount;
        $statFollowUp.textContent = stats.needFollowUp;

        const statusBreakdown = stats.statusBreakdown || {};
        const inProgressKeys = ["Follow-up", "OA", "Screening Call", "1st Round", "2nd Round", "3rd Round"];
        const inProgress = inProgressKeys.reduce((sum, key) => sum + (statusBreakdown[key] || 0), 0);
        const maxLik = Math.max(statusBreakdown["Applied"] || 0, inProgress, statusBreakdown["Rejected"] || 0, 1);
        $barHigh.style.width = `${((statusBreakdown["Applied"] || 0) / maxLik) * 100}%`;
        $barMedium.style.width = `${(inProgress / maxLik) * 100}%`;
        $barLow.style.width = `${((statusBreakdown["Rejected"] || 0) / maxLik) * 100}%`;
        $countHigh.textContent = statusBreakdown["Applied"] || 0;
        $countMedium.textContent = inProgress;
        $countLow.textContent = statusBreakdown["Rejected"] || 0;

        // ── Source Chips ──
        const sources = stats.sources || {};
        const entries = Object.entries(sources).sort((a, b) => b[1] - a[1]).slice(0, 6);
        if (entries.length) {
            $sourceChips.innerHTML = entries
                .map(([s, c]) => `<span class="source-chip">${escapeHtml(s)} <span class="source-count">${c}</span></span>`)
                .join("");
        } else {
            $sourceChips.innerHTML = '<span class="source-chip empty">No data yet</span>';
        }

        boardApps = stats.recentApps || [];
        renderBoardList();
    } catch (err) {
        console.warn("Dashboard load error:", err);
    }
}

const BOARD_PROGRESS = ["Follow-up", "OA", "Screening Call", "1st Round", "2nd Round", "3rd Round"];
let boardApps = [];
let boardFilter = "all";

function matchesBoard(app) {
    const query = ($boardSearch.value || "").trim().toLowerCase();
    if (query) {
        const haystack = [app.jobTitle, app.companyName, app.location, app.salary, app.notes, app.status]
            .join(" ")
            .toLowerCase();
        if (!haystack.includes(query)) return false;
    }
    const status = app.status || "Applied";
    if (boardFilter === "progress") return BOARD_PROGRESS.includes(status);
    if (boardFilter === "followup") return !!app.needsFollowUp;
    if (boardFilter !== "all") return status === boardFilter;
    return true;
}

function renderBoardList() {
    const apps = boardApps.filter(matchesBoard);
    if (!apps.length) {
        const message = boardApps.length
            ? "No roles match this search."
            : "No applications yet.<br/>Open a job page and save the role.";
        $recentList.innerHTML = `
        <div class="recent-empty">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          <p>${message}</p>
        </div>`;
        return;
    }

    const statuses = ["Applied", "Follow-up", "Rejected", "OA", "Screening Call", "1st Round", "2nd Round", "3rd Round"];
    $recentList.innerHTML = apps.map((app) => `
          <div class="recent-item" data-app-id="${escapeHtml(app.id)}">
            <div class="recent-dot status-${escapeHtml((app.status || "Applied").replace(/\s+/g, ""))}"></div>
            <div class="recent-info">
              <div class="recent-title">${escapeHtml(app.jobTitle || "Untitled")}</div>
              <div class="recent-company">${escapeHtml(app.companyName || "—")}</div>
            </div>
            <div class="recent-meta">
              <span class="recent-status-badge status-${escapeHtml((app.status || "Applied").replace(/\s+/g, ""))}">${escapeHtml(app.status || "Applied")}</span>
              <span class="recent-date">${escapeHtml(app.applicationDate || "")}</span>
            </div>
            <div class="recent-actions">
              <button type="button" class="follow-btn" data-edit-id="${escapeHtml(app.id)}">Edit</button>
              <button type="button" class="follow-btn" data-delete-id="${escapeHtml(app.id)}">Delete</button>
              ${app.needsFollowUp ? `<button type="button" class="follow-btn" data-follow-id="${escapeHtml(app.id)}">Followed up</button>` : ""}
            </div>
            <form class="edit-panel" data-edit-panel="${escapeHtml(app.id)}" hidden>
              <input type="text" data-field="jobTitle" value="${escapeHtml(app.jobTitle || "")}" placeholder="Role" required />
              <input type="text" data-field="companyName" value="${escapeHtml(app.companyName || "")}" placeholder="Company" />
              <input type="text" data-field="location" value="${escapeHtml(app.location || "")}" placeholder="Where" />
              <input type="text" data-field="salary" value="${escapeHtml(app.salary || "")}" placeholder="Your price" />
              <select data-field="status">
                ${statuses.map((status) => `<option value="${escapeHtml(status)}" ${status === (app.status || "Applied") ? "selected" : ""}>${escapeHtml(status)}</option>`).join("")}
              </select>
              <textarea data-field="notes" rows="2" placeholder="Notes">${escapeHtml(app.notes || "")}</textarea>
              <button type="submit" class="follow-btn" data-save-id="${escapeHtml(app.id)}">Save changes</button>
            </form>
          </div>
        `).join("");
}

$boardSearch.addEventListener("input", renderBoardList);
$boardFilters.addEventListener("click", (event) => {
    const chip = event.target.closest("[data-filter]");
    if (!chip) return;
    boardFilter = chip.dataset.filter;
    $boardFilters.querySelectorAll(".filter-chip").forEach((button) => {
        button.classList.toggle("active", button === chip);
    });
    renderBoardList();
});

$recentList.addEventListener("click", async (event) => {
    const editButton = event.target.closest("[data-edit-id]");
    if (editButton) {
        const panel = $recentList.querySelector(`[data-edit-panel="${CSS.escape(editButton.dataset.editId)}"]`);
        if (panel) panel.hidden = !panel.hidden;
        return;
    }

    const deleteButton = event.target.closest("[data-delete-id]");
    if (deleteButton) {
        const item = deleteButton.closest(".recent-item");
        const title = item?.querySelector(".recent-title")?.textContent || "this role";
        if (!window.confirm(`Delete ${title}?`)) return;
        deleteButton.disabled = true;
        const result = await sendMessageWithRetry({
            action: "deleteApplication",
            id: deleteButton.dataset.deleteId,
        });
        if (!result?.ok) {
            deleteButton.disabled = false;
            return;
        }
        loadDashboard();
        return;
    }

    const followButton = event.target.closest("[data-follow-id]");
    if (!followButton) return;
    followButton.disabled = true;
    const result = await sendMessageWithRetry({
        action: "markFollowedUp",
        id: followButton.dataset.followId,
    });
    if (!result?.ok) {
        followButton.disabled = false;
        return;
    }
    loadDashboard();
});

$recentList.addEventListener("submit", async (event) => {
    const form = event.target.closest("[data-edit-panel]");
    if (!form) return;
    event.preventDefault();
    const field = (name) => form.querySelector(`[data-field="${name}"]`)?.value || "";
    const result = await sendMessageWithRetry({
        action: "updateApplication",
        data: {
            id: form.dataset.editPanel,
            jobTitle: field("jobTitle"),
            companyName: field("companyName"),
            location: field("location"),
            salary: field("salary"),
            status: field("status"),
            notes: field("notes"),
        },
    });
    if (!result?.ok) return;
    loadDashboard();
});

function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
}

// ═══════════════════════════════════════════════════════════
//  BOOT
// ═══════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "draftReady") loadPendingDraft();
});

init();
