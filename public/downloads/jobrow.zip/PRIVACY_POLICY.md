# Privacy Policy for Jobrow

**Last Updated:** October 16, 2026  
**Developer:** Ali Hamza

## Overview

Jobrow saves job application details in your browser. This policy explains what leaves your computer.

## Data collection

Jobrow stores the following **only when you press "Save this role"**:

- Role, company, where, your price, status, and notes
- The job posting URL and the date you saved it
- The resume name you select

Jobrow does not collect your name, email, passwords, cookies, or browsing history. It reads a page when you click Apply or the Jobrow icon, and only to fill the preview. It does not upload the resume file.

## Where data stays

- Applications, the daily goal, and resume names stay in `chrome.storage.local` on your computer.
- Export downloads a CSV or JSON file to your computer. Jobrow does not send that file anywhere.
- Jobrow does not run a server and does not use a Google account.

## Permissions

| Permission | Why |
| --- | --- |
| `activeTab` | Read the open tab's URL and title when you click Jobrow |
| `scripting` | Read the role, company, price, and link when you click Apply or the Jobrow icon |
| `storage` | Keep applications, the daily goal, and resume names |
| `alarms` | Recheck follow-ups every 6 hours and update the badge |

## Deletion

Remove the extension to delete the saved applications. Delete the CSV or JSON file yourself if you exported one.

## Contact

Ali Hamza  
Email: [alihamza.devstack@gmail.com](mailto:alihamza.devstack@gmail.com)  
Policy page: [https://github.com/alihamzaio/jobrow/blob/main/privacy.html](https://github.com/alihamzaio/jobrow/blob/main/privacy.html)
