/* =========================================================
   welcome.js — First-run screen for Jobrow
   ========================================================= */

"use strict";

const $goal = document.getElementById("dailyGoal");
const $start = document.getElementById("startBtn");

async function init() {
    const data = await chrome.storage.local.get(["dailyGoal"]);
    if (data.dailyGoal) $goal.value = data.dailyGoal;
}

$start.addEventListener("click", async () => {
    await chrome.storage.local.set({
        dailyGoal: parseInt($goal.value, 10) || 5,
        setupComplete: true,
    });
    window.close();
});

init();
