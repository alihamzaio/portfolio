# Jobrow

Jobrow is a Chrome extension that keeps a job search in one place. Click Apply on a posting and a preview opens with the role, company, price, and link. Fix anything that is wrong, then save. The applications stay on your computer. When you want a spreadsheet, download a CSV and open it in Google Sheets or Excel.

Made by Ali Hamza.

## Install

1. Download this repository and unzip it, or clone it.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Choose the folder that contains `manifest.json`.
6. Click the puzzle icon in the Chrome toolbar and pin **Jobrow**.

The welcome screen opens the first time. Set a daily goal if you want one, then click **Start tracking**.

A local copy does not update by itself. After you download a newer copy, go back to `chrome://extensions` and click the reload icon on the Jobrow card.

## Save a role

Click **Apply** on a job page. Jobrow opens a preview with the role, company, price, place, and link filled in when the page publishes them. Check each field. If the company, price, or link is wrong, change it, then press **Save this role**.

You can also click the Jobrow icon on a job page and save from there.

Jobrow reads LinkedIn, Indeed, Glassdoor, Greenhouse, Lever, Workday, and company pages that include a job posting. If a field is empty, type it before you save.

![Save tab with the role, company, price, and link filled in](screenshots/track-tab.png)

If that job link was saved before, Jobrow shows a warning. You can still save it again.

## Board

**Board** is the list of roles already saved. Search by company or role, or filter by Applied, In progress, Rejected, and Need follow-up.

| What you see | What it means |
| --- | --- |
| Today's goal | How many roles you saved today, next to the daily goal |
| Total | Every role saved in this browser |
| This week | Roles saved since Sunday |
| Need follow-up | Roles still marked Applied after 7 days |

The Jobrow icon shows a badge with that follow-up count. Jobrow checks again every 6 hours.

On each saved role you can:

- **Edit** the role, company, where, price, status, and notes
- **Delete** the role
- **Followed up**, which sets the status to Follow-up and clears it from the badge

Status choices are Applied, Follow-up, Rejected, OA, Screening Call, 1st Round, 2nd Round, and 3rd Round.

![Board with today's goal and saved roles](screenshots/dashboard-tab.png)

## Spreadsheet

Setup → **Download CSV** writes this file:

```text
Date Applied, Company, Role, Job link, Where, Your price, Resume, Status, Notes
```

In Google Sheets, use **File → Import → Upload** and choose that CSV.

**Download backup** writes a JSON file. Use that file, or a CSV, with **Import CSV or JSON** to bring the roles back. A matching job link updates the role that is already there.

The same download is on the arrow button in the header.

![Setup with the resume list and CSV download](screenshots/settings-tab.png)

## Before you remove Jobrow

The saved roles live only in this browser. Removing the extension, or clearing extension data, deletes them. Download a CSV or a backup from Setup first. The welcome screen says the same thing.

## Privacy

Jobrow reads a page when you click Apply or the Jobrow icon, and only to fill the role, company, price, and link. It does not run a server, and it does not ask you to sign in to Google. The full policy is in [PRIVACY_POLICY.md](PRIVACY_POLICY.md). A page you can host is [privacy.html](privacy.html).

Questions: [alihamza.devstack@gmail.com](mailto:alihamza.devstack@gmail.com)

## License

MIT. See [LICENSE](LICENSE).
