# Deploy notes

This file used to describe a Koyeb free-tier box. **That is not how this app is hosted.**

Production is Railway. Follow [README.md](README.md).

- Live: https://localhost
- Dockerfile still lives at `docker/koyeb/Dockerfile` (name is historical). Railway and GHCR both use that file.
