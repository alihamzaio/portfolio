<#
  Starts the local, read-only SyncForge stack on this machine.

  Postgres and Redis are expected to already be listening on 5432/6379 (the containers
  this box already runs); this script only starts SyncForge's own Bun services, so nothing
  fights the DayOtter dev server on port 3000.

    .\run-local.ps1          # start api + web (+ worker + cron)
    .\run-local.ps1 -Stop    # stop whatever this script started
#>
param(
  [switch]$Stop,
  [string]$ProjectDir = $PSScriptRoot
)

$ErrorActionPreference = "Stop"
$logDir = Join-Path $env:TEMP "SyncForge-local"
$pidFile = Join-Path $logDir "pids.json"

if ($Stop) {
  if (!(Test-Path $pidFile)) { Write-Host "Nothing recorded as running."; exit 0 }
  foreach ($entry in (Get-Content $pidFile | ConvertFrom-Json)) {
    Get-Process -Id $entry.Id -ErrorAction SilentlyContinue |
      Where-Object { $_.ProcessName -in @("bun", "node", "npm") } |
      Stop-Process -Force
    Write-Host "stopped $($entry.Name) (pid $($entry.Id))"
  }
  Remove-Item $pidFile -Force
  exit 0
}

New-Item -ItemType Directory -Force -Path $logDir | Out-Null

# Bun is installed per-user and is not on the machine PATH.
$bun = Join-Path $env:USERPROFILE ".bun\bin\bun.exe"
if (!(Test-Path $bun)) { throw "bun not found at $bun" }

$envPath = Join-Path $ProjectDir ".env"
if (!(Test-Path $envPath)) { throw ".env not found at $envPath" }
Get-Content $envPath | ForEach-Object {
  if ($_ -match '^\s*([A-Z_][A-Z0-9_]*)=(.*)$') {
    [Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], "Process")
  }
}

# api must be up before web, which proxies to it. worker and cron do the calendar
# ingestion; drop them from this list to run the UI against already-synced data.
$services = @(
  @{ Name = "api";    Dir = "services\api" }
  @{ Name = "worker"; Dir = "services\worker" }
  @{ Name = "cron";   Dir = "services\cron" }
)

# The dashboard is a standalone npm/Next app rather than a Bun workspace member, so it
# starts through npm instead of the loop above.
$dashboardProcess = Start-Process -FilePath "npm.cmd" `
  -ArgumentList "run", "dev" `
  -WorkingDirectory (Join-Path $ProjectDir "applications\dashboard") `
  -RedirectStandardOutput (Join-Path $logDir "dashboard.out.log") `
  -RedirectStandardError  (Join-Path $logDir "dashboard.err.log") `
  -WindowStyle Hidden -PassThru

$started = foreach ($service in $services) {
  $process = Start-Process -FilePath $bun `
    -ArgumentList "run", "dev" `
    -WorkingDirectory (Join-Path $ProjectDir $service.Dir) `
    -RedirectStandardOutput (Join-Path $logDir "$($service.Name).out.log") `
    -RedirectStandardError  (Join-Path $logDir "$($service.Name).err.log") `
    -WindowStyle Hidden -PassThru
  [pscustomobject]@{ Name = $service.Name; Id = $process.Id }
}

$started = @($started) + [pscustomobject]@{ Name = "dashboard"; Id = $dashboardProcess.Id }
$started | ConvertTo-Json | Set-Content $pidFile
$started | Format-Table -AutoSize
Write-Host "logs: $logDir"
Write-Host "dashboard: http://localhost:$($env:PORT)"
