# Weeklane

Every company calendar on one private team board.

Connect Google and Outlook or ICS, label each source as a company, and see conflicts and free time without leaking join links. This is Ali Hamza's product for a private client install. It is not the Birxment company site.

## Start

Docker starts the database. The first time the Weeklane app starts, it updates the database and creates the administrator if one does not exist yet.

Local database only:

```bash
docker compose up -d
```

Then start the app (see Local development below) or deploy the Weeklane image. On that first start, sign in with:

| | |
|---|---|
| Email | `admin@weeklane.local` |
| Password | `WeeklaneAdmin1` |

Open **Profile** and change the email and password. Email is what you use to sign in. The next Docker start will not overwrite them.

Copy `services/api/.env.template` to `services/api/.env` before the first boot. The same file is what a reset uses. A reset means an empty database: delete the Docker volume, start again, and these values create the administrator and the license. If an administrator or a license is already stored, a later start does not overwrite them.

| Name | Default |
|---|---|
| `FIRST_ADMIN_EMAIL` | `admin@weeklane.local` |
| `FIRST_ADMIN_PASSWORD` | `WeeklaneAdmin1` |
| `FIRST_ADMIN_NAME` | `Weeklane Admin` |
| `LICENSE_BUYER_NAME` | `Weeklane Admin` |
| `LICENSE_BUYER_EMAIL` | `admin@weeklane.local` |
| `LICENSE_COMPANY` | empty |
| `LICENSE_PURCHASE_REF` | `manual` (Gumroad order id) |
| `LICENSE_PLAN` | `Solo` (`Team` is the other value) |

The password must be at least 8 characters. `LICENSE_PLAN` is `Solo` unless it is set to `Team`. Settings shows this license to the administrator. Change the buyer fields in `.env` before a reset when the install is for a real order.

## After you sign in

1. Open **Profile** and set your real email and a new password.
2. Open **Calendars** and connect Google, or paste an Outlook or ICS link.
3. Give each source a company name and a color.
4. Use **Sync now** instead of waiting for the next automatic sync.

Later people are added under **Users**. Only an administrator sees the license record. The public page, if you turn it on, shows busy or free and titles only. It does not show descriptions, locations, or meeting links.

## What you get

- Google (OAuth) and ICS or iCal, including Outlook publish links
- Company labels, colors, and a company filter
- Day, week, month, and agenda views
- Conflict detection and a free-time finder
- A private team schedule, plus an optional public busy or free page
- Import an `.ics` file or an Outlook print PDF
- Manual meeting entry when a source is missing

## Production

One private server. Point `DATABASE_URL` at Postgres. Do not put a trailing slash on URLs.

| Name | Value |
|---|---|
| `PORT` | `8000` |
| `DATABASE_URL` | Postgres connection string |
| `BETTER_AUTH_SECRET` | a long random secret |
| `ENCRYPTION_KEY` | another long random secret |
| `BETTER_AUTH_URL` | your public https address |
| `TRUSTED_ORIGINS` | the same address |
| `BETTER_AUTH_TRUSTED_PROXIES` | `*` |
| `COMMERCIAL_MODE` | `false` |

Leave `REDIS_URL` unset when Redis is inside the same image. Health check: `/api/health`.

Optional Google redirect: `{YOUR ADDRESS}/api/sources/callback/google`.

## Local development

```bash
bun install
docker compose up -d
```

Then start the API and the dashboard:

```bash
cd services/api && bun run dev
cd applications/dashboard && npm install && npm run dev
```

Dashboard: http://localhost:3010. API: http://localhost:3020.

`applications/dashboard/.env.local` should contain `API_ORIGIN=http://localhost:3020`.

The same first administrator is created the first time the API starts.

## License

Sold by Ali Hamza as an individual. See [LICENSE](LICENSE). One purchase is one private install. The buyer may run it for their own team and may not resell the source.

You do not need a company. When someone buys a copy, put their name and the Gumroad order id in `services/api/.env` (`LICENSE_BUYER_NAME`, `LICENSE_BUYER_EMAIL`, `LICENSE_PURCHASE_REF`) before that copy's first boot. Settings then shows that receipt. Leave `LICENSE_COMPANY` empty unless the buyer wants a company name on the line. `LICENSE_PLAN` is `Solo` or `Team`. A later start does not overwrite a license that is already stored.

## Store

Sell the download on Gumroad and link that page from your portfolio. Etsy is a poor fit: buyers there expect a file they can open, and Weeklane is a private calendar they run with Docker. Use the same screenshots either way. They are in `listing/screenshots`. Listing text is in `listing/gumroad.txt`. The meetings in those shots are fake (Acme Corp, Contoso, Northwind) and are not part of the download.
