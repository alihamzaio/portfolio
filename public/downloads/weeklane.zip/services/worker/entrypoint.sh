#!/bin/sh
set -e

export OTEL_SERVICE_NAME=SyncForge-worker

exec bun services/worker/dist/index.js 2>&1 | syncforge-otelemetry
