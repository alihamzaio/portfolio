import { isSyncForgeMcpEnabledAuth, createAuth } from "@syncforge/auth";
import { createDatabase } from "@syncforge/database";
import env from "./env";
import { createSyncForgeMcpHandler } from "./mcp-handler";
import { createSyncForgeMcpToolset } from "./toolset";
import { withWideEvent } from "./utils/middleware";

const database = await createDatabase(env.DATABASE_URL, { maxConnections: env.DATABASE_POOL_MAX });

const { auth: baseAuth } = createAuth({
  database,
  secret: env.BETTER_AUTH_SECRET,
  baseUrl: env.BETTER_AUTH_URL,
  commercialMode: env.COMMERCIAL_MODE ?? false,
  mcpResourceUrl: env.MCP_PUBLIC_URL,
  mcpApiBaseUrl: env.MCP_API_URL,
});

if (!isSyncForgeMcpEnabledAuth(baseAuth)) {
  throw new Error("MCP auth is not configured — ensure mcpResourceUrl is set");
}

const auth = baseAuth;
const SyncForgeMcpToolset = createSyncForgeMcpToolset();
const handleMcpRequest = createSyncForgeMcpHandler({
  auth,
  mcpPublicUrl: env.MCP_PUBLIC_URL,
  apiBaseUrl: env.MCP_API_URL ?? env.BETTER_AUTH_URL,
  toolset: SyncForgeMcpToolset,
});

export { auth, database, env, handleMcpRequest, SyncForgeMcpToolset, withWideEvent };
