import { SyncForge_API_READ_SCOPE } from "@syncforge/auth";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js";
import type { SyncForgeMcpToolDefinition, SyncForgeMcpToolset, SyncForgeToolContext } from "./toolset";
import { widelog } from "./utils/logging";

const JSON_RPC_VERSION = "2.0";
const JSON_RPC_ERROR_UNAUTHORIZED = -32_001;
const JSON_RPC_ERROR_FORBIDDEN = -32_003;
const JSON_RPC_ERROR_METHOD_NOT_ALLOWED = -32_005;
const ALLOWED_HTTP_METHODS = new Set(["DELETE", "GET", "POST"]);
const ALLOW_HEADER_VALUE = "GET, POST, DELETE, OPTIONS";
type ResponseHeaders = Headers | Record<string, string>;

interface SyncForgeMcpAuthSession {
  scopes: string;
  userId: string | null;
}

interface AuthenticatedSyncForgeMcpSession {
  scopes: string;
  userId: string;
  bearerToken: string;
}

interface SyncForgeMcpAuth {
  api: {
    getMcpSession: (input: { headers: Headers }) => Promise<SyncForgeMcpAuthSession | null>;
  };
}

type McpSessionResolution =
  | {
    authenticated: true;
    session: AuthenticatedSyncForgeMcpSession;
  }
  | {
    authenticated: false;
  };

interface CreateSyncForgeMcpHandlerOptions {
  auth: SyncForgeMcpAuth;
  mcpPublicUrl: string;
  apiBaseUrl: string;
  toolset: SyncForgeMcpToolset;
  serverInfo?: {
    name: string;
    version: string;
  };
  enableJsonResponse?: boolean;
}

const hasScope = (scopes: string, requiredScope: string): boolean =>
  scopes
    .split(/\s+/)
    .filter((scope) => scope.length > 0)
    .includes(requiredScope);

const isAuthValidationError = (error: unknown): boolean =>
  error instanceof Error && error.name === "APIError";

const extractBearerToken = (headers: Headers): string | null => {
  const authHeader = headers.get("authorization");
  if (!authHeader) {
    return null;
  }

  if (!authHeader.startsWith("Bearer ")) {
    return null;
  }

  return authHeader.slice("Bearer ".length);
};

const resolveMcpSession = async (
  auth: SyncForgeMcpAuth,
  headers: Headers,
): Promise<McpSessionResolution> => {
  try {
    const session = await auth.api.getMcpSession({ headers });

    if (!session?.userId) {
      return { authenticated: false };
    }

    const bearerToken = extractBearerToken(headers);

    if (!bearerToken) {
      return { authenticated: false };
    }

    const authenticatedSession: AuthenticatedSyncForgeMcpSession = {
      scopes: session.scopes,
      userId: session.userId,
      bearerToken,
    };

    return {
      authenticated: true,
      session: authenticatedSession,
    };
  } catch (error) {
    if (isAuthValidationError(error)) {
      return { authenticated: false };
    }

    throw error;
  }
};

const createJsonRpcErrorResponse = (
  status: number,
  code: number,
  message: string,
  headers?: ResponseHeaders,
  details?: Record<string, unknown>,
): Response =>
  Response.json(
    {
      jsonrpc: JSON_RPC_VERSION,
      error: {
        code,
        message,
        ...(details && details),
      },
      id: null,
    },
    {
      status,
      headers,
    },
  );

const stringifyToolResult = (result: unknown): string => JSON.stringify(result, null, 2);

const createToolResponse = (result: unknown) => ({
  content: [
    {
      type: "text" as const,
      text: stringifyToolResult(result),
    },
  ],
});

const registerToolset = (
  server: McpServer,
  toolset: Record<string, SyncForgeMcpToolDefinition<unknown>>,
  toolContext: SyncForgeToolContext,
  userId: string,
): void => {
  for (const [name, tool] of Object.entries(toolset)) {
    server.registerTool(
      name,
      {
        annotations: tool.annotations,
        description: tool.description,
        inputSchema: tool.inputSchema,
        title: tool.title,
      },
      async (input: Record<string, unknown>) => {
        widelog.set("mcp.tool", name);
        widelog.set("user.id", userId);
        const result = await tool.execute(toolContext, input);
        return createToolResponse(result);
      },
    );
  }
};

const createAuthenticatedMcpServer = (
  toolset: SyncForgeMcpToolset,
  toolContext: SyncForgeToolContext,
  userId: string,
  serverInfo: { name: string; version: string },
): McpServer => {
  const server = new McpServer(serverInfo, {
    capabilities: {
      tools: {},
    },
  });

  const tools: Record<string, SyncForgeMcpToolDefinition<unknown>> = { ...toolset };
  registerToolset(server, tools, toolContext, userId);

  return server;
};

const createSyncForgeMcpHandler = ({
  auth,
  mcpPublicUrl,
  apiBaseUrl,
  toolset,
  serverInfo = {
    name: "SyncForge",
    version: "1.0.0",
  },
  enableJsonResponse = true,
}: CreateSyncForgeMcpHandlerOptions) => {
  const protectedResourceMetadataUrl = new URL(
    "/.well-known/oauth-protected-resource",
    mcpPublicUrl,
  ).toString();

  return async (request: Request): Promise<Response> => {
    if (!ALLOWED_HTTP_METHODS.has(request.method)) {
      return createJsonRpcErrorResponse(
        405,
        JSON_RPC_ERROR_METHOD_NOT_ALLOWED,
        "Method not allowed",
        {
          Allow: ALLOW_HEADER_VALUE,
        },
      );
    }

    const wwwAuthenticateHeader = `Bearer resource_metadata="${protectedResourceMetadataUrl}"`;

    const unauthorizedResponse = () =>
      createJsonRpcErrorResponse(
        401,
        JSON_RPC_ERROR_UNAUTHORIZED,
        "Unauthorized: Authentication required",
        {
          "Access-Control-Expose-Headers": "WWW-Authenticate",
          "WWW-Authenticate": wwwAuthenticateHeader,
          Allow: ALLOW_HEADER_VALUE,
        },
        {
          "www-authenticate": wwwAuthenticateHeader,
        },
      );

    const sessionResult = await resolveMcpSession(auth, request.headers);

    if (!sessionResult.authenticated) {
      return unauthorizedResponse();
    }

    const { userId, scopes, bearerToken } = sessionResult.session;

    if (!hasScope(scopes, SyncForge_API_READ_SCOPE)) {
      const insufficientScopeHeader =
        `${wwwAuthenticateHeader}, error="insufficient_scope", scope="${SyncForge_API_READ_SCOPE}"`;

      return createJsonRpcErrorResponse(
        403,
        JSON_RPC_ERROR_FORBIDDEN,
        "Forbidden: SyncForge.read scope is required",
        {
          "Access-Control-Expose-Headers": "WWW-Authenticate",
          "WWW-Authenticate": insufficientScopeHeader,
          Allow: ALLOW_HEADER_VALUE,
        },
        {
          "www-authenticate": insufficientScopeHeader,
        },
      );
    }

    const toolContext: SyncForgeToolContext = {
      bearerToken,
      apiBaseUrl,
    };

    const server = createAuthenticatedMcpServer(toolset, toolContext, userId, serverInfo);
    const transport = new WebStandardStreamableHTTPServerTransport({
      enableJsonResponse,
    });

    try {
      await server.connect(transport);
      return await transport.handleRequest(request);
    } finally {
      await transport.close();
      await server.close();
    }
  };
};

export { createSyncForgeMcpHandler };
export type { CreateSyncForgeMcpHandlerOptions, SyncForgeMcpAuth, SyncForgeMcpAuthSession };
