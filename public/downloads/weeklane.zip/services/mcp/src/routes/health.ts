import { withWideEvent } from "@/context";

const GET = withWideEvent(() =>
  Response.json({ service: "SyncForge-mcp", status: "ok" }),
);

export { GET };
