#!/bin/sh
set -e

export OTEL_SERVICE_NAME=SyncForge-mcp

exec bun services/mcp/dist/index.js 2>&1 | syncforge-otelemetry
