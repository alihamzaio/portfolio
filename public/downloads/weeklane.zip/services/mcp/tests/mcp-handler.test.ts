import { describe, expect, it } from "vitest";
import { z } from "zod";
import { createSyncForgeMcpHandler } from "../src/mcp-handler";
import { createSyncForgeMcpToolset } from "../src/toolset";

const toolset = createSyncForgeMcpToolset();

const listedToolSchema = z.object({
  name: z.string(),
  annotations: z.object({
    readOnlyHint: z.boolean(),
    destructiveHint: z.boolean().optional(),
    openWorldHint: z.boolean(),
  }),
});

const listToolsResultSchema = z.object({
  result: z.object({
    tools: z.array(listedToolSchema),
  }),
});

describe("createSyncForgeMcpHandler", () => {
  it("returns protected-resource metadata when authentication is missing", async () => {
    const handler = createSyncForgeMcpHandler({
      auth: {
        api: {
          getMcpSession: () => Promise.resolve(null),
        },
      },
      mcpPublicUrl: "https://mcp.SyncForge.com",
      apiBaseUrl: "https://SyncForge.com",
      toolset,
    });

    const response = await handler(
      new Request("https://mcp.SyncForge.com/mcp", {
        body: JSON.stringify({
          id: "1",
          jsonrpc: "2.0",
          method: "tools/list",
        }),
        headers: {
          "Content-Type": "application/json",
        },
        method: "POST",
      }),
    );

    expect(response.status).toBe(401);
    expect(response.headers.get("WWW-Authenticate")).toContain(
      'resource_metadata="https://mcp.SyncForge.com/.well-known/oauth-protected-resource"',
    );
  });

  it("supports unauthenticated GET with an OAuth challenge instead of 405", async () => {
    const handler = createSyncForgeMcpHandler({
      auth: {
        api: {
          getMcpSession: () => Promise.resolve(null),
        },
      },
      mcpPublicUrl: "https://mcp.SyncForge.com",
      apiBaseUrl: "https://SyncForge.com",
      toolset,
    });

    const response = await handler(
      new Request("https://mcp.SyncForge.com/mcp", {
        method: "GET",
      }),
    );

    expect(response.status).toBe(401);
    expect(response.headers.get("WWW-Authenticate")).toContain(
      'resource_metadata="https://mcp.SyncForge.com/.well-known/oauth-protected-resource"',
    );
  });

  it("returns insufficient scope metadata when SyncForge.read is missing", async () => {
    const handler = createSyncForgeMcpHandler({
      auth: {
        api: {
          getMcpSession: () => Promise.resolve({
            scopes: "openid profile",
            userId: "user-123",
          }),
        },
      },
      mcpPublicUrl: "https://mcp.SyncForge.com",
      apiBaseUrl: "https://SyncForge.com",
      toolset,
    });

    const response = await handler(
      new Request("https://mcp.SyncForge.com/mcp", {
        body: JSON.stringify({
          id: "1",
          jsonrpc: "2.0",
          method: "tools/list",
        }),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer test-token",
        },
        method: "POST",
      }),
    );

    expect(response.status).toBe(403);
    expect(response.headers.get("WWW-Authenticate")).toContain('error="insufficient_scope"');
    expect(response.headers.get("WWW-Authenticate")).toContain('scope="SyncForge.read"');
  });

  it("returns unauthorized challenge when token verification throws", async () => {
    const authValidationError = new Error("invalid token");
    authValidationError.name = "APIError";

    const handler = createSyncForgeMcpHandler({
      auth: {
        api: {
          getMcpSession: () => Promise.reject(authValidationError),
        },
      },
      mcpPublicUrl: "https://mcp.SyncForge.com",
      apiBaseUrl: "https://SyncForge.com",
      toolset,
    });

    const response = await handler(
      new Request("https://mcp.SyncForge.com/mcp", {
        method: "GET",
      }),
    );

    expect(response.status).toBe(401);
    expect(response.headers.get("WWW-Authenticate")).toContain(
      'resource_metadata="https://mcp.SyncForge.com/.well-known/oauth-protected-resource"',
    );
  });

  it("lists every tool with its annotations", async () => {
    const handler = createSyncForgeMcpHandler({
      auth: {
        api: {
          getMcpSession: () => Promise.resolve({
            scopes: "SyncForge.read",
            userId: "user-123",
          }),
        },
      },
      mcpPublicUrl: "https://mcp.SyncForge.com",
      apiBaseUrl: "https://SyncForge.com",
      toolset,
    });

    const response = await handler(
      new Request("https://mcp.SyncForge.com/mcp", {
        body: JSON.stringify({
          id: "1",
          jsonrpc: "2.0",
          method: "tools/list",
        }),
        headers: {
          "Accept": "application/json, text/event-stream",
          "Authorization": "Bearer test-token",
          "Content-Type": "application/json",
        },
        method: "POST",
      }),
    );

    const { result } = listToolsResultSchema.parse(await response.json());
    const annotationsByName = new Map(
      result.tools.map((tool) => [tool.name, tool.annotations]),
    );

    expect(annotationsByName.size).toBe(Object.keys(toolset).length);
    expect(annotationsByName.get("get_events")).toEqual({
      readOnlyHint: true,
      openWorldHint: false,
    });
    expect(annotationsByName.get("delete_event")).toEqual({
      readOnlyHint: false,
      destructiveHint: true,
      openWorldHint: false,
    });
  });

  it("rethrows unexpected session errors", async () => {
    const handler = createSyncForgeMcpHandler({
      auth: {
        api: {
          getMcpSession: () => Promise.reject(new Error("database unavailable")),
        },
      },
      mcpPublicUrl: "https://mcp.SyncForge.com",
      apiBaseUrl: "https://SyncForge.com",
      toolset,
    });

    await expect(
      handler(
        new Request("https://mcp.SyncForge.com/mcp", {
          method: "GET",
        }),
      ),
    ).rejects.toThrow("database unavailable");
  });
});
