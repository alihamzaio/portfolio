import { describe, expect, it } from "vitest";
import { sourceMapFromSources } from "../../src/queries/get-events-in-range";
import type { SyncForgeSource } from "../../src/types";

const source = (overrides: Partial<SyncForgeSource> & { id: string; capabilities: string[] }): SyncForgeSource => ({
  accountId: "account-1",
  accountIdentifier: "team@example.com",
  accountLabel: "Example",
  calendarType: "ics",
  companyColor: null,
  companyLabel: "Example",
  disabled: false,
  displayName: "Example",
  email: "team@example.com",
  includeInIcalFeed: false,
  name: "Meetings",
  needsReauthentication: false,
  provider: "ics",
  providerIcon: null,
  providerMissingSince: null,
  providerName: "ICS",
  timeZone: null,
  unavailableSince: null,
  userId: "user-1",
  ...overrides,
});

describe("sourceMapFromSources", () => {
  it("keeps pull calendars and skips write-only ones", () => {
    const map = sourceMapFromSources([
      source({ capabilities: ["pull"], id: "cal-pull", name: "Readable" }),
      source({ capabilities: ["push"], id: "cal-push", name: "Write only" }),
    ]);

    expect([...map.keys()]).toEqual(["cal-pull"]);
    expect(map.get("cal-pull")).toEqual({
      name: "Readable",
      provider: "ics",
      url: null,
      userId: "user-1",
    });
  });
});
