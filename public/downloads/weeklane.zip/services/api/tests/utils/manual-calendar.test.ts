import { describe, expect, it } from "vitest";
import {
  companyNameFromUser,
  isWritableSource,
  MANUAL_PROVIDER,
} from "../../src/utils/manual-calendar";

describe("companyNameFromUser", () => {
  it("uses the signed-in display name", () => {
    expect(
      companyNameFromUser({ email: "ada@company.test", name: "Ada Lovelace", username: "ada" }),
    ).toBe("Ada Lovelace");
  });

  it("falls back to username, then the email local part", () => {
    expect(companyNameFromUser({ email: "ada@company.test", name: "  ", username: "ada" })).toBe(
      "ada",
    );
    expect(companyNameFromUser({ email: "ada@company.test", name: "", username: null })).toBe("ada");
  });
});

describe("isWritableSource", () => {
  it("treats the SyncForge calendar as writable", () => {
    expect(isWritableSource({
      capabilities: ["pull"],
      disabled: false,
      provider: MANUAL_PROVIDER,
    })).toBe(true);
  });

  it("treats a push-capable Google calendar as writable", () => {
    expect(isWritableSource({
      capabilities: ["pull", "push"],
      disabled: false,
      provider: "google",
    })).toBe(true);
  });

  it("does not treat an ICS feed as writable", () => {
    expect(isWritableSource({
      capabilities: ["pull"],
      disabled: false,
      provider: "ics",
    })).toBe(false);
  });

  it("does not treat a paused calendar as writable", () => {
    expect(isWritableSource({
      capabilities: ["pull", "push"],
      disabled: true,
      provider: "google",
    })).toBe(false);
  });
});
