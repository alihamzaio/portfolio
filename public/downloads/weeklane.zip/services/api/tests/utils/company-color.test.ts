import { describe, expect, it } from "vitest";

import { parseCompanyColor } from "@/utils/company-color";

describe("parseCompanyColor", () => {
  it("normalises a six-digit hex colour", () => {
    expect(parseCompanyColor("#2F6FED")).toEqual({ ok: true, color: "#2f6fed" });
  });

  it("expands a three-digit hex colour", () => {
    expect(parseCompanyColor("#0a8")).toEqual({ ok: true, color: "#00aa88" });
  });

  it("clears the colour when the value is blank", () => {
    expect(parseCompanyColor("  ")).toEqual({ ok: true, color: null });
  });

  it("rejects a value that is not a hex colour", () => {
    expect(parseCompanyColor("blue")).toEqual({
      error: "Use a hex color such as #2f6fed.",
      ok: false,
    });
  });
});
