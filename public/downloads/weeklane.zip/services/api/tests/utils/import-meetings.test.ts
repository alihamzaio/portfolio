import { describe, expect, it } from "vitest";
import { filterNewMeetings, meetingDuplicateKey, previewIcsMeetings } from "../../src/utils/import-meetings";

const SAMPLE_ICS = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//SyncForge//Test//EN
BEGIN:VEVENT
UID:standup-1
DTSTART:20260907T081500Z
DTEND:20260907T084500Z
SUMMARY:Daily Stand Up
END:VEVENT
BEGIN:VEVENT
UID:empty-title
DTSTART:20260907T100000Z
DTEND:20260907T110000Z
SUMMARY:
END:VEVENT
END:VCALENDAR
`;

describe("previewIcsMeetings", () => {
  it("returns timed events with titles from an ICS document", () => {
    const meetings = previewIcsMeetings(SAMPLE_ICS);
    expect(meetings).toHaveLength(1);
    expect(meetings[0]?.title).toBe("Daily Stand Up");
    expect(meetings[0]?.startTime).toBe("2026-09-07T08:15:00.000Z");
    expect(meetings[0]?.endTime).toBe("2026-09-07T08:45:00.000Z");
  });

  it("throws when the body is not an iCalendar document", () => {
    expect(() => previewIcsMeetings("not a calendar")).toThrow(/BEGIN:VCALENDAR/);
  });
});

describe("meetingDuplicateKey", () => {
  it("treats the same title and start as one meeting", () => {
    expect(meetingDuplicateKey("Standup", "2026-09-07T08:15:00.000Z")).toBe(
      meetingDuplicateKey(" standup ", "2026-09-07T08:15:00.000Z"),
    );
  });
});

describe("filterNewMeetings", () => {
  it("skips meetings already on the calendar and duplicates in the batch", () => {
    const existing = [{ startTime: new Date("2026-09-07T08:15:00.000Z"), title: "Daily Stand Up" }];
    const { next, skipped } = filterNewMeetings(
      [
        {
          endTime: "2026-09-07T08:45:00.000Z",
          startTime: "2026-09-07T08:15:00.000Z",
          title: "Daily Stand Up",
        },
        {
          endTime: "2026-09-07T10:00:00.000Z",
          startTime: "2026-09-07T09:30:00.000Z",
          title: "Sprint Retro",
        },
        {
          endTime: "2026-09-07T10:00:00.000Z",
          startTime: "2026-09-07T09:30:00.000Z",
          title: "Sprint Retro",
        },
      ],
      existing,
    );

    expect(skipped).toBe(2);
    expect(next).toHaveLength(1);
    expect(next[0]?.title).toBe("Sprint Retro");
  });
});
