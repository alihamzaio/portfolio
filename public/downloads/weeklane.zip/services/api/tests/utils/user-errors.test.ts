import { describe, expect, it } from "vitest";

import { createUserFailureMessage, parsePassword } from "@/utils/user-errors";

describe("createUserFailureMessage", () => {
  it("says the email is already used when sign-up reports a taken address", () => {
    expect(createUserFailureMessage({ message: "email already taken" })).toBe(
      "That email is already used.",
    );
    expect(createUserFailureMessage({ error: "That email is already in use." })).toBe(
      "That email is already used.",
    );
  });

  it("falls back when the failure is something else", () => {
    expect(createUserFailureMessage({ message: "username can only contain letters" })).toBe(
      "Could not create that user.",
    );
    expect(createUserFailureMessage(null)).toBe("Could not create that user.");
  });
});

describe("parsePassword", () => {
  it("accepts a password of at least eight characters", () => {
    expect(parsePassword("long-enough")).toEqual({ ok: true, password: "long-enough" });
  });

  it("rejects a short or missing password", () => {
    expect(parsePassword("short")).toEqual({
      error: "Password must be at least 8 characters.",
      ok: false,
    });
    expect(parsePassword(undefined)).toEqual({
      error: "Password is required.",
      ok: false,
    });
  });
});
