import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  meetingsFromPdfExtract,
  parseOutlookMonthCells,
  parseOutlookMonthGrid,
  parseOutlookPrintText,
  type OcrWord,
} from "../../../../applications/dashboard/lib/parse-outlook-print";

const ZONE = "Asia/Karachi";

describe("parseOutlookPrintText", () => {
  it("reads a weekly Outlook agenda with one date heading per day", () => {
    const text = `
Monday 7 September 2026
12:00 PM Sprint Planning
1:15 PM Daily Stand Up - Product Delivery
Friday 11 September 2026
9:00 AM - 10:30 AM Sprint Retro
`;

    const meetings = parseOutlookPrintText(text, ZONE);

    expect(meetings.map((meeting) => meeting.title)).toEqual([
      "Sprint Planning",
      "Daily Stand Up - Product Delivery",
      "Sprint Retro",
    ]);
    expect(new Date(meetings[0]?.startTime ?? "").toISOString()).toBe("2026-09-07T07:00:00.000Z");
    expect(new Date(meetings[0]?.endTime ?? "").toISOString()).toBe("2026-09-07T07:30:00.000Z");
    expect(new Date(meetings[2]?.startTime ?? "").toISOString()).toBe("2026-09-11T04:00:00.000Z");
    expect(new Date(meetings[2]?.endTime ?? "").toISOString()).toBe("2026-09-11T05:30:00.000Z");
  });

  it("skips canceled rows", () => {
    const text = `
Monday 7 September 2026
12:00 PM Canceled: Sprint Planning
1:00 PM Team sync
`;
    expect(parseOutlookPrintText(text, ZONE).map((meeting) => meeting.title)).toEqual(["Team sync"]);
  });

  it("returns nothing when the print has no times", () => {
    expect(parseOutlookPrintText("Outlook Calendar\nWork week", ZONE)).toEqual([]);
  });

  it("reads a US-style Outlook date heading", () => {
    const text = `
Monday, September 7, 2026
1:15 PM Daily Stand Up
`;
    const meetings = parseOutlookPrintText(text, ZONE);
    expect(meetings).toHaveLength(1);
    expect(meetings[0]?.title).toBe("Daily Stand Up");
    expect(new Date(meetings[0]?.startTime ?? "").toISOString()).toBe("2026-09-07T08:15:00.000Z");
  });

  it("reads OCR-style times and a title on the next line", () => {
    const text = `
Monday 7 Sep 2026
1:15PM
Daily Stand Up
2.00 PM - 2:30 PM Sprint Retro
`;
    const meetings = parseOutlookPrintText(text, ZONE);
    expect(meetings.map((meeting) => meeting.title)).toEqual(["Daily Stand Up", "Sprint Retro"]);
  });

  it("reads a monthly grid from OCR word positions", () => {
    const word = (text: string, x0: number, y0: number): OcrWord => ({
      text,
      x0,
      x1: x0 + Math.max(8, text.length * 8),
      y0,
      y1: y0 + 16,
    });
    const words: OcrWord[] = [
      word("September", 28, 48),
      word("2026", 140, 48),
      word("Monday", 21, 151),
      word("Tuesday", 190, 151),
      word("Wednesday", 355, 151),
      word("Thursday", 524, 151),
      word("Friday", 697, 151),
      word("Saturday", 862, 151),
      word("Sunday", 1035, 151),
      word("31", 21, 176),
      word("Aug", 40, 176),
      word("1", 191, 176),
      word("02", 359, 176),
      word("03", 528, 176),
      word("04", 693, 176),
      word("05", 865, 176),
      word("06", 1034, 176),
      word("1:15", 21, 218),
      word("PM", 60, 218),
      word("Daily", 90, 218),
      word("Stand", 130, 218),
      word("Up", 170, 218),
      word("1:15", 194, 218),
      word("PM", 230, 218),
      word("Daily", 260, 218),
      word("Stand", 300, 218),
      word("Up", 340, 218),
      word("3", 355, 240),
      word("PM", 375, 240),
      word("CMT", 400, 240),
      word("Refinement", 430, 240),
    ];

    const meetings = parseOutlookMonthGrid(words, ZONE);
    expect(meetings.map((meeting) => meeting.title)).toEqual([
      "Daily Stand Up",
      "Daily Stand Up",
      "CMT Refinement",
    ]);
    expect(new Date(meetings[0]?.startTime ?? "").toISOString()).toBe("2026-08-31T08:15:00.000Z");
    expect(new Date(meetings[1]?.startTime ?? "").toISOString()).toBe("2026-09-01T08:15:00.000Z");
    expect(new Date(meetings[2]?.startTime ?? "").toISOString()).toBe("2026-09-02T10:00:00.000Z");
  });

  it("reads a month grid from per-cell OCR and skips canceled rows", () => {
    const cell = (week: number, column: number, text: string) => ({ column, text, week });
    const cells = [
      cell(0, 0, "31 Aug\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(0, 1, "1 Sep\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(0, 2, "02\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up\n3 PM CMT - User Story Ref"),
      cell(0, 3, "03\n1 PM Canceled: CMT Daily"),
      cell(0, 4, "04\n12 PM Sprint Retrospective\n1 PM Canceled: CMT Daily\n1:15 PM Canceled: Daily"),
      cell(0, 5, "05"),
      cell(0, 6, "06"),
      cell(1, 0, "07\n12 PM Canceled: Sprint\n1 PM Canceled: Finalize\n1:15 PM Canceled: Daily"),
      cell(1, 1, "08\n12:45 PM Sprint Plannin\n1 PM Canceled: CMT Daily\n1:15 PM Canceled: Daily"),
      cell(1, 2, "09\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(1, 3, "10\n1 PM Canceled: CMT Daily"),
      cell(1, 4, "11\n12 PM Canceled: Team Icebreaker\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up\n3:30 PM Team Icebreaker"),
      cell(1, 5, "12"),
      cell(1, 6, "13"),
      cell(2, 0, "14\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(2, 1, "15\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(2, 2, "16\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(2, 3, "17\n1 PM Canceled: CMT Daily"),
      cell(2, 4, "18\n12 PM Sprint Retrospective\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(3, 0, "21\n12 PM Canceled: Sprint\n12:45 PM Sprint Planning\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(3, 1, "22\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(3, 2, "23\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(3, 4, "25\n12 PM Canceled: Team Icebreaker\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up\n3:30 PM Team Icebreaker"),
      cell(4, 0, "28\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(4, 1, "29\n1 PM Canceled: CMT Daily\n1:15 PM Daily stand up"),
      cell(4, 2, "30\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up"),
      cell(4, 3, "1 Oct\n1 PM Canceled: CMT Daily"),
      cell(4, 4, "02\n12 PM Sprint Retrospect\n1 PM Canceled: CMT Daily\n1:15 PM Daily Stand Up i"),
    ];

    const meetings = parseOutlookMonthCells(cells, "September 2026 Calendar", ZONE);
    const labels = meetings.map((meeting) => {
      const start = new Date(meeting.startTime);
      const minutes = String(start.getUTCMinutes()).padStart(2, "0");
      const hour = start.getUTCHours() + 5;
      return `${start.toISOString().slice(0, 10)} ${hour}:${minutes} ${meeting.title}`;
    });

    expect(labels).toEqual([
      "2026-08-31 13:15 Daily Stand Up",
      "2026-09-01 13:15 Daily Stand Up",
      "2026-09-02 13:15 Daily Stand Up",
      "2026-09-02 15:00 CMT - User Story Ref",
      "2026-09-04 12:00 Sprint Retrospective",
      "2026-09-08 12:45 Sprint Planning",
      "2026-09-09 13:15 Daily Stand Up",
      "2026-09-11 13:15 Daily Stand Up",
      "2026-09-11 15:30 Team Icebreaker",
      "2026-09-14 13:15 Daily Stand Up",
      "2026-09-15 13:15 Daily Stand Up",
      "2026-09-16 13:15 Daily Stand Up",
      "2026-09-18 12:00 Sprint Retrospective",
      "2026-09-18 13:15 Daily Stand Up",
      "2026-09-21 12:45 Sprint Planning",
      "2026-09-21 13:15 Daily Stand Up",
      "2026-09-22 13:15 Daily Stand Up",
      "2026-09-23 13:15 Daily Stand Up",
      "2026-09-25 13:15 Daily Stand Up",
      "2026-09-25 15:30 Team Icebreaker",
      "2026-09-28 13:15 Daily Stand Up",
      "2026-09-29 13:15 Daily Stand Up",
      "2026-09-30 13:15 Daily Stand Up",
      "2026-10-02 12:00 Sprint Retrospective",
      "2026-10-02 13:15 Daily Stand Up",
    ]);
  });

  it("prefers per-cell OCR over mixed whole-page text", () => {
    const meetings = meetingsFromPdfExtract(
      "Monday 1 September 2026\n1:00 PM Wrong meeting",
      [],
      ZONE,
      [{ column: 1, text: "1 Sep\n1:15 PM Daily Stand Up", week: 0 }],
    );
    expect(meetings).toHaveLength(1);
    expect(meetings[0]?.title).toBe("Daily Stand Up");
    expect(new Date(meetings[0]?.startTime ?? "").toISOString()).toBe("2026-09-01T08:15:00.000Z");
  });

  it("reads 12M as 12 PM from OCR", () => {
    const meetings = parseOutlookMonthCells(
      [{ column: 4, text: "04\n12M Sprint Retrospect", week: 0 }],
      "September 2026",
      ZONE,
    );
    expect(meetings).toHaveLength(1);
    expect(meetings[0]?.title).toBe("Sprint Retrospective");
    expect(new Date(meetings[0]?.startTime ?? "").toISOString()).toBe("2026-09-04T07:00:00.000Z");
  });

  it("repairs common Outlook OCR time and title mistakes", () => {
    const meetings = parseOutlookMonthCells(
      [
        { column: 0, text: "14\n1615 pM Daily Stand Up", week: 2 },
        { column: 4, text: "18\n12 PM Sprint Retrospective\n2:15PM Daity Stand Up", week: 2 },
        { column: 0, text: "21\n12 PM Canceled: Sprint\n155 ss Prin\n1:15 Prt Daily Stand Up", week: 3 },
        { column: 1, text: "22\n1PM Canceled: CMT Da\n1:15 Pr Daily Stand Up", week: 3 },
        { column: 4, text: "11\n330 PM Tear Icebreakee", week: 1 },
        { column: 0, text: "28\n1:15.PM Baily Stand up", week: 4 },
      ],
      "September 2026",
      ZONE,
    );
    expect(meetings.map((meeting) => `${meeting.startTime.slice(0, 16)} ${meeting.title}`)).toEqual([
      "2026-09-11T10:30 Team Icebreaker",
      "2026-09-14T08:15 Daily Stand Up",
      "2026-09-18T07:00 Sprint Retrospective",
      "2026-09-18T08:15 Daily Stand Up",
      "2026-09-21T07:45 Sprint Planning",
      "2026-09-21T08:15 Daily Stand Up",
      "2026-09-22T08:15 Daily Stand Up",
      "2026-09-28T08:15 Daily Stand Up",
    ]);
  });

  it("matches the September 2026 Outlook month PDF, skipping canceled rows", () => {
    const fixture = JSON.parse(
      readFileSync(join(dirname(fileURLToPath(import.meta.url)), "outlook-september-2026-ocr.json"), "utf8"),
    ) as { cells: { column: number; text: string; week: number }[]; pageText: string };
    const meetings = meetingsFromPdfExtract(fixture.pageText, [], ZONE, fixture.cells);
    expect(
      meetings.map((meeting) => {
        const start = new Date(meeting.startTime);
        const hour = start.getUTCHours() + 5;
        const minutes = String(start.getUTCMinutes()).padStart(2, "0");
        return `${meeting.startTime.slice(0, 10)} ${hour}:${minutes} ${meeting.title}`;
      }),
    ).toEqual([
      "2026-08-31 13:15 Daily Stand Up",
      "2026-09-01 13:15 Daily Stand Up",
      "2026-09-02 13:15 Daily Stand Up",
      "2026-09-02 15:00 CMT - User Story Ref",
      "2026-09-04 12:00 Sprint Retrospective",
      "2026-09-08 12:45 Sprint Planning",
      "2026-09-09 13:15 Daily Stand Up",
      "2026-09-11 13:15 Daily Stand Up",
      "2026-09-11 15:30 Team Icebreaker",
      "2026-09-14 13:15 Daily Stand Up",
      "2026-09-15 13:15 Daily Stand Up",
      "2026-09-16 13:15 Daily Stand Up",
      "2026-09-18 12:00 Sprint Retrospective",
      "2026-09-18 13:15 Daily Stand Up",
      "2026-09-21 12:45 Sprint Planning",
      "2026-09-21 13:15 Daily Stand Up",
      "2026-09-22 13:15 Daily Stand Up",
      "2026-09-23 13:15 Daily Stand Up",
      "2026-09-25 13:15 Daily Stand Up",
      "2026-09-25 15:30 Team Icebreaker",
      "2026-09-28 13:15 Daily Stand Up",
      "2026-09-29 13:15 Daily Stand Up",
      "2026-09-30 13:15 Daily Stand Up",
      "2026-10-02 12:00 Sprint Retrospective",
      "2026-10-02 13:15 Daily Stand Up",
    ]);
  });
});
