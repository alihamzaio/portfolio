import { describe, expect, it } from "vitest";

import {
  promoteIfNoAdmin,
  userIdFromAuthPayload,
} from "@/utils/first-admin";

describe("userIdFromAuthPayload", () => {
  it("reads the created user id from a username-only auth response", () => {
    expect(userIdFromAuthPayload({ session: {}, user: { id: "user-1" } })).toBe("user-1");
  });

  it("returns null when the payload has no user id", () => {
    expect(userIdFromAuthPayload({ user: { email: "ada@company.com" } })).toBeNull();
    expect(userIdFromAuthPayload(null)).toBeNull();
  });
});

describe("promoteIfNoAdmin", () => {
  it("promotes the user when the instance has no administrator", async () => {
    const promoted: string[] = [];

    await expect(
      promoteIfNoAdmin(
        {
          hasAdmin: () => Promise.resolve(false),
          setAdmin: (userId) => {
            promoted.push(userId);
            return Promise.resolve();
          },
        },
        "user-1",
      ),
    ).resolves.toBe(true);

    expect(promoted).toEqual(["user-1"]);
  });

  it("leaves existing administrators in place", async () => {
    const promoted: string[] = [];

    await expect(
      promoteIfNoAdmin(
        {
          hasAdmin: () => Promise.resolve(true),
          setAdmin: (userId) => {
            promoted.push(userId);
            return Promise.resolve();
          },
        },
        "user-1",
      ),
    ).resolves.toBe(false);

    expect(promoted).toEqual([]);
  });
});
