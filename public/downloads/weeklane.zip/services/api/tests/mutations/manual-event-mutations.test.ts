import { beforeEach, describe, expect, it, vi } from "vitest";
import type { EventInput, ProviderCredentials } from "../../src/types";

const resolveCredentialsByCalendarId = vi.fn();
const resolveCredentialsByEventId = vi.fn();
const getEvent = vi.fn();

vi.mock("../../src/mutations/resolve-credentials", () => ({
  resolveCredentialsByCalendarId: (...args: unknown[]) => resolveCredentialsByCalendarId(...args),
  resolveCredentialsByEventId: (...args: unknown[]) => resolveCredentialsByEventId(...args),
}));

vi.mock("../../src/queries/get-event", () => ({
  getEvent: (...args: unknown[]) => getEvent(...args),
}));

vi.mock("../../src/mutations/providers/google", () => ({
  createGoogleEvent: vi.fn(),
  updateGoogleEvent: vi.fn(),
  deleteGoogleEvent: vi.fn(),
  rsvpGoogleEvent: vi.fn(),
  getPendingGoogleInvites: vi.fn(),
}));

const { createGoogleEvent } = await import("../../src/mutations/providers/google");
const { createEventMutation, updateEventMutation, deleteEventMutation } = await import(
  "../../src/mutations/index"
);

const USER_ID = "user-1";
const CALENDAR_ID = "019c0000-0000-7000-8000-00000000a001";
const EVENT_ID = "019c0000-0000-7000-8000-00000000e001";

const manualCredentials = (): ProviderCredentials => ({
  accountId: "account-manual",
  calendarId: CALENDAR_ID,
  calendarUrl: null,
  email: null,
  externalCalendarId: null,
  provider: "manual",
});

const googleCredentials = (): ProviderCredentials => ({
  accountId: "account-google",
  calendarId: CALENDAR_ID,
  calendarUrl: null,
  email: "ada@company.test",
  externalCalendarId: "primary",
  oauth: {
    accessToken: "access",
    credentialId: "cred-1",
    expiresAt: new Date(Date.now() + 3_600_000),
    refreshToken: "refresh",
  },
  provider: "google",
});

const input: EventInput = {
  calendarId: CALENDAR_ID,
  endTime: "2026-09-10T11:00:00.000Z",
  startTime: "2026-09-10T10:00:00.000Z",
  title: "Standup",
};

const createInsertDatabase = (insertedId: string) => {
  const values = vi.fn();
  const returning = vi.fn().mockResolvedValue([{ id: insertedId }]);
  values.mockReturnValue({ returning });
  return {
    insert: vi.fn().mockReturnValue({ values }),
    values,
  };
};

describe("manual event mutations", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("creates a local event without calling Google", async () => {
    resolveCredentialsByCalendarId.mockResolvedValue(manualCredentials());
    const created = { id: EVENT_ID, title: "Standup" };
    getEvent.mockResolvedValue(created);
    const database = createInsertDatabase(EVENT_ID);

    const result = await createEventMutation({ database: database as never }, USER_ID, input);

    expect(createGoogleEvent).not.toHaveBeenCalled();
    expect(database.values).toHaveBeenCalledWith(
      expect.objectContaining({
        calendarId: CALENDAR_ID,
        sourceEventUid: null,
        title: "Standup",
        userId: USER_ID,
      }),
    );
    expect(result).toEqual({ event: created, success: true });
  });

  it("still asks Google before inserting when the calendar is a Google source", async () => {
    resolveCredentialsByCalendarId.mockResolvedValue(googleCredentials());
    vi.mocked(createGoogleEvent).mockResolvedValue({
      sourceEventUid: "google-uid",
      success: true,
    });
    getEvent.mockResolvedValue({ id: EVENT_ID });
    const database = createInsertDatabase(EVENT_ID);

    await createEventMutation({ database: database as never }, USER_ID, input);

    expect(createGoogleEvent).toHaveBeenCalled();
    expect(database.values).toHaveBeenCalledWith(
      expect.objectContaining({ sourceEventUid: "google-uid" }),
    );
  });

  it("updates a manual event in the database when it has no source UID", async () => {
    resolveCredentialsByEventId.mockResolvedValue({
      credentials: manualCredentials(),
      eventSource: "user",
      occurrenceStart: null,
      sourceEventId: null,
      sourceEventUid: null,
    });
    const set = vi.fn().mockReturnValue({ where: vi.fn().mockResolvedValue(undefined) });
    const database = {
      select: vi.fn().mockReturnValue({
        from: () => ({
          where: () => ({
            limit: () => Promise.resolve([
              {
                endTime: new Date(input.endTime),
                startTime: new Date(input.startTime),
              },
            ]),
          }),
        }),
      }),
      update: vi.fn().mockReturnValue({ set }),
    };

    const result = await updateEventMutation(
      { database: database as never },
      USER_ID,
      EVENT_ID,
      { title: "Renamed" },
    );

    expect(result).toEqual({ success: true });
    expect(set).toHaveBeenCalledWith({ title: "Renamed" });
  });

  it("refuses to update a synced event", async () => {
    resolveCredentialsByEventId.mockResolvedValue({
      credentials: googleCredentials(),
      eventSource: "synced",
      occurrenceStart: null,
      sourceEventId: "g-1",
      sourceEventUid: "uid-1",
    });

    const result = await updateEventMutation(
      { database: {} as never },
      USER_ID,
      EVENT_ID,
      { title: "Nope" },
    );

    expect(result.success).toBe(false);
    expect(result.error).toMatch(/Synced events cannot be updated/);
  });

  it("deletes a manual event from the database", async () => {
    resolveCredentialsByEventId.mockResolvedValue({
      credentials: manualCredentials(),
      eventSource: "user",
      occurrenceStart: null,
      sourceEventId: null,
      sourceEventUid: null,
    });
    const where = vi.fn().mockResolvedValue(undefined);
    const database = {
      delete: vi.fn().mockReturnValue({ where }),
    };

    const result = await deleteEventMutation({ database: database as never }, USER_ID, EVENT_ID);

    expect(result).toEqual({ success: true });
    expect(database.delete).toHaveBeenCalled();
  });
});
