import { user as userTable } from "@syncforge/database/auth-schema";
import { calendarAccountsTable, calendarsTable } from "@syncforge/database/schema";
import { and, eq, sql } from "drizzle-orm";
import {
  createSourceCalendarInsertDependencies,
  insertSourceCalendars,
} from "./source-calendar-insert";
import type { SyncForgeDatabase } from "@/types";

const USER_MANUAL_CALENDAR_LOCK_NAMESPACE = 9003;
const MANUAL_PROVIDER = "manual";
const MANUAL_CALENDAR_TYPE = "manual";
const MANUAL_CALENDAR_NAME = "My events";
const FIRST_RESULT_LIMIT = 1;

interface ManualCalendar {
  id: string;
  name: string;
}

interface ManualCalendarRow extends ManualCalendar {
  accountId: string;
  companyLabel: string | null;
}

const companyNameFromUser = (user: {
  email: string | null;
  name: string | null;
  username: string | null;
}): string => {
  const name = user.name?.trim() ?? "";
  if (name.length > 0) {
    return name;
  }
  const username = user.username?.trim() ?? "";
  if (username.length > 0) {
    return username;
  }
  const local = (user.email ?? "").split("@")[0]?.trim() ?? "";
  return local.length > 0 ? local : MANUAL_CALENDAR_NAME;
};

const findManualCalendar = async (
  client: Pick<SyncForgeDatabase, "select">,
  userId: string,
): Promise<ManualCalendarRow | null> => {
  const [existing] = await client
    .select({
      accountId: calendarAccountsTable.id,
      companyLabel: calendarAccountsTable.companyLabel,
      id: calendarsTable.id,
      name: calendarsTable.name,
    })
    .from(calendarsTable)
    .innerJoin(calendarAccountsTable, eq(calendarsTable.accountId, calendarAccountsTable.id))
    .where(
      and(
        eq(calendarsTable.userId, userId),
        eq(calendarsTable.calendarType, MANUAL_CALENDAR_TYPE),
        eq(calendarAccountsTable.provider, MANUAL_PROVIDER),
      ),
    )
    .limit(FIRST_RESULT_LIMIT);

  if (!existing) {
    return null;
  }
  return existing;
};

const createManualCalendar = async (
  client: Pick<SyncForgeDatabase, "insert" | "select">,
  userId: string,
  companyName: string,
): Promise<ManualCalendar> => {
  const [account] = await client
    .insert(calendarAccountsTable)
    .values({
      authType: "none",
      companyLabel: companyName,
      displayName: companyName,
      provider: MANUAL_PROVIDER,
      userId,
    })
    .returning({ id: calendarAccountsTable.id });

  if (!account) {
    throw new Error("Failed to create the Weeklane events calendar account.");
  }

  const [calendar] = await insertSourceCalendars(
    createSourceCalendarInsertDependencies(client),
    userId,
    [{
      accountId: account.id,
      calendarType: MANUAL_CALENDAR_TYPE,
      capabilities: ["pull"],
      name: MANUAL_CALENDAR_NAME,
      userId,
    }],
  );

  if (!calendar) {
    throw new Error("Failed to create the Weeklane events calendar.");
  }

  return { id: calendar.id, name: calendar.name };
};

const assignCompanyIfNeeded = async (
  client: Pick<SyncForgeDatabase, "update">,
  calendar: ManualCalendarRow,
  companyName: string,
): Promise<void> => {
  if ((calendar.companyLabel ?? "").trim().length > 0) {
    return;
  }
  await client
    .update(calendarAccountsTable)
    .set({
      companyLabel: companyName,
      displayName: companyName,
    })
    .where(eq(calendarAccountsTable.id, calendar.accountId));
};

const userCompanyName = async (
  client: Pick<SyncForgeDatabase, "select">,
  userId: string,
): Promise<string> => {
  const [account] = await client
    .select({
      email: userTable.email,
      name: userTable.name,
      username: userTable.username,
    })
    .from(userTable)
    .where(eq(userTable.id, userId))
    .limit(FIRST_RESULT_LIMIT);
  return companyNameFromUser(account ?? { email: null, name: null, username: null });
};

/**
 * Every signed-in account gets one local calendar to create meetings on. ICS feeds and
 * Google calendars stay as they are; this row is never ingested because cron only pulls
 * `calendarType = "ical"`. The account is named after the user so Everyone can tell
 * whose meetings they are.
 */
const ensureManualCalendar = async (
  database: SyncForgeDatabase,
  userId: string,
): Promise<ManualCalendar> =>
  database.transaction(async (tx) => {
    await tx.execute(
      sql`select pg_advisory_xact_lock(${USER_MANUAL_CALENDAR_LOCK_NAMESPACE}, hashtext(${userId}))`,
    );

    const companyName = await userCompanyName(tx, userId);
    const existing = await findManualCalendar(tx, userId);
    if (existing) {
      await assignCompanyIfNeeded(tx, existing, companyName);
      return { id: existing.id, name: existing.name };
    }

    return createManualCalendar(tx, userId, companyName);
  });

const isWritableSource = (source: {
  capabilities: string[];
  disabled: boolean;
  provider: string;
}): boolean => {
  if (source.disabled) {
    return false;
  }
  if (source.provider === MANUAL_PROVIDER) {
    return true;
  }
  return source.capabilities.includes("push");
};

export {
  companyNameFromUser,
  ensureManualCalendar,
  isWritableSource,
  MANUAL_CALENDAR_NAME,
  MANUAL_PROVIDER,
};
export type { ManualCalendar };
