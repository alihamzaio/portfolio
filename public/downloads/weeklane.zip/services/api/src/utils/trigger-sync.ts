import type { Plan } from "@syncforge/data-schemas";
import { calendarsTable } from "@syncforge/database/schema";
import { and, arrayContains, eq, isNotNull } from "drizzle-orm";
import type { SyncForgeSyncTriggerResult } from "@/types";
import { enqueuePushSync } from "./enqueue-push-sync";

interface TriggerSyncDependencies {
  clearIngestBackoff: (userId: string) => Promise<number>;
  enqueuePushSync: (userId: string, plan: Plan) => Promise<void>;
}

const runTriggerSync = async (
  userId: string,
  plan: Plan,
  dependencies: TriggerSyncDependencies,
): Promise<SyncForgeSyncTriggerResult> => {
  const sourcesRefreshed = await dependencies.clearIngestBackoff(userId);
  await dependencies.enqueuePushSync(userId, plan);

  return { sourcesRefreshed, triggered: true };
};

const triggerSync = async (userId: string, plan: Plan): Promise<SyncForgeSyncTriggerResult> => {
  const { database } = await import("@/context");

  return runTriggerSync(userId, plan, {
    clearIngestBackoff: async (backoffUserId) => {
      const cleared = await database
        .update(calendarsTable)
        .set({ ingestNextAttemptAt: null })
        .where(and(
          eq(calendarsTable.userId, backoffUserId),
          eq(calendarsTable.disabled, false),
          arrayContains(calendarsTable.capabilities, ["pull"]),
          isNotNull(calendarsTable.ingestNextAttemptAt),
        ))
        .returning({ id: calendarsTable.id });

      return cleared.length;
    },
    enqueuePushSync,
  });
};

export { runTriggerSync, triggerSync };
export type { TriggerSyncDependencies };
