const HEX_COLOUR = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
const INVALID_COLOUR = "Use a hex color such as #2f6fed.";

type ParsedCompanyColor =
  | { ok: true; color: string | null }
  | { ok: false; error: string };

/**
 * Operator-chosen meeting colour for a company calendar. Stored as lowercase #rrggbb so
 * every surface -- admin picker, signed-in schedule, public page -- reads the same value.
 * An empty string clears it and restores the automatic palette colour.
 */
const parseCompanyColor = (raw: unknown): ParsedCompanyColor => {
  if (typeof raw !== "string") {
    return { error: INVALID_COLOUR, ok: false };
  }

  const trimmed = raw.trim();
  if (trimmed.length === 0) {
    return { color: null, ok: true };
  }

  const match = HEX_COLOUR.exec(trimmed);
  if (!match?.[1]) {
    return { error: INVALID_COLOUR, ok: false };
  }

  const hex = match[1].toLowerCase();
  const expanded = hex.length === 3
    ? hex.split("").map((digit) => `${digit}${digit}`).join("")
    : hex;
  return { color: `#${expanded}`, ok: true };
};

export { parseCompanyColor };
