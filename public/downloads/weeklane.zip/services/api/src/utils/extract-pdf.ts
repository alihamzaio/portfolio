import { createCanvas, DOMMatrix, Path2D } from "@napi-rs/canvas";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import { createWorker } from "tesseract.js";

const canvasGlobals = globalThis as typeof globalThis & {
  DOMMatrix: typeof DOMMatrix;
  Path2D: typeof Path2D;
};
canvasGlobals.Path2D = Path2D;
canvasGlobals.DOMMatrix = DOMMatrix;

export interface PdfOcrWord {
  text: string;
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

export interface OutlookMonthCell {
  column: number;
  week: number;
  text: string;
}

export interface PdfExtract {
  text: string;
  words: PdfOcrWord[];
  cells: OutlookMonthCell[];
}

const LINE_Y_TOLERANCE = 3;
const MIN_EMBEDDED_CHARS = 40;
const MAX_OCR_PAGES = 8;
const WEEKDAY_TOKEN =
  /^(moody|monday|tue|tuesday|wed|wednesday|wednesdy|thu|thursday|fri|friday|idsy|sat|saturday|saurdy|sun|sunday)$/i;
const MONTH_YEAR =
  /\b(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sept|Sep|Oct|Nov|Dec)\s+(\d{4})\b/i;
const MONTH_INDEX: Record<string, number> = {
  jan: 1,
  january: 1,
  feb: 2,
  february: 2,
  mar: 3,
  march: 3,
  apr: 4,
  april: 4,
  may: 5,
  jun: 6,
  june: 6,
  jul: 7,
  july: 7,
  aug: 8,
  august: 8,
  sep: 9,
  sept: 9,
  september: 9,
  oct: 10,
  october: 10,
  nov: 11,
  november: 11,
  dec: 12,
  december: 12,
};

type PageCanvas = ReturnType<typeof createCanvas>;
const require = createRequire(import.meta.url);

pdfjs.GlobalWorkerOptions.workerSrc = pathToFileURL(
  require.resolve("pdfjs-dist/legacy/build/pdf.worker.min.mjs"),
).href;

interface PdfTextItem {
  str: string;
  transform: number[];
}

const isTextItem = (item: unknown): item is PdfTextItem =>
  typeof item === "object"
  && item !== null
  && "str" in item
  && typeof (item as { str: unknown }).str === "string"
  && "transform" in item
  && Array.isArray((item as { transform: unknown }).transform);

const linesFromItems = (items: unknown[]): string[] => {
  const buckets = new Map<number, { x: number; text: string }[]>();

  for (const item of items) {
    if (!isTextItem(item) || item.str.trim().length === 0) {
      continue;
    }
    const y = Math.round((item.transform[5] ?? 0) / LINE_Y_TOLERANCE) * LINE_Y_TOLERANCE;
    const x = item.transform[4] ?? 0;
    const bucket = buckets.get(y) ?? [];
    bucket.push({ text: item.str, x });
    buckets.set(y, bucket);
  }

  return [...buckets.entries()]
    .sort((left, right) => right[0] - left[0])
    .map(([, parts]) =>
      parts
        .sort((left, right) => left.x - right.x)
        .map((part) => part.text)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim(),
    )
    .filter((line) => line.length > 0);
};

const patchPathDrawing = (context: ReturnType<PageCanvas["getContext"]>): void => {
  const names = ["clip", "fill", "stroke"] as const;
  for (const name of names) {
    const original = (context[name] as (...args: unknown[]) => unknown).bind(context);
    (context as unknown as Record<string, (...args: unknown[]) => unknown>)[name] = (...args: unknown[]) => {
      try {
        return original(...args);
      } catch {
        const rule = args.find((arg) => arg === "evenodd" || arg === "nonzero");
        return rule === undefined ? original() : original(rule);
      }
    };
  }
};

const renderPageCanvas = async (page: {
  getViewport: (options: { scale: number }) => { width: number; height: number };
  render: (options: object) => { promise: Promise<unknown> };
}): Promise<PageCanvas> => {
  const viewport = page.getViewport({ scale: 2.5 });
  const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
  const canvasContext = canvas.getContext("2d");
  patchPathDrawing(canvasContext);
  await page.render({ canvasContext, viewport }).promise;
  return canvas;
};

const wordsFromOcr = (result: {
  data: {
    text: string;
    blocks: { paragraphs: { lines: { words: { text: string; bbox: PdfOcrWord }[] }[] }[] }[] | null;
  };
}): { text: string; words: PdfOcrWord[] } => {
  const words: PdfOcrWord[] = [];
  for (const block of result.data.blocks ?? []) {
    for (const paragraph of block.paragraphs) {
      for (const line of paragraph.lines) {
        for (const word of line.words) {
          const text = word.text.trim();
          if (text.length === 0) {
            continue;
          }
          words.push({
            text,
            x0: word.bbox.x0,
            x1: word.bbox.x1,
            y0: word.bbox.y0,
            y1: word.bbox.y1,
          });
        }
      }
    }
  }
  return { text: result.data.text, words };
};

const weekdayXs = (words: PdfOcrWord[]): number[] => {
  const hits = words
    .filter((word) => WEEKDAY_TOKEN.test(word.text))
    .sort((left, right) => left.x0 - right.x0);
  const xs = hits.map((word) => word.x0);
  const unique: number[] = [];
  for (const x of xs) {
    if (unique.every((kept) => Math.abs(kept - x) > 40)) {
      unique.push(x);
    }
  }
  return unique;
};

const weekCountFromText = (text: string): number | null => {
  const dated = text.match(MONTH_YEAR);
  const month = dated ? MONTH_INDEX[(dated[1] ?? "").toLowerCase()] : undefined;
  if (!dated || !month) {
    return null;
  }
  const year = Number(dated[2]);
  const weekday = new Date(Date.UTC(year, month - 1, 1)).getUTCDay();
  const mondayIndex = weekday === 0 ? 6 : weekday - 1;
  const days = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return Math.ceil((mondayIndex + days) / 7);
};

const dayRowTops = (words: PdfOcrWord[], weekdayBottom: number): number[] => {
  const below = words.filter((word) => word.y0 > weekdayBottom + 8).sort((left, right) => left.y0 - right.y0);
  const rows: PdfOcrWord[][] = [];
  for (const word of below) {
    const last = rows[rows.length - 1];
    if (last && Math.abs(word.y0 - (last[0]?.y0 ?? 0)) <= 16) {
      last.push(word);
    } else {
      rows.push([word]);
    }
  }
  const tops: number[] = [];
  for (const row of rows) {
    if (row.some((word) => /^(AM|PM)$/i.test(word.text))) {
      continue;
    }
    const uniqueDays = new Set(
      row
        .map((word) => word.text.match(/^(\d{1,2})/))
        .filter((match): match is RegExpMatchArray => match !== null)
        .map((match) => Number(match[1]))
        .filter((day) => day >= 1 && day <= 31),
    );
    if (uniqueDays.size >= 4) {
      tops.push(Math.min(...row.map((word) => word.y0)) - 4);
    }
  }
  return tops.filter((top, index, all) => index === 0 || top - (all[index - 1] ?? 0) > 40);
};

const contrastCell = (source: PageCanvas, left: number, top: number, width: number, height: number): Buffer => {
  const x = Math.max(0, Math.floor(left));
  const y = Math.max(0, Math.floor(top));
  const w = Math.max(8, Math.min(Math.floor(width), source.width - x));
  const h = Math.max(8, Math.min(Math.floor(height), source.height - y));
  const cell = createCanvas(w, h);
  const context = cell.getContext("2d");
  context.drawImage(source, x, y, w, h, 0, 0, w, h);
  const image = context.getImageData(0, 0, w, h);
  const pixels = image.data;
  for (let index = 0; index < pixels.length; index += 4) {
    const gray = Math.min(pixels[index] ?? 255, pixels[index + 1] ?? 255, pixels[index + 2] ?? 255);
    const ink = gray < 170 ? 0 : 255;
    pixels[index] = ink;
    pixels[index + 1] = ink;
    pixels[index + 2] = ink;
  }
  context.putImageData(image, 0, 0);
  const scale = 2;
  const enlarged = createCanvas(w * scale, h * scale);
  const enlargedContext = enlarged.getContext("2d");
  enlargedContext.imageSmoothingEnabled = false;
  enlargedContext.drawImage(cell, 0, 0, w * scale, h * scale);
  return enlarged.toBuffer("image/png");
};

const cellIsBlank = (canvas: PageCanvas, left: number, top: number, width: number, height: number): boolean => {
  const x = Math.max(0, Math.floor(left));
  const y = Math.max(0, Math.floor(top));
  const w = Math.max(1, Math.min(Math.floor(width), canvas.width - x));
  const h = Math.max(1, Math.min(Math.floor(height), canvas.height - y));
  const pixels = canvas.getContext("2d").getImageData(x, y, w, h).data;
  let dark = 0;
  for (let index = 0; index < pixels.length; index += 16) {
    const red = pixels[index] ?? 255;
    const green = pixels[index + 1] ?? 255;
    const blue = pixels[index + 2] ?? 255;
    if (red + green + blue < 700) {
      dark += 1;
    }
  }
  return dark < 8;
};

const ocrMonthCells = async (
  canvas: PageCanvas,
  words: PdfOcrWord[],
  pageText: string,
  worker: Awaited<ReturnType<typeof createWorker>>,
): Promise<OutlookMonthCell[]> => {
  let xs = weekdayXs(words);
  let weekdayBottom = Math.max(
    0,
    ...words.filter((word) => WEEKDAY_TOKEN.test(word.text)).map((word) => word.y1),
  );
  if (xs.length < 4 || weekdayBottom < 20) {
    const margin = canvas.width * 0.015;
    xs = Array.from({ length: 7 }, (_, index) => margin + index * ((canvas.width - margin * 2) / 7));
    weekdayBottom = Math.round(canvas.height * 0.16);
  }

  const firstX = xs[0] ?? 0;
  const lastX = xs[xs.length - 1] ?? firstX;
  const colStarts =
    xs.length === 7
      ? xs
      : Array.from({ length: 7 }, (_, index) => firstX + index * ((lastX - firstX) / 6 || canvas.width / 7));
  const colWidth = (colStarts[1] ?? canvas.width / 7) - (colStarts[0] ?? 0);
  const gridTop = weekdayBottom + 6;
  const gridBottom = canvas.height - 8;
  const detectedTops = dayRowTops(words, weekdayBottom);
  const weekCount = weekCountFromText(pageText) ?? (gridBottom - gridTop > colWidth * 6.2 ? 6 : 5);
  const firstTop = detectedTops[0] ?? gridTop;
  const lastTop = detectedTops[detectedTops.length - 1] ?? (gridBottom - (gridBottom - firstTop) / weekCount);
  const weekTops = Array.from({ length: weekCount }, (_, week) =>
    Math.round(firstTop + week * ((lastTop - firstTop) / Math.max(1, weekCount - 1))),
  );
  const cells: OutlookMonthCell[] = [];

  try {
    await worker.setParameters({ tessedit_pageseg_mode: "6" });
  } catch {
    // Keep the worker's default page segmentation if this build rejects the flag.
  }

  for (let week = 0; week < weekTops.length; week += 1) {
    const top = weekTops[week] ?? gridTop;
    const bottom = weekTops[week + 1] ?? gridBottom;
    const height = Math.max(12, bottom - top - 2);
    for (let column = 0; column < 7; column += 1) {
      const left = (colStarts[column] ?? 0) - 8;
      const next = colStarts[column + 1] ?? canvas.width - 4;
      const width = next - left;
      if (cellIsBlank(canvas, left, top, width, height)) {
        cells.push({ column, text: "", week });
        continue;
      }
      const png = contrastCell(canvas, left, top, width, height);
      const result = await worker.recognize(png);
      cells.push({ column, text: result.data.text, week });
    }
  }

  return cells;
};

/**
 * Mozilla PDF.js (Apache-2.0) reads the file. Screenshot prints have no text layer, so
 * Tesseract.js (Apache-2.0) reads each calendar cell. Both are free npm packages.
 */
export const extractPdfContent = async (data: Uint8Array): Promise<PdfExtract> => {
  const pdf = await pdfjs.getDocument({ data, disableFontFace: true, isOffscreenCanvasSupported: false }).promise;
  const embedded: string[] = [];

  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    embedded.push(linesFromItems(content.items).join("\n"));
  }

  const embeddedText = embedded.join("\n").trim();
  if (embeddedText.length >= MIN_EMBEDDED_CHARS) {
    return { cells: [], text: embeddedText, words: [] };
  }

  const worker = await createWorker("eng");
  const texts: string[] = [];
  const words: PdfOcrWord[] = [];
  const cells: OutlookMonthCell[] = [];
  const lastPage = Math.min(pdf.numPages, MAX_OCR_PAGES);

  try {
    for (let pageNumber = 1; pageNumber <= lastPage; pageNumber += 1) {
      const page = await pdf.getPage(pageNumber);
      const canvas = await renderPageCanvas(page);
      const png = canvas.toBuffer("image/png");
      const pageOcr = wordsFromOcr(
        (await worker.recognize(png, {}, { blocks: true })) as Parameters<typeof wordsFromOcr>[0],
      );
      texts.push(pageOcr.text);
      words.push(...pageOcr.words);
      cells.push(...(await ocrMonthCells(canvas, pageOcr.words, pageOcr.text, worker)));
    }
  } finally {
    await worker.terminate();
  }

  return {
    cells,
    text: texts.join("\n"),
    words,
  };
};

export const MAX_PDF_BYTES = 8_000_000;
