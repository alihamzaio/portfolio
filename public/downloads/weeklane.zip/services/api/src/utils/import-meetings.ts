import { parseIcsCalendar, parseIcsEvents } from "@syncforge/calendar/ics";

interface ImportedMeetingDraft {
  title: string;
  startTime: string;
  endTime: string;
  isAllDay?: boolean;
  description?: string;
  location?: string;
}

const MAX_ICS_CHARS = 2_000_000;
const MAX_IMPORT_EVENTS = 250;

const duplicateKey = (title: string, startTime: Date): string =>
  `${title.trim().toLowerCase()}|${startTime.getTime()}`;

const meetingDuplicateKey = (title: string, startTimeIso: string): string =>
  duplicateKey(title, new Date(startTimeIso));

const previewIcsMeetings = (ics: string): ImportedMeetingDraft[] => {
  const calendar = parseIcsCalendar({ icsString: ics });
  const meetings: ImportedMeetingDraft[] = [];

  for (const event of parseIcsEvents(calendar)) {
    const title = event.title?.trim();
    if (!title || title.length === 0) {
      continue;
    }
    if (event.endTime.getTime() <= event.startTime.getTime()) {
      continue;
    }
    meetings.push({
      ...(event.description && { description: event.description }),
      endTime: event.endTime.toISOString(),
      isAllDay: event.isAllDay === true,
      ...(event.location && { location: event.location }),
      startTime: event.startTime.toISOString(),
      title,
    });
  }

  return meetings;
};

const filterNewMeetings = (
  drafts: ImportedMeetingDraft[],
  existing: { title: string | null; startTime: Date }[],
): { next: ImportedMeetingDraft[]; skipped: number } => {
  const seen = new Set(existing.map((row) => duplicateKey(row.title ?? "", row.startTime)));
  const next: ImportedMeetingDraft[] = [];
  let skipped = 0;

  for (const draft of drafts) {
    const start = new Date(draft.startTime);
    const end = new Date(draft.endTime);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end.getTime() <= start.getTime()) {
      skipped += 1;
      continue;
    }
    const key = duplicateKey(draft.title, start);
    if (seen.has(key)) {
      skipped += 1;
      continue;
    }
    seen.add(key);
    next.push({
      ...draft,
      endTime: end.toISOString(),
      startTime: start.toISOString(),
      title: draft.title.trim(),
    });
  }

  return { next, skipped };
};

export {
  MAX_ICS_CHARS,
  MAX_IMPORT_EVENTS,
  filterNewMeetings,
  meetingDuplicateKey,
  previewIcsMeetings,
};
export type { ImportedMeetingDraft };
