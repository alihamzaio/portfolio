interface FirstAdminStore {
  hasAdmin(): Promise<boolean>;
  setAdmin(userId: string): Promise<void>;
}

const userIdFromAuthPayload = (body: unknown): string | null => {
  if (!body || typeof body !== "object" || !("user" in body)) {
    return null;
  }

  const user = body.user;
  if (!user || typeof user !== "object" || !("id" in user)) {
    return null;
  }

  return typeof user.id === "string" && user.id.length > 0 ? user.id : null;
};

const promoteIfNoAdmin = async (store: FirstAdminStore, userId: string): Promise<boolean> => {
  if (userId.length === 0) {
    return false;
  }
  if (await store.hasAdmin()) {
    return false;
  }
  await store.setAdmin(userId);
  return true;
};

export { promoteIfNoAdmin, userIdFromAuthPayload };
export type { FirstAdminStore };
