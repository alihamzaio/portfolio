const MINIMUM_PASSWORD_LENGTH = 8;

const messageFromBody = (body: unknown): string => {
  if (!body || typeof body !== "object") {
    return "";
  }
  if ("error" in body && typeof body.error === "string") {
    return body.error;
  }
  if ("message" in body && typeof body.message === "string") {
    return body.message;
  }
  return "";
};

const createUserFailureMessage = (body: unknown): string => {
  const message = messageFromBody(body).toLowerCase();
  if (
    message.includes("already taken")
    || message.includes("already in use")
    || message.includes("already exists")
  ) {
    return "That email is already used.";
  }
  return "Could not create that user.";
};

type ParsedPassword =
  | { ok: true; password: string }
  | { ok: false; error: string };

const parsePassword = (raw: unknown): ParsedPassword => {
  if (typeof raw !== "string") {
    return { error: "Password is required.", ok: false };
  }
  if (raw.length < MINIMUM_PASSWORD_LENGTH) {
    return {
      error: `Password must be at least ${MINIMUM_PASSWORD_LENGTH} characters.`,
      ok: false,
    };
  }
  return { ok: true, password: raw };
};

export { createUserFailureMessage, MINIMUM_PASSWORD_LENGTH, parsePassword };
