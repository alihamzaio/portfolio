const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const NAME_MAX_LENGTH = 80;

type ParsedEmail =
  | { ok: true; email: string }
  | { ok: false; error: string };

type ParsedName =
  | { ok: true; name: string }
  | { ok: false; error: string };

const parseEmail = (raw: unknown): ParsedEmail => {
  if (typeof raw !== "string") {
    return { error: "Enter an email address.", ok: false };
  }
  const email = raw.trim().toLowerCase();
  if (!EMAIL.test(email)) {
    return { error: "Enter a valid email address.", ok: false };
  }
  return { email, ok: true };
};

const parseDisplayName = (raw: unknown): ParsedName => {
  if (typeof raw !== "string") {
    return { error: "Enter a name.", ok: false };
  }
  const name = raw.trim();
  if (name.length === 0) {
    return { error: "Enter a name.", ok: false };
  }
  if (name.length > NAME_MAX_LENGTH) {
    return { error: `Name must be at most ${NAME_MAX_LENGTH} characters.`, ok: false };
  }
  return { name, ok: true };
};

export { parseDisplayName, parseEmail };
