import {
  caldavCredentialsTable,
  calendarAccountsTable,
  oauthCredentialsTable,
} from "@syncforge/database/schema";
import { buildImportedCalendarExists, decryptPassword } from "@syncforge/database";
import {
  resolveRediscoveryCalendarType,
  toDiscoveredCalDAVCalendars,
  toDiscoveredGoogleCalendars,
} from "@syncforge/calendar";
import type { DiscoveredCalendar, RediscoveryCalendarType } from "@syncforge/calendar";
import {
  createCalDAVClient,
  resolveCalDAVServerHost,
} from "@syncforge/calendar/caldav";
import { listUserCalendars as listGoogleCalendars } from "@syncforge/calendar/google";
import { and, eq, inArray } from "drizzle-orm";
import type { CalDAVAuthMethod } from "@syncforge/calendar/digest-fetch";
import { safeFetchOptions } from "./safe-fetch-options";
import {
  refreshGoogleSourceAccessToken,
} from "./oauth-refresh";

const FIRST_RESULT_LIMIT = 1;

interface RefreshableAccount {
  id: string;
  userId: string;
  provider: string;
  authType: string;
  calendarType: RediscoveryCalendarType;
  hasImportedCalendar: boolean;
  caldavServerHost?: string | null;
}

const isExpired = (expiresAt: Date): boolean => expiresAt < new Date();

const resolveSourceAccessToken = async (
  provider: string,
  credential: { id: string; accessToken: string; refreshToken: string; expiresAt: Date },
): Promise<string> => {
  if (!isExpired(credential.expiresAt)) {
    return credential.accessToken;
  }

  if (provider === "google") {
    const refreshed = await refreshGoogleSourceAccessToken(
      credential.id,
      credential.refreshToken,
    );
    return refreshed.accessToken;
  }

  throw new Error(`No token refresh support for provider: ${provider}`);
};

const discoverOAuthAccountCalendars = async (
  accountId: string,
  provider: string,
): Promise<DiscoveredCalendar[]> => {
  const { database } = await import("@/context");

  const [credential] = await database
    .select({
      accessToken: oauthCredentialsTable.accessToken,
      expiresAt: oauthCredentialsTable.expiresAt,
      id: oauthCredentialsTable.id,
      refreshToken: oauthCredentialsTable.refreshToken,
    })
    .from(calendarAccountsTable)
    .innerJoin(
      oauthCredentialsTable,
      eq(calendarAccountsTable.oauthCredentialId, oauthCredentialsTable.id),
    )
    .where(eq(calendarAccountsTable.id, accountId))
    .limit(FIRST_RESULT_LIMIT);

  if (!credential) {
    throw new Error(`Calendar account ${accountId} has no OAuth credential`);
  }

  const accessToken = await resolveSourceAccessToken(provider, credential);

  if (provider === "google") {
    return toDiscoveredGoogleCalendars(await listGoogleCalendars(accessToken));
  }

  throw new Error(`No calendar listing support for provider: ${provider}`);
};

const discoverCalDAVAccountCalendars = async (
  accountId: string,
  encryptionKey: string,
): Promise<DiscoveredCalendar[]> => {
  const { database } = await import("@/context");

  const [credential] = await database
    .select({
      authMethod: caldavCredentialsTable.authMethod,
      encryptedPassword: caldavCredentialsTable.encryptedPassword,
      serverUrl: caldavCredentialsTable.serverUrl,
      username: caldavCredentialsTable.username,
    })
    .from(calendarAccountsTable)
    .innerJoin(
      caldavCredentialsTable,
      eq(calendarAccountsTable.caldavCredentialId, caldavCredentialsTable.id),
    )
    .where(eq(calendarAccountsTable.id, accountId))
    .limit(FIRST_RESULT_LIMIT);

  if (!credential) {
    throw new Error(`Calendar account ${accountId} has no CalDAV credential`);
  }

  const client = createCalDAVClient({
    authMethod: credential.authMethod as CalDAVAuthMethod,
    credentials: {
      password: decryptPassword(credential.encryptedPassword, encryptionKey),
      username: credential.username,
    },
    serverUrl: credential.serverUrl,
  }, safeFetchOptions);

  return toDiscoveredCalDAVCalendars(await client.discoverCalendars());
};

const markAccountNeedsReauthentication = async (accountId: string): Promise<void> => {
  const { database } = await import("@/context");

  await database
    .update(calendarAccountsTable)
    .set({ needsReauthentication: true })
    .where(eq(calendarAccountsTable.id, accountId));
};

interface RefreshableAccountRow {
  authType: string;
  hasImportedCalendar: boolean;
  id: string;
  provider: string;
  serverUrl: string | null;
  userId: string;
}

const toRefreshableAccount = (account: RefreshableAccountRow): RefreshableAccount => ({
  authType: account.authType,
  caldavServerHost: resolveCalDAVServerHost(account.serverUrl),
  calendarType: resolveRediscoveryCalendarType(account.authType),
  hasImportedCalendar: account.hasImportedCalendar,
  id: account.id,
  provider: account.provider,
  userId: account.userId,
});

const refreshableAccountColumns = {
  authType: calendarAccountsTable.authType,
  hasImportedCalendar: buildImportedCalendarExists(),
  id: calendarAccountsTable.id,
  provider: calendarAccountsTable.provider,
  serverUrl: caldavCredentialsTable.serverUrl,
  userId: calendarAccountsTable.userId,
};

const loadRefreshableAccount = async (
  accountId: string,
  userId: string,
): Promise<RefreshableAccount | null> => {
  const { database } = await import("@/context");

  const [account] = await database
    .select(refreshableAccountColumns)
    .from(calendarAccountsTable)
    .leftJoin(
      caldavCredentialsTable,
      eq(calendarAccountsTable.caldavCredentialId, caldavCredentialsTable.id),
    )
    .where(and(
      eq(calendarAccountsTable.id, accountId),
      eq(calendarAccountsTable.userId, userId),
    ))
    .limit(FIRST_RESULT_LIMIT);

  if (!account) {
    return null;
  }

  return toRefreshableAccount(account);
};

const loadRefreshableAccountsForUser = async (
  userId: string,
): Promise<RefreshableAccount[]> => {
  const { database } = await import("@/context");

  const accounts = await database
    .select(refreshableAccountColumns)
    .from(calendarAccountsTable)
    .leftJoin(
      caldavCredentialsTable,
      eq(calendarAccountsTable.caldavCredentialId, caldavCredentialsTable.id),
    )
    .where(and(
      eq(calendarAccountsTable.userId, userId),
      eq(calendarAccountsTable.needsReauthentication, false),
      inArray(calendarAccountsTable.authType, ["oauth", "caldav"]),
    ));

  return accounts
    .map((account) => toRefreshableAccount(account))
    .filter((account) => account.hasImportedCalendar);
};

export {
  discoverCalDAVAccountCalendars,
  discoverOAuthAccountCalendars,
  loadRefreshableAccount,
  loadRefreshableAccountsForUser,
  markAccountNeedsReauthentication,
};
export type { RefreshableAccount };
