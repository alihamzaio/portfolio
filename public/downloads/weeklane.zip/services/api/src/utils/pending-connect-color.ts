import { calendarAccountsTable } from "@syncforge/database/schema";
import { and, eq } from "drizzle-orm";
import { parseCompanyColor } from "./company-color";

const PENDING_CONNECT_COLOR_TTL_SECONDS = 20 * 60;

const pendingConnectColorKey = (userId: string): string => `connect:pending-color:${userId}`;

/**
 * Colour chosen on Calendars before the Google/Microsoft redirect. Stored against the
 * user so the OAuth callback can apply it after the account exists.
 */
const rememberPendingConnectColor = async (userId: string, color: string | null): Promise<void> => {
  const { redis } = await import("@/context");
  const key = pendingConnectColorKey(userId);
  if (color === null) {
    await redis.del(key);
    return;
  }
  await redis.set(key, color, "EX", PENDING_CONNECT_COLOR_TTL_SECONDS);
};

const applyPendingConnectColor = async (
  userId: string,
  accountId: string,
): Promise<string | null> => {
  const { database, redis } = await import("@/context");
  const key = pendingConnectColorKey(userId);
  const stored = await redis.get(key);
  if (!stored) {
    return null;
  }

  await redis.del(key);
  const parsed = parseCompanyColor(stored);
  if (!parsed.ok || parsed.color === null) {
    return null;
  }

  const updated = await database
    .update(calendarAccountsTable)
    .set({ companyColor: parsed.color })
    .where(
      and(eq(calendarAccountsTable.id, accountId), eq(calendarAccountsTable.userId, userId)),
    )
    .returning({ id: calendarAccountsTable.id });

  if (updated.length === 0) {
    return null;
  }

  return parsed.color;
};

export { applyPendingConnectColor, rememberPendingConnectColor };
