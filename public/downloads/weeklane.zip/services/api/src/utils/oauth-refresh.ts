import {
  calendarAccountsTable,
  oauthCredentialsTable,
} from "@syncforge/database/schema";
import { createGoogleTokenRefresher } from "@syncforge/calendar";
import { eq } from "drizzle-orm";
import { database, env } from "@/context";

const FIRST_RESULT_LIMIT = 1;
const MS_PER_SECOND = 1000;

interface RefreshResult {
  accessToken: string;
  expiresAt: Date;
}

const refreshGoogleAccessToken = async (
  accountId: string,
  refreshToken: string,
): Promise<RefreshResult> => {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) {
    throw new Error("Google OAuth not configured");
  }

  const refreshGoogleToken = createGoogleTokenRefresher({
    clientId: env.GOOGLE_CLIENT_ID,
    clientSecret: env.GOOGLE_CLIENT_SECRET,
  });

  const tokenData = await refreshGoogleToken(refreshToken);
  const newExpiresAt = new Date(Date.now() + tokenData.expires_in * MS_PER_SECOND);

  const [account] = await database
    .select({ oauthCredentialId: calendarAccountsTable.oauthCredentialId })
    .from(calendarAccountsTable)
    .where(eq(calendarAccountsTable.id, accountId))
    .limit(FIRST_RESULT_LIMIT);

  if (account?.oauthCredentialId) {
    await database
      .update(oauthCredentialsTable)
      .set({
        accessToken: tokenData.access_token,
        expiresAt: newExpiresAt,
        refreshToken: tokenData.refresh_token ?? refreshToken,
      })
      .where(eq(oauthCredentialsTable.id, account.oauthCredentialId));
  }

  return {
    accessToken: tokenData.access_token,
    expiresAt: newExpiresAt,
  };
};

const refreshGoogleSourceAccessToken = async (
  credentialId: string,
  refreshToken: string,
): Promise<RefreshResult> => {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) {
    throw new Error("Google OAuth not configured");
  }

  const refreshGoogleToken = createGoogleTokenRefresher({
    clientId: env.GOOGLE_CLIENT_ID,
    clientSecret: env.GOOGLE_CLIENT_SECRET,
  });

  const tokenData = await refreshGoogleToken(refreshToken);
  const newExpiresAt = new Date(Date.now() + tokenData.expires_in * MS_PER_SECOND);

  await database
    .update(oauthCredentialsTable)
    .set({
      accessToken: tokenData.access_token,
      expiresAt: newExpiresAt,
      refreshToken: tokenData.refresh_token ?? refreshToken,
    })
    .where(eq(oauthCredentialsTable.id, credentialId));

  return {
    accessToken: tokenData.access_token,
    expiresAt: newExpiresAt,
  };
};

export {
  refreshGoogleAccessToken,
  refreshGoogleSourceAccessToken,
};
