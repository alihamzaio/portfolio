const titleCase = (value: string): string => value.charAt(0).toUpperCase() + value.slice(1);

const fromDomain = (domain: string): string => {
  const [name] = domain.split(".");
  return name ? titleCase(name) : domain;
};

/**
 * A calendar feed URL carries the owning address in its path
 * (/calendar/ical/<email>/private-<token>/basic.ics), so a company name can be recovered
 * from it. The token in that URL grants read access to the whole calendar, so only the
 * derived name is ever returned -- never any part of the URL itself.
 */
const fromFeedUrl = (label: string): string | null => {
  let parsed: URL;
  try {
    parsed = new URL(label);
  } catch {
    return null;
  }

  for (const segment of parsed.pathname.split("/")) {
    const decoded = decodeURIComponent(segment);
    const domain = decoded.includes("@") ? decoded.split("@")[1] : undefined;
    if (domain) {
      return fromDomain(domain);
    }
  }

  return parsed.hostname;
};

/**
 * The company a calendar belongs to: the name an operator set, otherwise one derived from
 * the account address or its feed URL. Mirrors what the dashboard shows, so the public
 * page and the signed-in schedule never disagree about what a company is called.
 */
const resolveCompanyName = (source: {
  companyLabel?: string | null;
  email?: string | null;
  accountIdentifier?: string | null;
  providerName?: string | null;
}): string | null => {
  const label = source.companyLabel?.trim();
  if (label) {
    return label;
  }

  const domain = source.email?.split("@")[1];
  if (domain) {
    return fromDomain(domain);
  }

  if (source.accountIdentifier) {
    const derived = fromFeedUrl(source.accountIdentifier);
    if (derived) {
      return derived;
    }
  }

  return source.providerName ?? null;
};

export { resolveCompanyName };
