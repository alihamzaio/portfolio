import { calendarsTable } from "@syncforge/database/schema";
import { and, arrayContains, eq, inArray } from "drizzle-orm";
import {
  PENDING_CORRELATION_KEY,
  PENDING_INGEST_KEY,
  PENDING_REWAKE_KEY,
  signalPendingCalendars,
} from "@syncforge/calendar";
import { database, redis } from "@/context";
import { ingestIcsSource } from "./sources";

const ICAL_CALENDAR_TYPE = "ical";

interface ImmediateIngestResult {
  failed: number;
  ingested: number;
  queued: number;
}

/**
 * Pulls this user's calendars now. ICS feeds are fetched in this process so the operator
 * does not wait for the next cron minute. Google/Microsoft/CalDAV are queued onto the
 * pending-ingest signal the in-container cron already drains.
 */
const runImmediateIngest = async (userId: string): Promise<ImmediateIngestResult> => {
  const sources = await database
    .select()
    .from(calendarsTable)
    .where(
      and(
        eq(calendarsTable.userId, userId),
        eq(calendarsTable.disabled, false),
        arrayContains(calendarsTable.capabilities, ["pull"]),
      ),
    );

  const icsSources = sources.filter((source) => source.calendarType === ICAL_CALENDAR_TYPE);
  const queuedSources = sources.filter((source) => source.calendarType !== ICAL_CALENDAR_TYPE);

  let ingested = 0;
  let failed = 0;

  for (const source of icsSources) {
    try {
      await ingestIcsSource(source);
      ingested += 1;
    } catch {
      failed += 1;
    }
  }

  if (queuedSources.length > 0) {
    const calendarIds = queuedSources.map((source) => source.id);
    const correlationId = crypto.randomUUID();
    const now = Date.now();

    await redis.hset(
      PENDING_CORRELATION_KEY,
      ...calendarIds.flatMap((calendarId) => [calendarId, correlationId]),
    );
    await Promise.all(
      calendarIds.map((calendarId) => redis.hincrby(PENDING_REWAKE_KEY, calendarId, 1)),
    );
    await redis.zadd(
      PENDING_INGEST_KEY,
      "LT",
      ...calendarIds.flatMap((calendarId) => [now, calendarId]),
    );
    await signalPendingCalendars(redis, calendarIds);
    await database
      .update(calendarsTable)
      .set({ ingestNextAttemptAt: null })
      .where(inArray(calendarsTable.id, calendarIds));
  }

  return { failed, ingested, queued: queuedSources.length };
};

export { runImmediateIngest };
export type { ImmediateIngestResult };
