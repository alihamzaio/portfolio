import {
  calendarAccountsTable,
  calendarsTable,
} from "@syncforge/database/schema";
import { asc, eq, sql } from "drizzle-orm";
import { withAccountDisplay } from "@/provider-display";
import type { SyncForgeDatabase, SyncForgeSource } from "@/types";

const listSources = async (
  database: SyncForgeDatabase,
  userId: string,
  options: { allUsers?: boolean } = {},
): Promise<SyncForgeSource[]> => {
  const calendars = await database
    .select({
      id: calendarsTable.id,
      name: calendarsTable.name,
      userId: calendarsTable.userId,
      timeZone: calendarsTable.timeZone,
      companyLabel: calendarAccountsTable.companyLabel,
      companyColor: calendarAccountsTable.companyColor,
      calendarType: calendarsTable.calendarType,
      capabilities: calendarsTable.capabilities,
      accountId: calendarAccountsTable.id,
      provider: calendarAccountsTable.provider,
      displayName: calendarAccountsTable.displayName,
      email: calendarAccountsTable.email,
      accountIdentifier: calendarAccountsTable.accountId,
      needsReauthentication: calendarAccountsTable.needsReauthentication,
      includeInIcalFeed: calendarsTable.includeInIcalFeed,
      unavailableSince: calendarsTable.unavailableSince,
      disabled: calendarsTable.disabled,
      providerMissingSince: calendarsTable.providerMissingSince,
    })
    .from(calendarsTable)
    .innerJoin(calendarAccountsTable, eq(calendarsTable.accountId, calendarAccountsTable.id))
    .where(options.allUsers ? sql`true` : eq(calendarsTable.userId, userId))
    .orderBy(asc(calendarsTable.createdAt));

  return calendars.map((calendar) => withAccountDisplay({
    ...calendar,
    providerMissingSince: calendar.providerMissingSince?.toISOString() ?? null,
  }));
};

export { listSources };
