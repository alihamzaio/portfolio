import {
  calendarAccountsTable,
  calendarsTable,
  eventStatesTable,
  userEventsTable,
} from "@syncforge/database/schema";
import { normalizeDateRange } from "@/utils/date-range";
import { and, arrayContains, asc, eq, gte, inArray, isNotNull, isNull, lte, or } from "drizzle-orm";
import type { SQL } from "drizzle-orm";
import {
  overlapsRepresentableTimeWindow,
  REPRESENTABLE_RANGE_SLACK_MS,
} from "@syncforge/calendar";
import type {
  SyncForgeDatabase,
  SyncForgeEvent,
  SyncForgeEventFilters,
  SyncForgeEventRangeInput,
  SyncForgeSource,
} from "@/types";
import { projectSyncedEvents, toSyncForgeEvent, toUserProjection } from "./event-read-model";
import type {
  SyncForgeEventProjection,
  SourceInfo,
  SyncedEventRow,
  UserEventRow,
} from "./event-read-model";

const EMPTY_RESULT_COUNT = 0;

const toRequiredDate = (value: Date | string, label: "from" | "to"): Date => {
  const parsedDate = new Date(value);
  if (Number.isNaN(parsedDate.getTime())) {
    throw new TypeError(`Invalid ${label} date`);
  }
  return parsedDate;
};

const normalizeEventRange = (
  range: SyncForgeEventRangeInput,
): {
  start: Date;
  end: Date;
} => normalizeDateRange(
  toRequiredDate(range.from, "from"),
  toRequiredDate(range.to, "to"),
);

const getSourcesForUser = async (
  database: SyncForgeDatabase,
  userId: string,
  filters?: SyncForgeEventFilters,
): Promise<{ calendarIds: string[]; sourceMap: Map<string, SourceInfo> }> => {
  const sourceConditions: SQL[] = [
    eq(calendarsTable.userId, userId),
    arrayContains(calendarsTable.capabilities, ["pull"]),
  ];

  if (filters?.calendarId && filters.calendarId.length > 0) {
    sourceConditions.push(inArray(calendarsTable.id, filters.calendarId));
  }

  const sources = await database
    .select({
      id: calendarsTable.id,
      name: calendarsTable.name,
      provider: calendarAccountsTable.provider,
      url: calendarsTable.url,
      userId: calendarsTable.userId,
    })
    .from(calendarsTable)
    .innerJoin(calendarAccountsTable, eq(calendarsTable.accountId, calendarAccountsTable.id))
    .where(and(...sourceConditions));

  const calendarIds = sources.map((source) => source.id);
  const sourceMap = new Map(
    sources.map((source) => [
      source.id,
      { name: source.name, provider: source.provider, url: source.url, userId: source.userId },
    ]),
  );

  return { calendarIds, sourceMap };
};

const flattenSyncedEvents = (
  rows: SyncedEventRow[],
  sourceMap: Map<string, SourceInfo>,
  windowStart: Date,
  windowEnd: Date,
  filters?: SyncForgeEventFilters,
): SyncForgeEventProjection[] => projectSyncedEvents(
  rows,
  sourceMap,
  windowStart,
  windowEnd,
  filters,
);

// Scan wider than the window — the clause sees only stored columns — and let isWithinReadWindow decide.
const toScanBounds = (start: Date, end: Date): { scanEnd: Date; scanStart: Date } => ({
  scanEnd: new Date(end.getTime() + REPRESENTABLE_RANGE_SLACK_MS),
  scanStart: new Date(start.getTime() - REPRESENTABLE_RANGE_SLACK_MS),
});

/**
 * Build the WHERE clause for fetching synced rows that may contribute events
 * to [start, end]: overlapping one-offs, recurring masters whose first
 * occurrence is at-or-before the window end, and detached overrides that either
 * overlap the range at their moved time or originally occupied a slot in it.
 */
const buildSyncedRangeCondition = (start: Date, end: Date): SQL | undefined => {
  const { scanEnd, scanStart } = toScanBounds(start, end);

  return or(
    and(
      isNull(eventStatesTable.recurrenceRule),
      isNull(eventStatesTable.recurrenceId),
      or(
        gte(eventStatesTable.endTime, scanStart),
        gte(eventStatesTable.startTime, scanStart),
      ),
      lte(eventStatesTable.startTime, scanEnd),
    ),
    and(
      isNotNull(eventStatesTable.recurrenceRule),
      lte(eventStatesTable.startTime, scanEnd),
    ),
    isNotNull(eventStatesTable.recurrenceId),
  );
};

const buildUserRangeCondition = (start: Date, end: Date): SQL | undefined => {
  const { scanEnd, scanStart } = toScanBounds(start, end);

  return and(
    or(
      gte(userEventsTable.endTime, scanStart),
      gte(userEventsTable.startTime, scanStart),
    ),
    lte(userEventsTable.startTime, scanEnd),
  );
};

// Read windows are inclusive of their end; the shared predicate is half-open.
const INCLUSIVE_WINDOW_END_MS = 1;

const isWithinReadWindow = (
  row: { endTime: Date; isAllDay?: boolean | null; startTime: Date },
  start: Date,
  end: Date,
): boolean => overlapsRepresentableTimeWindow(
  {
    endTime: row.endTime,
    startTime: row.startTime,
    ...(typeof row.isAllDay === "boolean" && { isAllDay: row.isAllDay }),
  },
  start,
  new Date(end.getTime() + INCLUSIVE_WINDOW_END_MS),
);

const sourceMapFromSources = (sources: SyncForgeSource[]): Map<string, SourceInfo> => {
  const sourceMap = new Map<string, SourceInfo>();
  for (const source of sources) {
    if (!source.capabilities.includes("pull")) {
      continue;
    }
    sourceMap.set(source.id, {
      name: source.name,
      provider: source.provider,
      url: null,
      userId: source.userId,
    });
  }
  return sourceMap;
};

const loadEventsForCalendars = async (
  database: SyncForgeDatabase,
  calendarIds: string[],
  sourceMap: Map<string, SourceInfo>,
  start: Date,
  end: Date,
  options: { filters?: SyncForgeEventFilters; userId?: string } = {},
): Promise<SyncForgeEvent[]> => {
  const { filters, userId } = options;

  const syncedConditions: SQL[] = [
    inArray(eventStatesTable.calendarId, calendarIds),
  ];
  const syncedRangeCondition = buildSyncedRangeCondition(start, end);
  if (syncedRangeCondition) {
    syncedConditions.push(syncedRangeCondition);
  }

  const userConditions: SQL[] = [
    inArray(userEventsTable.calendarId, calendarIds),
  ];
  if (userId) {
    userConditions.push(eq(userEventsTable.userId, userId));
  }
  const userRangeCondition = buildUserRangeCondition(start, end);
  if (userRangeCondition) {
    userConditions.push(userRangeCondition);
  }

  if (filters?.availability && filters.availability.length > 0) {
    userConditions.push(inArray(userEventsTable.availability, filters.availability));
  }
  if (filters && "isAllDay" in filters && typeof filters.isAllDay === "boolean") {
    userConditions.push(eq(userEventsTable.isAllDay, filters.isAllDay));
  }

  const [syncedRows, userEventRows]: [SyncedEventRow[], UserEventRow[]] = await Promise.all([
    database
      .select({
        attendees: eventStatesTable.attendees,
        availability: eventStatesTable.availability,
        calendarId: eventStatesTable.calendarId,
        description: eventStatesTable.description,
        endTime: eventStatesTable.endTime,
        exceptionDates: eventStatesTable.exceptionDates,
        id: eventStatesTable.id,
        isAllDay: eventStatesTable.isAllDay,
        location: eventStatesTable.location,
        meetingUrl: eventStatesTable.meetingUrl,
        organizer: eventStatesTable.organizer,
        recurrenceId: eventStatesTable.recurrenceId,
        recurrenceRule: eventStatesTable.recurrenceRule,
        sourceEventUid: eventStatesTable.sourceEventUid,
        startTime: eventStatesTable.startTime,
        startTimeZone: eventStatesTable.startTimeZone,
        title: eventStatesTable.title,
      })
      .from(eventStatesTable)
      .where(and(...syncedConditions))
      .orderBy(asc(eventStatesTable.startTime)),
    database
      .select({
        calendarId: userEventsTable.calendarId,
        description: userEventsTable.description,
        endTime: userEventsTable.endTime,
        id: userEventsTable.id,
        isAllDay: userEventsTable.isAllDay,
        location: userEventsTable.location,
        startTime: userEventsTable.startTime,
        title: userEventsTable.title,
      })
      .from(userEventsTable)
      .where(and(...userConditions))
      .orderBy(asc(userEventsTable.startTime)),
  ]);

  const syncedEvents = flattenSyncedEvents(syncedRows, sourceMap, start, end, filters);

  const allEvents: SyncForgeEventProjection[] = [
    ...syncedEvents,
    ...userEventRows
      .filter((event) => isWithinReadWindow(event, start, end))
      .map((event) => toUserProjection(event)),
  ];
  allEvents.sort((left, right) => left.startTime.getTime() - right.startTime.getTime());

  const detailsById = new Map(syncedRows.map((row) => [row.id, row]));

  return allEvents.map((event) => {
    const source = sourceMap.get(event.calendarId);
    if (!source) {
      throw new Error(`No source calendar found for event calendar ID: ${event.calendarId}`);
    }
    const SyncForgeEvent = toSyncForgeEvent(event, source);
    const detail = event.eventStateId ? detailsById.get(event.eventStateId) : undefined;
    if (!detail) {
      return SyncForgeEvent;
    }
    return {
      ...SyncForgeEvent,
      attendees: (detail.attendees as SyncForgeEvent["attendees"]) ?? null,
      meetingUrl: detail.meetingUrl ?? null,
      organizer: detail.organizer ?? null,
      startTimeZone: detail.startTimeZone,
    };
  });
};

const getEventsInRangeForSources = async (
  database: SyncForgeDatabase,
  sources: SyncForgeSource[],
  range: SyncForgeEventRangeInput,
  filters?: SyncForgeEventFilters,
): Promise<SyncForgeEvent[]> => {
  const { start, end } = normalizeEventRange(range);
  const sourceMap = sourceMapFromSources(sources);
  const calendarIds = [...sourceMap.keys()];
  if (calendarIds.length === EMPTY_RESULT_COUNT) {
    return [];
  }
  return loadEventsForCalendars(database, calendarIds, sourceMap, start, end, { filters });
};

const getEventsInRange = async (
  database: SyncForgeDatabase,
  userId: string,
  range: SyncForgeEventRangeInput,
  filters?: SyncForgeEventFilters,
): Promise<SyncForgeEvent[]> => {
  const { start, end } = normalizeEventRange(range);
  const { calendarIds, sourceMap } = await getSourcesForUser(database, userId, filters);

  if (calendarIds.length === EMPTY_RESULT_COUNT) {
    return [];
  }

  return loadEventsForCalendars(database, calendarIds, sourceMap, start, end, { filters, userId });
};

export {
  buildSyncedRangeCondition,
  buildUserRangeCondition,
  flattenSyncedEvents,
  getEventsInRange,
  getEventsInRangeForSources,
  getSourcesForUser,
  isWithinReadWindow,
  normalizeEventRange,
  sourceMapFromSources,
};
