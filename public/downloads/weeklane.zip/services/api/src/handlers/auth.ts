import { hasOAuthProviderApi } from "@syncforge/auth";
import { auth, authCapabilities, database, env } from "@/context";
import { user as userTable } from "@syncforge/database/auth-schema";
import { eq } from "drizzle-orm";
import { prepareOAuthTokenRequest } from "./auth-oauth-resource";
import type { FirstAdminStore } from "@/utils/first-admin";
import { promoteIfNoAdmin, userIdFromAuthPayload } from "@/utils/first-admin";
import { context, widelog } from "@/utils/logging";
import { resolveOutcome } from "@/utils/middleware";
import { labelFailure } from "@/utils/error-labelling";

const COMPANION_COOKIE_NAME = "weeklane.has_session";
const COMPANION_COOKIE_MAX_AGE = 60 * 60 * 24 * 30;
const COMPANION_COOKIE_SET =
  `${COMPANION_COOKIE_NAME}=1; Path=/; SameSite=Lax; Max-Age=${COMPANION_COOKIE_MAX_AGE}`;
const COMPANION_COOKIE_CLEAR = `${COMPANION_COOKIE_NAME}=; Path=/; Max-Age=0; SameSite=Lax`;

const hasSessionTokenSet = (response: Response): boolean => {
  const cookies = response.headers.getSetCookie();
  return cookies.some(
    (cookie) => cookie.includes("better-auth.session_token=") && !cookie.includes("Max-Age=0"),
  );
};

const hasSessionTokenCleared = (response: Response): boolean => {
  const cookies = response.headers.getSetCookie();
  return cookies.some(
    (cookie) => cookie.includes("better-auth.session_token=") && cookie.includes("Max-Age=0"),
  );
};

const withCompanionCookie = (response: Response, cookie: string): Response => {
  const headers = new Headers(response.headers);
  headers.append("Set-Cookie", cookie);
  return new Response(response.body, {
    headers,
    status: response.status,
    statusText: response.statusText,
  });
};

const processAuthResponse = async (_pathname: string, response: Response): Promise<Response> => {
  if (hasSessionTokenSet(response)) {
    return withCompanionCookie(response, COMPANION_COOKIE_SET);
  }

  if (hasSessionTokenCleared(response)) {
    return withCompanionCookie(response, COMPANION_COOKIE_CLEAR);
  }

  // A failed session lookup must not delete a still-valid cookie. That used to
  // sign people out when they moved between Home and Schedule.
  return response;
};

const isUnauthenticatedRequest = (request: Request): boolean => {
  const authorization = request.headers.get("authorization");
  if (authorization && authorization.trim().length > 0) {
    return false;
  }

  const cookie = request.headers.get("cookie");
  if (cookie && cookie.includes("better-auth.session_token=")) {
    return false;
  }

  return true;
};

const prepareUnauthenticatedRegisterRequest = async (
  pathname: string,
  request: Request,
): Promise<Request> => {
  if (pathname !== "/api/auth/oauth2/register") {
    return request;
  }

  if (request.method !== "POST") {
    return request;
  }

  if (!isUnauthenticatedRequest(request)) {
    return request;
  }

  const body = await request.clone().json().catch(() => null);
  if (!body || typeof body !== "object") {
    return request;
  }

  const modified = { ...body, token_endpoint_auth_method: "none" };
  const headers = new Headers(request.headers);
  headers.delete("content-length");

  return new Request(request.url, {
    method: request.method,
    headers,
    body: JSON.stringify(modified),
  });
};

const HTTP_FORBIDDEN = 403;

const SIGN_UP_PATH = "/api/auth/username-only/sign-up";
const SIGN_IN_PATH = "/api/auth/username-only/sign-in";
const SETUP_PATH = "/api/auth/setup";

const firstAdminStore = (): FirstAdminStore => ({
  async hasAdmin() {
    const [row] = await database
      .select({ id: userTable.id })
      .from(userTable)
      .where(eq(userTable.role, "admin"))
      .limit(1);
    return Boolean(row);
  },
  async setAdmin(userId) {
    await database.update(userTable).set({ role: "admin" }).where(eq(userTable.id, userId));
  },
});

/**
 * A fresh instance has nobody who can promote anyone. The first successful sign-up (or
 * a later sign-in while no administrator exists) becomes admin so the operator never
 * has to run SQL.
 */
const promoteCallerIfNoAdmin = async (response: Response): Promise<void> => {
  if (!response.ok) {
    return;
  }
  const payload = await response.clone().json().catch(() => null);
  const userId = userIdFromAuthPayload(payload);
  if (!userId) {
    return;
  }
  await promoteIfNoAdmin(firstAdminStore(), userId);
};

/**
 * Self-registration is closed. The username-only plugin exposes an open sign-up
 * endpoint, which is right for a personal instance and wrong the moment this is reachable
 * by anyone else: a stranger could create an account and read every connected calendar.
 *
 * Two exceptions keep it usable: the very first account (there is no admin yet to create
 * it), and a request already carrying an admin session, which is how the user panel adds
 * people.
 */
const isSignUpAllowed = async (request: Request): Promise<boolean> => {
  const [existing] = await database.select({ id: userTable.id }).from(userTable).limit(1);
  if (!existing) {
    return true;
  }

  const session = await auth.api.getSession({ headers: request.headers });
  const requesterId = session?.user?.id;
  if (!requesterId) {
    return false;
  }

  const [requester] = await database
    .select({ role: userTable.role })
    .from(userTable)
    .where(eq(userTable.id, requesterId))
    .limit(1);

  return requester?.role === "admin";
};

const processAuth = async (pathname: string, request: Request): Promise<Response> => {
  if (pathname === "/api/auth/capabilities") {
    return Response.json(authCapabilities);
  }

  if (pathname === SETUP_PATH) {
    const [existing] = await database.select({ id: userTable.id }).from(userTable).limit(1);
    return Response.json({ needsFirstAdmin: !existing });
  }

  if (pathname === SIGN_UP_PATH && !(await isSignUpAllowed(request))) {
    return Response.json(
      { error: "Self-registration is disabled. An administrator creates accounts." },
      { status: HTTP_FORBIDDEN },
    );
  }

  if (hasOAuthProviderApi(auth.api)) {
    if (pathname === "/api/auth/.well-known/oauth-authorization-server") {
      return Response.json(
        await auth.api.getOAuthServerConfig({
          headers: request.headers,
        }),
      );
    }

    if (pathname === "/api/auth/.well-known/openid-configuration") {
      return Response.json(
        await auth.api.getOpenIdConfig({
          headers: request.headers,
        }),
      );
    }
  }

  const preparedRequest = await prepareUnauthenticatedRegisterRequest(pathname, request);
  const preparedTokenRequest = await prepareOAuthTokenRequest({
    mcpPublicUrl: env.MCP_PUBLIC_URL,
    pathname,
    request: preparedRequest,
  });

  const response = await auth.handler(preparedTokenRequest.request);

  // Read a clone of the handler response before wrapping it. Cloning the wrapped
  // body can lock the stream in Bun and drop the session cookie the browser needs
  // to leave the login page.
  if (pathname === SIGN_UP_PATH || pathname === SIGN_IN_PATH) {
    await promoteCallerIfNoAdmin(response);
  }

  return processAuthResponse(pathname, response);
};

const handleAuthRequest = (pathname: string, request: Request): Promise<Response> =>
  context(async () => {
    const requestId = request.headers.get("x-request-id") ?? crypto.randomUUID();

    widelog.set("operation.name", `${request.method} ${pathname}`);
    widelog.set("operation.type", "auth");
    widelog.set("request.id", requestId);
    widelog.set("http.method", request.method);
    widelog.set("http.path", pathname);

    try {
      return await widelog.time.measure("duration_ms", async () => {
        const response = await processAuth(pathname, request);
        widelog.set("status_code", response.status);
        widelog.set("outcome", resolveOutcome(response.status));
        return response;
      });
    } catch (error) {
      widelog.set("status_code", 500);
      widelog.set("outcome", "error");
      labelFailure(error, { slug: "auth-request-failed" });
      throw error;
    } finally {
      widelog.flush();
    }
  });

export { handleAuthRequest };
