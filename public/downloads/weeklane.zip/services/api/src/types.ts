import type { BunSQLDatabase } from "drizzle-orm/bun-sql";
import type { FreeSlot, WorkingHours } from "@/utils/free-time";

type SyncForgeDatabase = BunSQLDatabase;

interface SyncForgeEventRangeInput {
  from: Date | string;
  to: Date | string;
}

interface SyncForgeEventFilters {
  calendarId?: string[];
  availability?: string[];
  isAllDay?: boolean;
}

interface SyncForgeSource {
  id: string;
  name: string;
  /** Owning auth user. Needed so the team schedule can name events without a per-user fan-out. */
  userId: string;
  /**
   * A correction, not the feed's own zone: "the wall-clock times in this calendar were
   * actually entered in this zone". Set when a calendar is misconfigured -- e.g. a feed
   * declaring UTC whose owner types local Pakistan times into it. Null means the times
   * are trusted as published.
   */
  timeZone: string | null;
  /** Operator-set company name for the owning account; null means derive one. */
  companyLabel: string | null;
  /** Operator-set meeting colour for the owning account; null means use the palette. */
  companyColor: string | null;
  calendarType: string;
  capabilities: string[];
  accountId: string;
  provider: string;
  displayName: string | null;
  email: string | null;
  accountIdentifier: string;
  needsReauthentication: boolean;
  includeInIcalFeed: boolean;
  unavailableSince: Date | null;
  disabled: boolean;
  providerMissingSince: string | null;
  providerName: string;
  providerIcon: string | null;
  accountLabel: string;
}

interface SyncForgeEvent {
  id: string;
  /** Persisted event_states UUID for synced events; null for user-created events. */
  eventStateId: string | null;
  startTime: string;
  endTime: string;
  title: string | null;
  description: string | null;
  location: string | null;
  attendees: EventAttendee[] | null;
  organizer: string | null;
  meetingUrl: string | null;
  /** The zone the event was authored in, when the source declared one (ICS TZID). */
  startTimeZone: string | null;
  calendarId: string;
  calendarName: string;
  calendarProvider: string;
  calendarUrl: string | null;
  isAllDay: boolean | null;
}

interface EventAttendee {
  email: string;
  name?: string;
  role?: string;
  status?: string;
}

interface SyncForgeFreeTimeOptions {
  durationMinutes: number;
  timezone: string;
  workingHours: WorkingHours | null;
  ignoreAllDayEvents: boolean;
  limit: number;
}

interface SyncForgeFreeTimeResult {
  from: string;
  to: string;
  timezone: string;
  durationMinutes: number;
  slots: FreeSlot[];
}

interface SyncForgeSyncTriggerResult {
  triggered: boolean;
  sourcesRefreshed: number;
}

interface SyncForgeCalendarPauseResult {
  calendarId: string;
  paused: boolean;
}

interface SyncForgeSyncStatus {
  calendarId: string;
  inSync: boolean;
  lastSyncedAt: string | null;
  localEventCount: number;
  remoteEventCount: number;
}

interface EventInput {
  calendarId: string;
  title: string;
  description?: string;
  location?: string;
  startTime: string;
  endTime: string;
  isAllDay?: boolean;
  availability?: "busy" | "free";
  startTimeZone?: string;
}

interface EventUpdateInput {
  title?: string;
  description?: string;
  location?: string;
  startTime?: string;
  endTime?: string;
  isAllDay?: boolean;
  availability?: "busy" | "free";
  startTimeZone?: string;
}

type RsvpStatus = "accepted" | "declined" | "tentative";

interface EventActionResult {
  success: boolean;
  error?: string;
}

interface ProviderEventReference {
  sourceEventId: string | null;
  sourceEventUid: string;
}

interface EventCreateResult extends EventActionResult {
  event?: SyncForgeEvent;
}

interface PendingInvite {
  sourceEventUid: string;
  title: string | null;
  description: string | null;
  location: string | null;
  startTime: string;
  endTime: string;
  isAllDay: boolean;
  organizer: string | null;
  calendarId: string;
  provider: string;
}

interface ProviderCredentials {
  provider: string;
  calendarId: string;
  accountId: string;
  externalCalendarId: string | null;
  calendarUrl: string | null;
  email: string | null;
  oauth?: {
    credentialId: string;
    accessToken: string;
    refreshToken: string;
    expiresAt: Date;
  };
  caldav?: {
    authMethod: string;
    serverUrl: string;
    username: string;
    encryptedPassword: string;
  };
}

interface SyncForgeApi {
  listSources: (userId: string) => Promise<SyncForgeSource[]>;
  getEventsInRange: (userId: string, range: SyncForgeEventRangeInput, filters?: SyncForgeEventFilters) => Promise<SyncForgeEvent[]>;
  getEvent: (userId: string, eventId: string) => Promise<SyncForgeEvent | null>;
  getEventCount: (userId: string, options?: { from: Date; to: Date }) => Promise<number>;
  findFreeTime: (
    userId: string,
    range: SyncForgeEventRangeInput,
    options: SyncForgeFreeTimeOptions,
    filters?: SyncForgeEventFilters,
  ) => Promise<SyncForgeFreeTimeResult>;
  getSyncStatuses: (userId: string) => Promise<SyncForgeSyncStatus[]>;
  createEvent: (userId: string, input: EventInput) => Promise<EventCreateResult>;
  updateEvent: (userId: string, eventId: string, updates: EventUpdateInput) => Promise<EventActionResult>;
  deleteEvent: (userId: string, eventId: string) => Promise<EventActionResult>;
  rsvpEvent: (userId: string, eventId: string, status: RsvpStatus) => Promise<EventActionResult>;
  getPendingInvites: (userId: string, calendarId: string, from: string, to: string) => Promise<PendingInvite[]>;
}

export type {
  EventAttendee,
  EventActionResult,
  EventCreateResult,
  EventInput,
  EventUpdateInput,
  SyncForgeApi,
  SyncForgeCalendarPauseResult,
  SyncForgeDatabase,
  SyncForgeEvent,
  SyncForgeEventFilters,
  SyncForgeEventRangeInput,
  SyncForgeFreeTimeOptions,
  SyncForgeFreeTimeResult,
  SyncForgeSyncTriggerResult,
  SyncForgeSource,
  SyncForgeSyncStatus,
  PendingInvite,
  ProviderCredentials,
  ProviderEventReference,
  RsvpStatus,
};
