import { Resend } from "resend";
import env from "./env";
import { createDatabase, decryptPassword } from "@syncforge/database";
import { providerAppsTable, syncStatusTable } from "@syncforge/database/schema";
import Redis from "ioredis";
import { createAuth } from "@syncforge/auth";
import { createBroadcastService } from "@syncforge/broadcast";
import { createPremiumService } from "@syncforge/premium";
import {
  createOAuthProviders,
  buildOAuthConfigs,
  createSyncAggregateRuntime,
  resolveWebhookConfig,
} from "@syncforge/calendar";
import { widelog } from "@/utils/logging";
import type {
  DestinationSyncResult,
  OAuthConfigs,
  OAuthProviders,
  OAuthStateStore,
  RefreshLockStore,
} from "@syncforge/calendar";

const MIN_TRUSTED_ORIGINS_COUNT = 0;

const database = await createDatabase(env.DATABASE_URL, { maxConnections: env.DATABASE_POOL_MAX });
const redis = new Redis(env.REDIS_URL, {
  commandTimeout: 10_000,
  maxRetriesPerRequest: 3,
});

const createRedisStateStore = (redisClient: Redis): OAuthStateStore => ({
  async set(key, value, ttlSeconds) {
    await redisClient.set(key, value);
    await redisClient.expire(key, ttlSeconds);
  },
  async consume(key) {
    const value = await redisClient.get(key);
    if (!value) {
      return null;
    }
    const deleted = await redisClient.del(key);
    if (!deleted) {
      return null;
    }
    return value;
  },
});

const oauthStateStore = createRedisStateStore(redis);

const createRedisRefreshLockStore = (redisClient: Redis): RefreshLockStore => ({
  async tryAcquire(key, ttlSeconds) {
    const result = await redisClient.set(key, "1", "EX", ttlSeconds, "NX");
    return result !== null;
  },
  async release(key) {
    await redisClient.del(key);
  },
});
const refreshLockStore = createRedisRefreshLockStore(redis);

const parseTrustedOrigins = (origins?: string): string[] => {
  if (!origins) {
    return [];
  }
  return origins.split(",").map((origin): string => origin.trim());
};

const trustedOrigins = parseTrustedOrigins(env.TRUSTED_ORIGINS);

const { auth, capabilities: authCapabilities } = createAuth({
  database,
  secret: env.BETTER_AUTH_SECRET,
  baseUrl: env.BETTER_AUTH_URL,
  commercialMode: env.COMMERCIAL_MODE ?? false,
  polarAccessToken: env.POLAR_ACCESS_TOKEN,
  polarMode: env.POLAR_MODE,
  googleClientId: env.GOOGLE_CLIENT_ID,
  googleClientSecret: env.GOOGLE_CLIENT_SECRET,
  resendApiKey: env.RESEND_API_KEY,
  passkeyRpId: env.PASSKEY_RP_ID,
  passkeyRpName: env.PASSKEY_RP_NAME,
  passkeyOrigin: env.PASSKEY_ORIGIN,
  mcpResourceUrl: env.MCP_PUBLIC_URL,
  mcpApiBaseUrl: env.MCP_API_URL,
  ...(trustedOrigins.length > MIN_TRUSTED_ORIGINS_COUNT && { trustedOrigins }),
});

const broadcastService = createBroadcastService({ redis });

const premiumService = createPremiumService({
  commercialMode: env.COMMERCIAL_MODE ?? false,
  database,
});

/**
 * OAuth client credentials can come from the environment or from the provider_apps table
 * written by the dashboard. The environment is the fallback; a stored row wins, so an
 * operator can add or rotate an app without editing files or restarting the API.
 *
 * The exported registry delegates to whichever set is current, which keeps every existing
 * consumer -- token refreshers included -- working against a value that can change.
 */
const environmentOAuthConfigs = buildOAuthConfigs(env);

const configSignature = (configs: OAuthConfigs): string =>
  (["google"] as const)
    .map((provider) => {
      const credentials = configs[provider];
      return credentials ? `${provider}:${credentials.clientId}:${credentials.clientSecret}` : `${provider}:-`;
    })
    .join("|");

const loadStoredOAuthConfigs = async (): Promise<OAuthConfigs> => {
  const configs: OAuthConfigs = {
    google: environmentOAuthConfigs.google,
  };

  const secretKey = env.ENCRYPTION_KEY;
  if (!secretKey) {
    return configs;
  }

  const rows = await database
    .select({
      clientId: providerAppsTable.clientId,
      clientSecretEncrypted: providerAppsTable.clientSecretEncrypted,
      provider: providerAppsTable.provider,
    })
    .from(providerAppsTable);

  for (const row of rows) {
    if (row.provider !== "google") {
      continue;
    }
    try {
      configs[row.provider] = {
        clientId: row.clientId,
        clientSecret: decryptPassword(row.clientSecretEncrypted, secretKey),
      };
    } catch {
      // A row encrypted under a different ENCRYPTION_KEY is unusable; the environment
      // value (or nothing) stands rather than crashing every OAuth request.
    }
  }

  return configs;
};

let activeProviders = createOAuthProviders(environmentOAuthConfigs, oauthStateStore);
let activeSignature = configSignature(environmentOAuthConfigs);

const reloadOAuthProviders = async (): Promise<void> => {
  const configs = await loadStoredOAuthConfigs();
  const signature = configSignature(configs);
  if (signature === activeSignature) {
    return;
  }
  activeProviders = createOAuthProviders(configs, oauthStateStore);
  activeSignature = signature;
};

const oauthProviders: OAuthProviders = {
  getProvider: (providerId) => activeProviders.getProvider(providerId),
  hasRequiredScopes: (providerId, grantedScopes) =>
    activeProviders.hasRequiredScopes(providerId, grantedScopes),
  isOAuthProvider: (providerId) => activeProviders.isOAuthProvider(providerId),
  validateState: (state) => activeProviders.validateState(state),
};

// Pick up anything already stored before the first request arrives.
await reloadOAuthProviders();

const persistSyncStatus = async (
  result: DestinationSyncResult,
  syncedAt: Date,
): Promise<void> => {
  await database
    .insert(syncStatusTable)
    .values({
      calendarId: result.calendarId,
      lastSyncedAt: syncedAt,
      localEventCount: result.localEventCount,
      remoteEventCount: result.remoteEventCount,
    })
    .onConflictDoUpdate({
      set: {
        lastSyncedAt: syncedAt,
        localEventCount: result.localEventCount,
        remoteEventCount: result.remoteEventCount,
      },
      target: [syncStatusTable.calendarId],
    });
};

const reportSyncAggregateError = (scope: string, error: Error): void => {
  widelog.error(`sync_aggregate.${scope}`, error);
};

const syncAggregateRuntime = createSyncAggregateRuntime({
  broadcast: (userId, eventName, payload): void => {
    broadcastService.emit(userId, eventName, payload);
  },
  onError: reportSyncAggregateError,
  persistSyncStatus,
  redis,
});

const getCurrentSyncAggregate = (
  userId: string,
  fallback: {
    progressPercent: number;
    syncEventsProcessed: number;
    syncEventsRemaining: number;
    syncEventsTotal: number;
    lastSyncedAt: string | null;
  },
) => syncAggregateRuntime.getCurrentSyncAggregate(userId, fallback);

const getCachedSyncAggregate = (userId: string) =>
  syncAggregateRuntime.getCachedSyncAggregate(userId);

const createResendClient = (): Resend | null => {
  if (!env.RESEND_API_KEY) {
    return null;
  }

  return new Resend(env.RESEND_API_KEY);
};

const resend = createResendClient();
const feedbackEmail = env.FEEDBACK_EMAIL ?? null;

const baseUrl = env.BETTER_AUTH_URL;
const encryptionKey = env.ENCRYPTION_KEY;
const webhookConfig = resolveWebhookConfig(env.WEBHOOK_PUBLIC_URL);

export {
  database,
  redis,
  env,
  webhookConfig,
  trustedOrigins,
  auth,
  authCapabilities,
  broadcastService,
  premiumService,
  oauthProviders,
  reloadOAuthProviders,
  refreshLockStore,
  resend,
  feedbackEmail,
  baseUrl,
  encryptionKey,
  getCurrentSyncAggregate,
  getCachedSyncAggregate,
};
