import { type } from "arktype";
import { HTTP_STATUS } from "@syncforge/constants";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { eventsImportPreviewBodySchema } from "@/utils/request-body";
import { ErrorResponse } from "@/utils/responses";
import { labelFailureResponse } from "@/utils/error-labelling";
import { MAX_ICS_CHARS, MAX_IMPORT_EVENTS, previewIcsMeetings } from "@/utils/import-meetings";

const POST = withWideEvent(
  withAuth(async ({ request }) => {
    const body = await request.json().catch(() => null);

    try {
      const parsed = eventsImportPreviewBodySchema(body);
      if (parsed instanceof type.errors) {
        return ErrorResponse.badRequest("Paste or upload an .ics file.").toResponse();
      }
      const { ics } = parsed;
      if (ics.length === 0) {
        return ErrorResponse.badRequest("Paste or upload an .ics file.").toResponse();
      }
      if (ics.length > MAX_ICS_CHARS) {
        return ErrorResponse.badRequest("That calendar file is too large to import.").toResponse();
      }

      const meetings = previewIcsMeetings(ics).slice(0, MAX_IMPORT_EVENTS);
      return Response.json({ meetings }, { status: HTTP_STATUS.OK });
    } catch (error) {
      const databaseResponse = labelFailureResponse(error, { slug: "invalid-ics-preview" });
      if (databaseResponse) {
        return databaseResponse;
      }

      if (error instanceof Error) {
        const { message } = error;
        if (message.includes("BEGIN:VCALENDAR")) {
          return ErrorResponse.badRequest("Not an iCalendar file.").toResponse();
        }
      }

      return ErrorResponse.badRequest("Could not read that calendar file.").toResponse();
    }
  }),
);

export { POST };
