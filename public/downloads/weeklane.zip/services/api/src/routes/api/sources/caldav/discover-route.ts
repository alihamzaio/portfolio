import { CalDAVAuthenticationError } from "@syncforge/calendar/caldav";
import { ErrorResponse } from "@/utils/responses";
import { labelFailure, labelFailureResponse } from "@/utils/error-labelling";
import type { CalendarInfo } from "@syncforge/calendar/caldav";

interface CalDAVDiscoverCredentials {
  serverUrl: string;
  username: string;
  password: string;
}

interface CalDAVDiscoverResult {
  calendars: CalendarInfo[];
  authMethod: string;
}

interface CalDAVDiscoverRouteContext {
  body: unknown;
}

interface CalDAVDiscoverRouteDependencies {
  parseDiscoverBody: (body: unknown) => CalDAVDiscoverCredentials;
  discoverCalendars: (credentials: CalDAVDiscoverCredentials) => Promise<CalDAVDiscoverResult>;
}

const handleCalDAVDiscoverRoute = async (
  context: CalDAVDiscoverRouteContext,
  dependencies: CalDAVDiscoverRouteDependencies,
): Promise<Response> => {
  try {
    const credentials = dependencies.parseDiscoverBody(context.body);
    const { calendars, authMethod } = await dependencies.discoverCalendars(credentials);

    return Response.json({ calendars, authMethod });
  } catch (error) {
    if (error instanceof CalDAVAuthenticationError) {
      labelFailure(error, { slug: "caldav-auth-failed" });
      return ErrorResponse.unauthorized("Invalid credentials").toResponse();
    }

    const databaseResponse = labelFailureResponse(error, { slug: "caldav-connection-failed" });
    if (databaseResponse) {
      return databaseResponse;
    }

    return ErrorResponse.badRequest("Failed to discover calendars").toResponse();
  }
};

export { handleCalDAVDiscoverRoute };
export type {
  CalDAVDiscoverCredentials,
  CalDAVDiscoverResult,
  CalDAVDiscoverRouteDependencies,
};
