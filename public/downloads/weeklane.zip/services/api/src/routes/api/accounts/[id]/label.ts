import { user as userTable } from "@syncforge/database/auth-schema";
import { calendarAccountsTable } from "@syncforge/database/schema";
import { and, eq } from "drizzle-orm";
import { database } from "@/context";
import { parseCompanyColor } from "@/utils/company-color";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";

const MAX_LABEL_LENGTH = 60;

/**
 * Names the company an account belongs to, and optionally sets its meeting colour.
 * Stored per account so every user and the public page read the same values. An empty
 * name or colour clears that field and restores the derived name / automatic palette.
 */
const PUT = withWideEvent(
  withAuth(async ({ params, request, userId }) => {
    const accountId = params.id;
    if (!accountId) {
      return ErrorResponse.badRequest("Account id is required").toResponse();
    }

    const body = (await request.json().catch(() => null)) as {
      color?: unknown;
      label?: unknown;
    } | null;

    const updates: { companyColor?: string | null; companyLabel?: string | null } = {};

    if (typeof body?.label === "string") {
      const raw = body.label.trim();
      if (raw.length > MAX_LABEL_LENGTH) {
        return ErrorResponse.badRequest(
          `A company name may be at most ${MAX_LABEL_LENGTH} characters.`,
        ).toResponse();
      }
      updates.companyLabel = raw.length === 0 ? null : raw;
    }

    if (body && "color" in body) {
      const parsed = parseCompanyColor(body.color);
      if (!parsed.ok) {
        return ErrorResponse.badRequest(parsed.error).toResponse();
      }
      updates.companyColor = parsed.color;
    }

    if (updates.companyLabel === undefined && updates.companyColor === undefined) {
      return ErrorResponse.badRequest("A company name or color is required").toResponse();
    }

    const [actor] = await database
      .select({ role: userTable.role })
      .from(userTable)
      .where(eq(userTable.id, userId))
      .limit(1);
    const asAdmin = actor?.role === "admin";

    const updated = await database
      .update(calendarAccountsTable)
      .set(updates)
      .where(
        asAdmin
          ? eq(calendarAccountsTable.id, accountId)
          : and(eq(calendarAccountsTable.id, accountId), eq(calendarAccountsTable.userId, userId)),
      )
      .returning({ id: calendarAccountsTable.id });

    if (updated.length === 0) {
      return ErrorResponse.notFound("Account not found").toResponse();
    }

    return Response.json({
      color: updates.companyColor,
      id: accountId,
      label: updates.companyLabel,
    });
  }),
);

export { PUT };
