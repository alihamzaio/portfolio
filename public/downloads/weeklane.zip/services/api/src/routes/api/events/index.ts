import { HTTP_STATUS } from "@syncforge/constants";
import { createSyncForgeApi } from "@/read-models";
import { handleGetEventsInRangeRoute } from "@/handlers/event-routes";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { database, oauthProviders, refreshLockStore, encryptionKey } from "@/context";
import { eventCreateBodySchema } from "@/utils/request-body";
import { ErrorResponse } from "@/utils/responses";
import { labelFailureResponse } from "@/utils/error-labelling";

const SyncForgeApi = createSyncForgeApi(database, {
  encryptionKey,
  oauthTokenRefresher: oauthProviders,
  refreshLockStore,
});

const GET = withWideEvent(
  withAuth(({ request, userId }) => handleGetEventsInRangeRoute(request, userId, SyncForgeApi)),
);

const POST = withWideEvent(
  withAuth(async ({ request, userId }) => {
    const body = await request.json();

    try {
      const { timezone, ...input } = eventCreateBodySchema.assert(body);
      const result = await SyncForgeApi.createEvent(userId, { ...input, startTimeZone: timezone });

      if (!result.success) {
        return ErrorResponse.badRequest(result.error ?? "Failed to create event.").toResponse();
      }

      return Response.json(result.event ?? { created: true }, { status: HTTP_STATUS.CREATED });
    } catch (error) {
      const databaseResponse = labelFailureResponse(error, { slug: "invalid-request-body" });
      if (databaseResponse) {
        return databaseResponse;
      }

      return ErrorResponse.badRequest(
        "Invalid event data. calendarId, title, startTime, and endTime are required.",
      ).toResponse();
    }
  }),
);

export { GET, POST };
