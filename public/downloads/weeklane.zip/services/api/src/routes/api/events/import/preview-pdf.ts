import { HTTP_STATUS } from "@syncforge/constants";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { labelFailureResponse } from "@/utils/error-labelling";

const MAX_PDF_BYTES = 8_000_000;

const isPdfUpload = (value: FormDataEntryValue | null): value is Blob =>
  typeof value === "object"
  && value !== null
  && "arrayBuffer" in value
  && "size" in value
  && typeof (value as Blob).size === "number"
  && (value as Blob).size > 0;

const POST = withWideEvent(
  withAuth(async ({ request }) => {
    const form = await request.formData().catch(() => null);
    const file = form?.get("file") ?? null;
    if (!isPdfUpload(file)) {
      return ErrorResponse.badRequest("Upload a PDF file.").toResponse();
    }
    if (file.size > MAX_PDF_BYTES) {
      return ErrorResponse.badRequest("That PDF is too large to import.").toResponse();
    }
    const name = (file instanceof File ? file.name : "").toLowerCase();
    const type = "type" in file ? String(file.type) : "";
    if (name.length > 0 && !name.endsWith(".pdf") && type !== "application/pdf") {
      return ErrorResponse.badRequest("Upload a PDF file.").toResponse();
    }

    try {
      const { extractPdfContent } = await import("@/utils/extract-pdf");
      const bytes = new Uint8Array(await file.arrayBuffer());
      const extracted = await extractPdfContent(bytes);
      return Response.json(extracted, { status: HTTP_STATUS.OK });
    } catch (error) {
      console.error(error);
      const databaseResponse = labelFailureResponse(error, { slug: "pdf-import-preview" });
      if (databaseResponse) {
        return databaseResponse;
      }
      return ErrorResponse.internal("Could not read that PDF.").toResponse();
    }
  }),
);

export { POST };
