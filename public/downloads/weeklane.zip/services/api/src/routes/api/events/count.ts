import { createSyncForgeApi } from "@/read-models";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { database } from "@/context";

const SyncForgeApi = createSyncForgeApi(database);

export const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    const count = await SyncForgeApi.getEventCount(userId);
    return Response.json({ count });
  }),
);
