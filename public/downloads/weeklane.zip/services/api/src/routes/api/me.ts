import { user as userTable } from "@syncforge/database/auth-schema";
import { and, eq, ne } from "drizzle-orm";
import { database } from "@/context";
import { parseDisplayName, parseEmail } from "@/utils/account-profile";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { ensureManualCalendar } from "@/utils/manual-calendar";

/**
 * The signed-in account, including its role. better-auth's own session payload does not
 * carry columns added outside its schema, so the dashboard reads the role from here
 * rather than from get-session.
 */
const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    const [account] = await database
      .select({
        email: userTable.email,
        id: userTable.id,
        name: userTable.name,
        role: userTable.role,
        username: userTable.username,
      })
      .from(userTable)
      .where(eq(userTable.id, userId))
      .limit(1);

    if (!account) {
      return ErrorResponse.notFound("Account not found").toResponse();
    }

    await ensureManualCalendar(database, userId).catch((error: unknown) => {
      console.error(error);
    });

    return Response.json({
      email: account.email,
      id: account.id,
      isAdmin: account.role === "admin",
      name: account.name,
      role: account.role,
      username: account.username,
    });
  }),
);

interface UpdateProfileBody {
  email?: unknown;
  name?: unknown;
}

const PATCH = withWideEvent(
  withAuth(async ({ request, userId }) => {
    const body = (await request.json().catch(() => null)) as UpdateProfileBody | null;
    if (!body) {
      return ErrorResponse.badRequest("Name or email is required").toResponse();
    }

    const updates: { email?: string; name?: string; updatedAt: Date } = { updatedAt: new Date() };

    if (body.name !== undefined) {
      const parsed = parseDisplayName(body.name);
      if (!parsed.ok) {
        return ErrorResponse.badRequest(parsed.error).toResponse();
      }
      updates.name = parsed.name;
    }

    if (body.email !== undefined) {
      const parsed = parseEmail(body.email);
      if (!parsed.ok) {
        return ErrorResponse.badRequest(parsed.error).toResponse();
      }

      const [taken] = await database
        .select({ id: userTable.id })
        .from(userTable)
        .where(and(eq(userTable.email, parsed.email), ne(userTable.id, userId)))
        .limit(1);
      if (taken) {
        return ErrorResponse.conflict("That email is already in use.").toResponse();
      }
      updates.email = parsed.email;
    }

    if (updates.name === undefined && updates.email === undefined) {
      return ErrorResponse.badRequest("Name or email is required").toResponse();
    }

    const [account] = await database
      .update(userTable)
      .set(updates)
      .where(eq(userTable.id, userId))
      .returning({
        email: userTable.email,
        id: userTable.id,
        name: userTable.name,
        role: userTable.role,
        username: userTable.username,
      });

    if (!account) {
      return ErrorResponse.notFound("Account not found").toResponse();
    }

    await ensureManualCalendar(database, userId).catch((error: unknown) => {
      console.error(error);
    });

    return Response.json({
      email: account.email,
      id: account.id,
      isAdmin: account.role === "admin",
      name: account.name,
      role: account.role,
      username: account.username,
    });
  }),
);

export { GET, PATCH };
