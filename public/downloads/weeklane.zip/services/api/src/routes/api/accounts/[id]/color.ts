import { user as userTable } from "@syncforge/database/auth-schema";
import { calendarAccountsTable } from "@syncforge/database/schema";
import { and, eq } from "drizzle-orm";
import { database } from "@/context";
import { parseCompanyColor } from "@/utils/company-color";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";

/**
 * Sets the colour meetings from this account use on every schedule. An empty value
 * clears it and restores the automatic palette colour.
 */
const PUT = withWideEvent(
  withAuth(async ({ params, request, userId }) => {
    const accountId = params.id;
    if (!accountId) {
      return ErrorResponse.badRequest("Account id is required").toResponse();
    }

    const body = (await request.json().catch(() => null)) as { color?: unknown } | null;
    const parsed = parseCompanyColor(body?.color);
    if (!parsed.ok) {
      return ErrorResponse.badRequest(parsed.error).toResponse();
    }

    const [actor] = await database
      .select({ role: userTable.role })
      .from(userTable)
      .where(eq(userTable.id, userId))
      .limit(1);
    const asAdmin = actor?.role === "admin";

    const updated = await database
      .update(calendarAccountsTable)
      .set({ companyColor: parsed.color })
      .where(
        asAdmin
          ? eq(calendarAccountsTable.id, accountId)
          : and(eq(calendarAccountsTable.id, accountId), eq(calendarAccountsTable.userId, userId)),
      )
      .returning({ id: calendarAccountsTable.id });

    if (updated.length === 0) {
      return ErrorResponse.notFound("Account not found").toResponse();
    }

    return Response.json({ color: parsed.color, id: accountId });
  }),
);

export { PUT };
