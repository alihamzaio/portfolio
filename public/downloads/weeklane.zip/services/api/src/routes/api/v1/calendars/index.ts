import { createSyncForgeApi } from "@/read-models";
import type { SyncForgeSource } from "@/types";
import { withV1Auth, withWideEvent } from "@/utils/middleware";
import { database } from "@/context";

const SyncForgeApi = createSyncForgeApi(database);

const toCalendar = (source: SyncForgeSource) => ({
  id: source.id,
  name: source.name,
  provider: source.providerName,
  account: source.accountLabel,
});

const GET = withWideEvent(
  withV1Auth(async ({ request, userId }) => {
    const url = new URL(request.url);
    const providerFilter = url.searchParams.get("provider");

    let sources = await SyncForgeApi.listSources(userId);

    if (providerFilter) {
      const providers = new Set(providerFilter.split(",").filter(Boolean));
      sources = sources.filter((source) => providers.has(source.provider));
    }

    return Response.json(sources.map((source) => toCalendar(source)));
  }),
);

export { GET };
