import { parseCompanyColor } from "@/utils/company-color";
import { rememberPendingConnectColor } from "@/utils/pending-connect-color";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";

/**
 * Remembers the meeting colour the operator picked before the Google/Microsoft consent
 * screen. The OAuth callback applies it once the account exists.
 */
const PUT = withWideEvent(
  withAuth(async ({ request, userId }) => {
    const body = (await request.json().catch(() => null)) as { color?: unknown } | null;
    const parsed = parseCompanyColor(typeof body?.color === "string" ? body.color : "");
    if (!parsed.ok) {
      return ErrorResponse.badRequest(parsed.error).toResponse();
    }

    await rememberPendingConnectColor(userId, parsed.color);
    return Response.json({ color: parsed.color });
  }),
);

export { PUT };
