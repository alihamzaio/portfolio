import { user as userTable } from "@syncforge/database/auth-schema";
import { eq } from "drizzle-orm";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { database } from "@/context";
import { createSyncForgeApi } from "@/read-models";
import { listSources } from "@/queries/list-sources";
import { ErrorResponse } from "@/utils/responses";

const SyncForgeApi = createSyncForgeApi(database);

const GET = withWideEvent(
  withAuth(async ({ request, userId }) => {
    const allUsers = new URL(request.url).searchParams.get("all") === "1";
    if (!allUsers) {
      return Response.json(await SyncForgeApi.listSources(userId));
    }

    const [account] = await database
      .select({ role: userTable.role })
      .from(userTable)
      .where(eq(userTable.id, userId))
      .limit(1);
    if (account?.role !== "admin") {
      return ErrorResponse.forbidden("Only an administrator can manage calendars.").toResponse();
    }

    return Response.json(await listSources(database, userId, { allUsers: true }));
  }),
);

export { GET };
