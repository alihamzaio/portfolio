import { type } from "arktype";
import { userEventsTable } from "@syncforge/database/schema";
import { and, eq } from "drizzle-orm";
import { HTTP_STATUS } from "@syncforge/constants";
import { createSyncForgeApi } from "@/read-models";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { database, oauthProviders, refreshLockStore, encryptionKey } from "@/context";
import { eventsImportBodySchema } from "@/utils/request-body";
import { ErrorResponse } from "@/utils/responses";
import { labelFailureResponse } from "@/utils/error-labelling";
import { ensureManualCalendar } from "@/utils/manual-calendar";
import { filterNewMeetings, MAX_IMPORT_EVENTS } from "@/utils/import-meetings";

const SyncForgeApi = createSyncForgeApi(database, {
  encryptionKey,
  oauthTokenRefresher: oauthProviders,
  refreshLockStore,
});

const POST = withWideEvent(
  withAuth(async ({ request, userId }) => {
    const body = await request.json().catch(() => null);
    const parsed = eventsImportBodySchema(body);
    if (parsed instanceof type.errors) {
      return ErrorResponse.badRequest(
        "Invalid import. Send a list of meetings with title, startTime, and endTime.",
      ).toResponse();
    }
    const { events } = parsed;

    if (events.length === 0) {
      return ErrorResponse.badRequest("Select at least one meeting to import.").toResponse();
    }
    if (events.length > MAX_IMPORT_EVENTS) {
      return ErrorResponse.badRequest(`Import at most ${MAX_IMPORT_EVENTS} meetings at a time.`).toResponse();
    }

    try {
      const calendar = await ensureManualCalendar(database, userId);
      const existing = await database
        .select({
          startTime: userEventsTable.startTime,
          title: userEventsTable.title,
        })
        .from(userEventsTable)
        .where(
          and(eq(userEventsTable.calendarId, calendar.id), eq(userEventsTable.userId, userId)),
        );

      const { next, skipped } = filterNewMeetings(events, existing);
      let imported = 0;
      let failed = 0;

      for (const draft of next) {
        const result = await SyncForgeApi.createEvent(userId, {
          calendarId: calendar.id,
          ...(draft.description && { description: draft.description }),
          endTime: draft.endTime,
          isAllDay: draft.isAllDay === true,
          ...(draft.location && { location: draft.location }),
          startTime: draft.startTime,
          title: draft.title,
        });
        if (result.success) {
          imported += 1;
        } else {
          failed += 1;
        }
      }

      return Response.json(
        { failed, imported, skipped },
        { status: HTTP_STATUS.OK },
      );
    } catch (error) {
      const databaseResponse = labelFailureResponse(error, { slug: "event-import" });
      if (databaseResponse) {
        return databaseResponse;
      }
      return ErrorResponse.internal("Could not import those meetings.").toResponse();
    }
  }),
);

export { POST };
