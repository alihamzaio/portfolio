import { createSyncForgeApi } from "@/read-models";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { database } from "@/context";

const SyncForgeApi = createSyncForgeApi(database);

const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    const destinations = await SyncForgeApi.getSyncStatuses(userId);
    return Response.json({ destinations });
  }),
);

export { GET };
