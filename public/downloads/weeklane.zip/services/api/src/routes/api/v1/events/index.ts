import { HTTP_STATUS } from "@syncforge/constants";
import { normalizeDateRange, parseDateRangeParams } from "@/utils/date-range";
import { withEventReadErrorHandling } from "@/utils/event-read-errors";
import { createSyncForgeApi } from "@/read-models";
import type { SyncForgeEventFilters } from "@/types";
import { withV1Auth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { labelFailureResponse } from "@/utils/error-labelling";
import { eventCreateBodySchema } from "@/utils/request-body";
import { database, oauthProviders, refreshLockStore, encryptionKey } from "@/context";

const SyncForgeApi = createSyncForgeApi(database, {
  oauthTokenRefresher: oauthProviders,
  refreshLockStore,
  encryptionKey,
});

const parseEventFilters = (url: URL): SyncForgeEventFilters => {
  const filters: SyncForgeEventFilters = {};

  const calendarId = url.searchParams.get("calendarId");
  if (calendarId) {
    filters.calendarId = calendarId.split(",").filter(Boolean);
  }

  const availability = url.searchParams.get("availability");
  if (availability) {
    filters.availability = availability.split(",").filter(Boolean);
  }

  const isAllDay = url.searchParams.get("isAllDay");
  if (isAllDay === "true") {
    filters.isAllDay = true;
  } else if (isAllDay === "false") {
    filters.isAllDay = false;
  }

  return filters;
};

const GET = withWideEvent(
  withV1Auth(({ request, userId }) => withEventReadErrorHandling(async () => {
    const url = new URL(request.url);
    const { from, to } = parseDateRangeParams(url);
    const { end, start } = normalizeDateRange(from, to);
    const shouldCount = url.searchParams.get("count") === "true";

    if (shouldCount) {
      const count = await SyncForgeApi.getEventCount(userId, { from: start, to: end });
      return Response.json({ count });
    }

    const filters = parseEventFilters(url);
    const events = await SyncForgeApi.getEventsInRange(
      userId,
      { from: start, to: end },
      filters,
    );
    return Response.json(events);
  })),
);

const POST = withWideEvent(
  withV1Auth(async ({ request, userId }) => {
    const body = await request.json();

    try {
      const { timezone, ...input } = eventCreateBodySchema.assert(body);

      const result = await SyncForgeApi.createEvent(userId, { ...input, startTimeZone: timezone });

      if (!result.success) {
        return ErrorResponse.badRequest(result.error ?? "Failed to create event.").toResponse();
      }

      return Response.json(result.event ?? { created: true }, { status: HTTP_STATUS.CREATED });
    } catch (error) {
      const databaseResponse = labelFailureResponse(error, { slug: "invalid-request-body" });
      if (databaseResponse) {
        return databaseResponse;
      }

      return ErrorResponse.badRequest("Invalid event data. calendarId, title, startTime, and endTime are required.").toResponse();
    }
  }),
);

export { GET, POST };
