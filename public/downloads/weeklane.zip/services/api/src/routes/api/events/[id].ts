import { HTTP_STATUS } from "@syncforge/constants";
import { createSyncForgeApi } from "@/read-models";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { labelFailureResponse } from "@/utils/error-labelling";
import { eventPatchBodySchema } from "@/utils/request-body";
import { database, oauthProviders, refreshLockStore, encryptionKey } from "@/context";

const SyncForgeApi = createSyncForgeApi(database, {
  encryptionKey,
  oauthTokenRefresher: oauthProviders,
  refreshLockStore,
});

const PATCH = withWideEvent(
  withAuth(async ({ request, params, userId }) => {
    const eventId = params.id;
    if (!eventId) {
      return ErrorResponse.badRequest("Event ID is required.").toResponse();
    }

    const body = await request.json();

    try {
      const validated = eventPatchBodySchema.assert(body);

      if (validated.rsvpStatus) {
        const result = await SyncForgeApi.rsvpEvent(userId, eventId, validated.rsvpStatus);
        if (!result.success) {
          return ErrorResponse.badRequest(result.error ?? "Failed to update RSVP status.").toResponse();
        }
        return Response.json({ rsvpStatus: validated.rsvpStatus });
      }

      const result = await SyncForgeApi.updateEvent(userId, eventId, {
        title: validated.title,
        description: validated.description,
        location: validated.location,
        startTime: validated.startTime,
        endTime: validated.endTime,
        isAllDay: validated.isAllDay,
        availability: validated.availability,
        startTimeZone: validated.timezone,
      });

      if (!result.success) {
        return ErrorResponse.badRequest(result.error ?? "Failed to update event.").toResponse();
      }

      const updated = await SyncForgeApi.getEvent(userId, eventId);
      return Response.json(updated);
    } catch (error) {
      const databaseResponse = labelFailureResponse(error, { slug: "invalid-request-body" });
      if (databaseResponse) {
        return databaseResponse;
      }

      return ErrorResponse.badRequest("Invalid update data.").toResponse();
    }
  }),
);

const DELETE = withWideEvent(
  withAuth(async ({ params, userId }) => {
    const eventId = params.id;
    if (!eventId) {
      return ErrorResponse.badRequest("Event ID is required.").toResponse();
    }

    const result = await SyncForgeApi.deleteEvent(userId, eventId);
    if (!result.success) {
      return ErrorResponse.badRequest(result.error ?? "Failed to delete event.").toResponse();
    }

    return new Response(null, { status: HTTP_STATUS.NO_CONTENT });
  }),
);

export { PATCH, DELETE };
