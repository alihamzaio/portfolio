import { user as userTable } from "@syncforge/database/auth-schema";
import { appSettingsTable, PUBLIC_SCHEDULE_SETTING } from "@syncforge/database/schema";
import { eq } from "drizzle-orm";
import { database } from "@/context";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";

/**
 * Controls the sign-in-free schedule page.
 *
 * Enabling it publishes meeting titles, times and company names to anyone who knows the
 * URL, so it is off unless switched on, only an administrator may switch it, and turning
 * it off takes effect on the next request.
 */
const isAdmin = async (userId: string): Promise<boolean> => {
  const [account] = await database
    .select({ role: userTable.role })
    .from(userTable)
    .where(eq(userTable.id, userId))
    .limit(1);
  return account?.role === "admin";
};

const readSetting = async (): Promise<boolean> => {
  const [row] = await database
    .select({ value: appSettingsTable.value })
    .from(appSettingsTable)
    .where(eq(appSettingsTable.key, PUBLIC_SCHEDULE_SETTING))
    .limit(1);
  return row?.value === "true";
};

const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    if (!(await isAdmin(userId))) {
      return ErrorResponse.forbidden("Only an administrator can read this setting.")
        .toResponse();
    }
    return Response.json({ enabled: await readSetting() });
  }),
);

const PUT = withWideEvent(
  withAuth(async ({ request, userId }) => {
    if (!(await isAdmin(userId))) {
      return ErrorResponse.forbidden(
        "Only an administrator can change the public schedule.",
      ).toResponse();
    }

    const body = (await request.json().catch(() => null)) as { enabled?: unknown } | null;
    if (typeof body?.enabled !== "boolean") {
      return ErrorResponse.badRequest("`enabled` must be true or false.").toResponse();
    }

    const value = String(body.enabled);
    await database
      .insert(appSettingsTable)
      .values({ key: PUBLIC_SCHEDULE_SETTING, value })
      .onConflictDoUpdate({
        set: { updatedAt: new Date(), value },
        target: appSettingsTable.key,
      });

    return Response.json({ enabled: body.enabled });
  }),
);

export { GET, PUT, readSetting };
