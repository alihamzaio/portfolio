import { user as userTable } from "@syncforge/database/auth-schema";
import { database } from "@/context";
import { getEventsInRangeForSources } from "@/queries/get-events-in-range";
import { listSources } from "@/queries/list-sources";
import { normalizeDateRange, parseDateRangeParams } from "@/utils/date-range";
import { withEventReadErrorHandling } from "@/utils/event-read-errors";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { resolveCompanyName } from "@/utils/company-name";

/**
 * The combined team schedule: every connected calendar from every account, in one list.
 *
 * Sources and owner names load once; events load once across those calendars. Recurring
 * events are still expanded inside the shared read model, so this stays aligned with a
 * single-user listing instead of growing a second expander.
 *
 * Any signed-in account may read this, member or admin: it is the shared view of who is
 * busy when. Join links are not part of the payload consumers render for it -- the
 * dashboard hides them on this view -- and no calendar is ever modified.
 */
const GET = withWideEvent(
  withAuth(({ request }) => withEventReadErrorHandling(async () => {
    const url = new URL(request.url);
    const { from, to } = parseDateRangeParams(url);
    const { end, start } = normalizeDateRange(from, to);

    const [accounts, sources] = await Promise.all([
      database
        .select({ id: userTable.id, name: userTable.name, username: userTable.username })
        .from(userTable),
      listSources(database, "", { allUsers: true }),
    ]);

    const events = await getEventsInRangeForSources(database, sources, { from: start, to: end });
    const byCalendar = new Map(sources.map((source) => [source.id, source]));
    const byUser = new Map(accounts.map((account) => [account.id, account]));

    const merged = events
      .map((event) => {
        const source = byCalendar.get(event.calendarId);
        const owner = source ? byUser.get(source.userId) : undefined;
        return {
          ...event,
          /*
           * For an ICS account the calendar URL *is* the secret feed URL, so spreading
           * the event wholesale handed every signed-in user a permanent read credential
           * for someone else's calendar. Nothing in the dashboard reads this field.
           */
          calendarUrl: null,
          accountEmail: source?.email ?? null,
          accountId: source?.accountId ?? null,
          /*
           * The resolved company name, never the raw account identifier. For an ICS
           * account that identifier is the feed URL, whose token grants permanent read
           * access to the whole calendar -- sending it to every signed-in user handed
           * out a credential that cannot be revoked without regenerating the feed.
           */
          accountName: source ? resolveCompanyName(source) : null,
          companyColor: source?.companyColor ?? null,
          calendarTimeZone: source?.timeZone ?? null,
          ownerId: owner?.id ?? source?.userId ?? null,
          ownerName: owner?.name ?? "",
          ownerUsername: owner?.username ?? null,
        };
      })
      .sort((left, right) => left.startTime.localeCompare(right.startTime));

    return Response.json(merged, {
      headers: {
        // Short private cache: week navigation feels instant without serving stale day data long.
        "Cache-Control": "private, max-age=10, stale-while-revalidate=30",
      },
    });
  })),
);

export { GET };
