import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { checkAndClaimImmediateIngest } from "@/utils/sync-trigger-limit";
import { runImmediateIngest } from "@/utils/immediate-ingest";
import { spawnBackgroundJob } from "@/utils/background-task";
import { redis } from "@/context";
import { widelog } from "@/utils/logging";

const POST = withWideEvent(
  withAuth(async ({ userId }) => {
    const cooldown = await checkAndClaimImmediateIngest(redis, userId);

    if (!cooldown.allowed) {
      widelog.set("sync_now.throttled", true);
      widelog.set("sync_now.retry_after_seconds", cooldown.retryAfterSeconds);
      const throttled = ErrorResponse.tooManyRequests(
        `A sync was already requested recently. Try again in ${cooldown.retryAfterSeconds} seconds.`,
      ).toResponse();
      throttled.headers.set("Retry-After", String(cooldown.retryAfterSeconds));
      return throttled;
    }

    spawnBackgroundJob("sync-now", { "user.id": userId }, async () => {
      const result = await runImmediateIngest(userId);
      widelog.set("sync_now.ingested", result.ingested);
      widelog.set("sync_now.queued", result.queued);
      widelog.set("sync_now.failed", result.failed);
    });

    return Response.json({ started: true });
  }),
);

export { POST };
