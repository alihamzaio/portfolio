import { createSyncForgeApi } from "@/read-models";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { database } from "@/context";
import { ensureManualCalendar, isWritableSource } from "@/utils/manual-calendar";

const SyncForgeApi = createSyncForgeApi(database);

const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    await ensureManualCalendar(database, userId);
    const sources = await SyncForgeApi.listSources(userId);
    const writable = sources.filter((source) => isWritableSource(source));
    writable.sort((left, right) => {
      if (left.provider === "manual" && right.provider !== "manual") {
        return -1;
      }
      if (right.provider === "manual" && left.provider !== "manual") {
        return 1;
      }
      return left.name.localeCompare(right.name);
    });
    return Response.json(writable);
  }),
);

export { GET };
