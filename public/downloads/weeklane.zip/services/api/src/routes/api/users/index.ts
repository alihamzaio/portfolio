import { user as userTable } from "@syncforge/database/auth-schema";
import { calendarsTable } from "@syncforge/database/schema";
import { count, eq } from "drizzle-orm";
import { auth, baseUrl, database } from "@/context";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { createUserFailureMessage, MINIMUM_PASSWORD_LENGTH } from "@/utils/user-errors";

const ROLES = new Set(["admin", "member"]);

const isAdmin = async (userId: string): Promise<boolean> => {
  const [account] = await database
    .select({ role: userTable.role })
    .from(userTable)
    .where(eq(userTable.id, userId))
    .limit(1);
  return account?.role === "admin";
};

const forbidden = (): Response =>
  ErrorResponse.forbidden("Only an administrator can manage users.").toResponse();

const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    if (!(await isAdmin(userId))) {
      return forbidden();
    }

    // Calendar counts come from the same query so the panel can show at a glance who has
    // actually connected anything.
    const rows = await database
      .select({
        calendars: count(calendarsTable.id),
        createdAt: userTable.createdAt,
        email: userTable.email,
        id: userTable.id,
        name: userTable.name,
        role: userTable.role,
        username: userTable.username,
      })
      .from(userTable)
      .leftJoin(calendarsTable, eq(calendarsTable.userId, userTable.id))
      .groupBy(userTable.id)
      .orderBy(userTable.createdAt);

    return Response.json(rows);
  }),
);

interface CreateUserBody {
  email?: unknown;
  username?: unknown;
  password?: unknown;
  name?: unknown;
  role?: unknown;
}

const POST = withWideEvent(
  withAuth(async ({ request, userId }) => {
    if (!(await isAdmin(userId))) {
      return forbidden();
    }

    const body = (await request.json().catch(() => null)) as CreateUserBody | null;
    const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
    const username = typeof body?.username === "string" ? body.username.trim() : "";
    const password = typeof body?.password === "string" ? body.password : "";
    const name = typeof body?.name === "string" && body.name.trim().length > 0
      ? body.name.trim()
      : "";
    const role = typeof body?.role === "string" ? body.role : "member";

    if (email.length === 0 && username.length < 3) {
      return ErrorResponse.badRequest("Email is required.").toResponse();
    }
    if (password.length < MINIMUM_PASSWORD_LENGTH) {
      return ErrorResponse.badRequest(
        `Password must be at least ${MINIMUM_PASSWORD_LENGTH} characters.`,
      ).toResponse();
    }
    if (!ROLES.has(role)) {
      return ErrorResponse.badRequest("Role must be admin or member.").toResponse();
    }

    const signUpBody = email.length > 0
      ? { email, name: name || undefined, password }
      : { name: name || username, password, username };

    // Created through the auth handler rather than a direct insert, so password hashing
    // and the account rows land in exactly the shape sign-in expects. The plugin's typed
    // API is not surfaced on `auth.api`, hence the internal request.
    const signUp = await auth.handler(
      new Request(new URL("/api/auth/username-only/sign-up", baseUrl).toString(), {
        body: JSON.stringify(signUpBody),
        headers: { "Content-Type": "application/json" },
        method: "POST",
      }),
    );

    if (!signUp.ok) {
      const detail = await signUp.json().catch(() => null);
      return ErrorResponse.badRequest(createUserFailureMessage(detail)).toResponse();
    }

    const created = (await signUp.json().catch(() => null)) as { user?: { email?: string; id?: string } } | null;
    const createdEmail = created?.user?.email ?? email;
    const createdId = created?.user?.id;

    if (role === "admin") {
      if (createdId) {
        await database.update(userTable).set({ role }).where(eq(userTable.id, createdId));
      } else if (createdEmail) {
        await database.update(userTable).set({ role }).where(eq(userTable.email, createdEmail));
      }
    }

    return Response.json({ email: createdEmail, role });
  }),
);

export { GET, POST };
