import { appSettingsTable, PUBLIC_SCHEDULE_SETTING } from "@syncforge/database/schema";
import { eq } from "drizzle-orm";
import { database } from "@/context";
import { getEventsInRangeForSources } from "@/queries/get-events-in-range";
import { listSources } from "@/queries/list-sources";
import { normalizeDateRange, parseDateRangeParams } from "@/utils/date-range";
import { withEventReadErrorHandling } from "@/utils/event-read-errors";
import { withWideEvent } from "@/utils/middleware";
import { resolveCompanyName } from "@/utils/company-name";
import { ErrorResponse } from "@/utils/responses";

const PUBLIC_SCHEDULE_CACHE_MS = 30_000;
const PUBLIC_SCHEDULE_CACHE_CONTROL = "public, max-age=30, stale-while-revalidate=60";

interface PublicScheduleCompany {
  color: string | null;
  key: string;
  name: string;
}

interface PublicScheduleEvent {
  attendees: unknown;
  company: string | null;
  companyColor: string | null;
  companyKey: string;
  endTime: string;
  id: string;
  organizer: string | null;
  provider: string;
  startTime: string;
  title: string | null;
}

interface PublicSchedulePayload {
  companies: PublicScheduleCompany[];
  events: PublicScheduleEvent[];
}

interface PublicScheduleCacheEntry {
  expiresAt: number;
  payload: PublicSchedulePayload;
}

const payloadCache = new Map<string, PublicScheduleCacheEntry>();

/**
 * The team schedule, served without sign-in.
 *
 * Deliberately narrower than the authenticated feed. Anyone holding the URL can read this,
 * so it carries only what a shared wall-planner needs -- when someone is busy, under which
 * company, and what the meeting is called. Everything that could be acted on or leaked is
 * withheld:
 *
 *   - no descriptions. This is what actually enforces "no join links": every one of these
 *     calendars puts the Meet URL in the description, so publishing it would hand out
 *     entry to the calls. Dial-in PINs and agenda documents live there too.
 *   - no meeting links
 *   - no locations
 *   - no calendar identifiers, and never the feed URL, whose token grants full read access
 *
 * Off unless an administrator enables it, and answers 404 rather than 403 when disabled:
 * a disabled page should not advertise that it exists.
 *
 * One sources query plus one events query for every calendar, not a fan-out per account.
 */
const isEnabled = async (): Promise<boolean> => {
  const [row] = await database
    .select({ value: appSettingsTable.value })
    .from(appSettingsTable)
    .where(eq(appSettingsTable.key, PUBLIC_SCHEDULE_SETTING))
    .limit(1);
  return row?.value === "true";
};

const cachedPayload = (key: string): PublicSchedulePayload | null => {
  const entry = payloadCache.get(key);
  if (!entry) {
    return null;
  }
  if (entry.expiresAt <= Date.now()) {
    payloadCache.delete(key);
    return null;
  }
  return entry.payload;
};

const jsonSchedule = (payload: PublicSchedulePayload): Response =>
  Response.json(payload, {
    headers: { "Cache-Control": PUBLIC_SCHEDULE_CACHE_CONTROL },
  });

const GET = withWideEvent(({ request }) => withEventReadErrorHandling(async () => {
  const url = new URL(request.url);
  const { from, to } = parseDateRangeParams(url);
  const { end, start } = normalizeDateRange(from, to);
  const cacheKey = `${start.toISOString()}:${end.toISOString()}`;
  const hit = cachedPayload(cacheKey);
  if (hit) {
    return jsonSchedule(hit);
  }

  const [enabled, sources] = await Promise.all([
    isEnabled(),
    listSources(database, "", { allUsers: true }),
  ]);

  if (!enabled) {
    return ErrorResponse.notFound("Not found").toResponse();
  }

  const byCalendar = new Map(sources.map((source) => [source.id, source]));
  const events = await getEventsInRangeForSources(database, sources, { from: start, to: end });

  const companiesByKey = new Map<string, PublicScheduleCompany>();
  for (const source of sources) {
    if (companiesByKey.has(source.accountId)) {
      continue;
    }
    companiesByKey.set(source.accountId, {
      color: source.companyColor ?? null,
      key: source.accountId,
      name: resolveCompanyName(source) ?? "Other",
    });
  }

  const payload: PublicSchedulePayload = {
    companies: [...companiesByKey.values()].sort((left, right) =>
      left.name.localeCompare(right.name),
    ),
    events: events
      .map((event) => {
        const source = byCalendar.get(event.calendarId);
        return {
          attendees: event.attendees,
          company: source ? resolveCompanyName(source) : null,
          companyColor: source?.companyColor ?? null,
          companyKey: source?.accountId ?? "unknown",
          endTime: event.endTime,
          id: event.id,
          organizer: event.organizer,
          provider: event.calendarProvider,
          startTime: event.startTime,
          title: event.title,
        };
      })
      .sort((left, right) => left.startTime.localeCompare(right.startTime)),
  };

  payloadCache.set(cacheKey, {
    expiresAt: Date.now() + PUBLIC_SCHEDULE_CACHE_MS,
    payload,
  });

  return jsonSchedule(payload);
}));

export { GET };
