import { calendarsTable } from "@syncforge/database/schema";
import { and, eq } from "drizzle-orm";
import { database } from "@/context";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";

/**
 * Sets a calendar's timezone correction: "the wall-clock times published by this feed
 * were actually entered in this zone".
 *
 * This exists for a misconfigured source. A calendar whose own timezone is UTC, but whose
 * owner types local times into it, publishes instants five hours adrift from what was
 * meant. Recording the intended zone lets the dashboard show the meeting at the hour the
 * person meant, without editing anyone's calendar.
 *
 * Stored, never applied here: the ingested instants stay exactly as published, and the
 * correction is applied when rendering. That keeps the change reversible -- clearing it
 * restores the published times -- and keeps the stored data faithful to the source.
 */
const isUsableTimeZone = (candidate: string): boolean => {
  try {
    new Intl.DateTimeFormat("en-GB", { timeZone: candidate });
    return true;
  } catch {
    return false;
  }
};

const PUT = withWideEvent(
  withAuth(async ({ params, request, userId }) => {
    const calendarId = params.id;
    if (!calendarId) {
      return ErrorResponse.badRequest("Calendar id is required").toResponse();
    }

    const body = (await request.json().catch(() => null)) as { timeZone?: unknown } | null;
    const raw = typeof body?.timeZone === "string" ? body.timeZone.trim() : "";
    const timeZone = raw.length === 0 ? null : raw;

    if (timeZone !== null && !isUsableTimeZone(timeZone)) {
      return ErrorResponse.badRequest(`Unknown timezone: ${timeZone}`).toResponse();
    }

    const updated = await database
      .update(calendarsTable)
      .set({ timeZone })
      .where(and(eq(calendarsTable.id, calendarId), eq(calendarsTable.userId, userId)))
      .returning({ id: calendarsTable.id });

    if (updated.length === 0) {
      return ErrorResponse.notFound("Calendar not found").toResponse();
    }

    return Response.json({ id: calendarId, timeZone });
  }),
);

export { PUT };
