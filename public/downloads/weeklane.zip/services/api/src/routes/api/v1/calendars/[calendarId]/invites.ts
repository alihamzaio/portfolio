import { normalizeDateRange, parseDateRangeParams } from "@/utils/date-range";
import { createSyncForgeApi } from "@/read-models";
import { withV1Auth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { database, oauthProviders, refreshLockStore, encryptionKey } from "@/context";

const SyncForgeApi = createSyncForgeApi(database, {
  oauthTokenRefresher: oauthProviders,
  refreshLockStore,
  encryptionKey,
});

const GET = withWideEvent(
  withV1Auth(async ({ request, params, userId }) => {
    const { calendarId } = params;
    if (!calendarId) {
      return ErrorResponse.badRequest("Calendar ID is required.").toResponse();
    }

    const url = new URL(request.url);
    const { from, to } = parseDateRangeParams(url);
    const { start, end } = normalizeDateRange(from, to);

    const invites = await SyncForgeApi.getPendingInvites(
      userId,
      calendarId,
      start.toISOString(),
      end.toISOString(),
    );

    return Response.json(invites);
  }),
);

export { GET };
