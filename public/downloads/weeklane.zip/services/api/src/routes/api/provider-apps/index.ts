import { providerAppsTable } from "@syncforge/database/schema";
import { encryptPassword } from "@syncforge/database";
import { eq } from "drizzle-orm";
import { user as userTable } from "@syncforge/database/auth-schema";
import { database, encryptionKey, reloadOAuthProviders } from "@/context";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";

const SUPPORTED_PROVIDERS = new Set(["google"]);

/**
 * These credentials belong to the instance, not to a user: whoever holds them controls
 * where every OAuth connection is sent. A member could otherwise point the whole instance
 * at an app they own, or break everyone's connections by overwriting them.
 */
const isAdmin = async (userId: string): Promise<boolean> => {
  const [account] = await database
    .select({ role: userTable.role })
    .from(userTable)
    .where(eq(userTable.id, userId))
    .limit(1);
  return account?.role === "admin";
};

const forbidden = (): Response =>
  ErrorResponse.forbidden("Only an administrator can manage connection apps.").toResponse();

const CONFIG_KEYS: Record<string, string> = { google: "google" };

interface SaveProviderAppBody {
  provider?: unknown;
  clientId?: unknown;
  clientSecret?: unknown;
}

const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    const rows = await database
      .select({
        clientId: providerAppsTable.clientId,
        provider: providerAppsTable.provider,
        updatedAt: providerAppsTable.updatedAt,
      })
      .from(providerAppsTable);

    // Members need to know which Connect buttons to light up. The client ID is only for
    // administrators editing Settings; the secret never leaves the server.
    const admin = await isAdmin(userId);
    return Response.json(
      rows.map((row) => ({
        clientId: admin ? row.clientId : "",
        configured: true,
        provider: row.provider,
        updatedAt: row.updatedAt,
      })),
    );
  }),
);

const PUT = withWideEvent(
  withAuth(async ({ request, userId }) => {
    if (!(await isAdmin(userId))) {
      return forbidden();
    }

    if (!encryptionKey) {
      return ErrorResponse.badRequest(
        "ENCRYPTION_KEY is not set, so client secrets cannot be stored safely.",
      ).toResponse();
    }

    const body = (await request.json().catch(() => null)) as SaveProviderAppBody | null;
    const provider = typeof body?.provider === "string" ? body.provider : "";
    const clientId = typeof body?.clientId === "string" ? body.clientId.trim() : "";
    const clientSecret = typeof body?.clientSecret === "string" ? body.clientSecret.trim() : "";

    if (!SUPPORTED_PROVIDERS.has(provider)) {
      return ErrorResponse.badRequest("Unsupported provider").toResponse();
    }
    if (clientId.length === 0) {
      return ErrorResponse.badRequest("A client ID is required.").toResponse();
    }

    const storedProvider = CONFIG_KEYS[provider] ?? provider;

    // An empty secret on an existing app means "keep the stored one", so the client ID can
    // be corrected without re-entering a secret the operator may no longer have to hand.
    if (clientSecret.length === 0) {
      const [existing] = await database
        .select({ id: providerAppsTable.id })
        .from(providerAppsTable)
        .where(eq(providerAppsTable.provider, storedProvider))
        .limit(1);

      if (!existing) {
        return ErrorResponse.badRequest("A client secret is required the first time.").toResponse();
      }

      await database
        .update(providerAppsTable)
        .set({ clientId, updatedAt: new Date() })
        .where(eq(providerAppsTable.provider, storedProvider));

      await reloadOAuthProviders();
      return Response.json({ configured: true, provider });
    }

    const clientSecretEncrypted = encryptPassword(clientSecret, encryptionKey);

    await database
      .insert(providerAppsTable)
      .values({ clientId, clientSecretEncrypted, provider: storedProvider })
      .onConflictDoUpdate({
        set: { clientId, clientSecretEncrypted, updatedAt: new Date() },
        target: providerAppsTable.provider,
      });

    // Without this the new credentials would only take effect on the next API restart,
    // which is exactly what storing them in the database is meant to avoid.
    await reloadOAuthProviders();

    return Response.json({ configured: true, provider });
  }),
);

const DELETE = withWideEvent(
  withAuth(async ({ request, userId }) => {
    if (!(await isAdmin(userId))) {
      return forbidden();
    }

    const provider = new URL(request.url).searchParams.get("provider") ?? "";
    if (!SUPPORTED_PROVIDERS.has(provider)) {
      return ErrorResponse.badRequest("Unsupported provider").toResponse();
    }

    await database
      .delete(providerAppsTable)
      .where(eq(providerAppsTable.provider, CONFIG_KEYS[provider] ?? provider));

    await reloadOAuthProviders();

    return Response.json({ configured: false, provider });
  }),
);

export { GET, PUT, DELETE };
