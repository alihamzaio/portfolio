import { calendarAccountsTable } from "@syncforge/database/schema";
import { and, eq } from "drizzle-orm";
import { createSourceSchema } from "@syncforge/data-schemas";
import { database } from "@/context";
import { parseCompanyColor } from "@/utils/company-color";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import {
  InvalidSourceUrlError,
  SourceLimitError,
  createSource,
  getUserSources,
} from "@/utils/sources";
import {
  handleGetIcsSourcesRoute,
  handlePostIcsSourceRoute,
} from "./source-routes";

const GET = withWideEvent(
  withAuth(({ userId }) =>
    handleGetIcsSourcesRoute(
      { userId },
      {
        getUserSources,
      },
    )),
);

const POST = withWideEvent(
  withAuth(async ({ request, userId }) => {
    const body = await request.json();
    let colorToStore: string | null | undefined;
    try {
      const parsed = createSourceSchema.assert(body);
      if (parsed.color !== undefined) {
        const colour = parseCompanyColor(parsed.color);
        if (!colour.ok) {
          return ErrorResponse.badRequest(colour.error).toResponse();
        }
        colorToStore = colour.color;
      }
    } catch {
      // handlePostIcsSourceRoute already maps a parse failure to a 400.
    }

    return handlePostIcsSourceRoute(
      { body, userId },
      {
        createSource: async (ownerId, name, url) => {
          const source = await createSource(ownerId, name, url);
          if (colorToStore) {
            await database
              .update(calendarAccountsTable)
              .set({ companyColor: colorToStore })
              .where(
                and(
                  eq(calendarAccountsTable.id, source.accountId),
                  eq(calendarAccountsTable.userId, ownerId),
                ),
              );
          }
          return source;
        },
        isInvalidSourceUrlError: (error): error is InvalidSourceUrlError =>
          error instanceof InvalidSourceUrlError,
        isSourceLimitError: (error): error is SourceLimitError =>
          error instanceof SourceLimitError,
        parseCreateSourceBody: (value) => createSourceSchema.assert(value),
      },
    );
  }),
);

export { GET, POST };
