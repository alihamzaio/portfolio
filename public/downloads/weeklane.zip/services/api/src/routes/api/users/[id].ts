import {
  account as accountTable,
  session as sessionTable,
  user as userTable,
} from "@syncforge/database/auth-schema";
import { hashPassword } from "better-auth/crypto";
import { and, eq, ne } from "drizzle-orm";
import { database } from "@/context";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";
import { parsePassword } from "@/utils/user-errors";

const ROLES = new Set(["admin", "member"]);

const isAdmin = async (userId: string): Promise<boolean> => {
  const [account] = await database
    .select({ role: userTable.role })
    .from(userTable)
    .where(eq(userTable.id, userId))
    .limit(1);
  return account?.role === "admin";
};

const forbidden = (): Response =>
  ErrorResponse.forbidden("Only an administrator can manage users.").toResponse();

/**
 * Guards against an instance with no administrator left, which no one could recover from
 * through the UI: demoting or deleting the last admin is refused.
 */
const otherAdminExists = async (excludingUserId: string): Promise<boolean> => {
  const [other] = await database
    .select({ id: userTable.id })
    .from(userTable)
    .where(and(eq(userTable.role, "admin"), ne(userTable.id, excludingUserId)))
    .limit(1);
  return Boolean(other);
};

const PATCH = withWideEvent(
  withAuth(async ({ params, request, userId }) => {
    if (!(await isAdmin(userId))) {
      return forbidden();
    }

    const targetId = params.id;
    if (!targetId) {
      return ErrorResponse.badRequest("User id is required").toResponse();
    }

    const body = (await request.json().catch(() => null)) as {
      password?: unknown;
      role?: unknown;
    } | null;
    if (!body) {
      return ErrorResponse.badRequest("Role or password is required.").toResponse();
    }

    const wantsRole = typeof body.role === "string" && body.role.length > 0;
    const wantsPassword = body.password !== undefined;
    if (!wantsRole && !wantsPassword) {
      return ErrorResponse.badRequest("Role or password is required.").toResponse();
    }

    if (wantsRole) {
      const role = body.role as string;
      if (!ROLES.has(role)) {
        return ErrorResponse.badRequest("Role must be admin or member.").toResponse();
      }
      if (role === "member" && !(await otherAdminExists(targetId))) {
        return ErrorResponse.badRequest("This is the only administrator.").toResponse();
      }

      const updated = await database
        .update(userTable)
        .set({ role })
        .where(eq(userTable.id, targetId))
        .returning({ id: userTable.id });

      if (updated.length === 0) {
        return ErrorResponse.notFound("User not found").toResponse();
      }
    }

    if (wantsPassword) {
      const parsed = parsePassword(body.password);
      if (!parsed.ok) {
        return ErrorResponse.badRequest(parsed.error).toResponse();
      }

      const hashed = await hashPassword(parsed.password);
      const updated = await database
        .update(accountTable)
        .set({ password: hashed, updatedAt: new Date() })
        .where(and(eq(accountTable.userId, targetId), eq(accountTable.providerId, "credential")))
        .returning({ id: accountTable.id });

      if (updated.length === 0) {
        return ErrorResponse.notFound("User has no password login.").toResponse();
      }

      await database.delete(sessionTable).where(eq(sessionTable.userId, targetId));
    }

    const [account] = await database
      .select({ role: userTable.role })
      .from(userTable)
      .where(eq(userTable.id, targetId))
      .limit(1);

    if (!account) {
      return ErrorResponse.notFound("User not found").toResponse();
    }

    return Response.json({
      id: targetId,
      passwordReset: wantsPassword,
      role: account.role,
    });
  }),
);

const DELETE = withWideEvent(
  withAuth(async ({ params, userId }) => {
    if (!(await isAdmin(userId))) {
      return forbidden();
    }

    const targetId = params.id;
    if (!targetId) {
      return ErrorResponse.badRequest("User id is required").toResponse();
    }
    if (targetId === userId) {
      return ErrorResponse.badRequest("You cannot delete your own account.").toResponse();
    }
    if (!(await otherAdminExists(targetId))) {
      return ErrorResponse.badRequest("This is the only administrator.").toResponse();
    }

    // Calendars, accounts and sessions cascade from the user row, so deleting an account
    // also removes the calendar data it owned.
    const deleted = await database
      .delete(userTable)
      .where(eq(userTable.id, targetId))
      .returning({ id: userTable.id });

    if (deleted.length === 0) {
      return ErrorResponse.notFound("User not found").toResponse();
    }

    return Response.json({ deleted: targetId });
  }),
);

export { PATCH, DELETE };
