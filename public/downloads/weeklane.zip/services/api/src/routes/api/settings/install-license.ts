import { user as userTable } from "@syncforge/database/auth-schema";
import { appSettingsTable, INSTALL_LICENSE_SETTING } from "@syncforge/database/schema";
import { eq } from "drizzle-orm";
import { database } from "@/context";
import { withAuth, withWideEvent } from "@/utils/middleware";
import { ErrorResponse } from "@/utils/responses";

export type InstallLicense = {
  buyerName: string;
  buyerEmail: string;
  company: string;
  purchaseRef: string;
  plan: "Solo" | "Team";
  installedAt: string;
};

const isAdmin = async (userId: string): Promise<boolean> => {
  const [account] = await database
    .select({ role: userTable.role })
    .from(userTable)
    .where(eq(userTable.id, userId))
    .limit(1);
  return account?.role === "admin";
};

const parseLicense = (raw: string | undefined): InstallLicense | null => {
  if (!raw) {
    return null;
  }
  try {
    const value = JSON.parse(raw) as Partial<InstallLicense>;
    if (
      typeof value.buyerName !== "string"
      || typeof value.buyerEmail !== "string"
      || typeof value.purchaseRef !== "string"
      || (value.plan !== "Solo" && value.plan !== "Team")
      || typeof value.installedAt !== "string"
    ) {
      return null;
    }
    return {
      buyerEmail: value.buyerEmail,
      buyerName: value.buyerName,
      company: typeof value.company === "string" ? value.company : "",
      installedAt: value.installedAt,
      plan: value.plan,
      purchaseRef: value.purchaseRef,
    };
  } catch {
    return null;
  }
};

const readLicense = async (): Promise<InstallLicense | null> => {
  const [row] = await database
    .select({ value: appSettingsTable.value })
    .from(appSettingsTable)
    .where(eq(appSettingsTable.key, INSTALL_LICENSE_SETTING))
    .limit(1);
  return parseLicense(row?.value);
};

const GET = withWideEvent(
  withAuth(async ({ userId }) => {
    if (!(await isAdmin(userId))) {
      return ErrorResponse.forbidden("Only an administrator can read the license.")
        .toResponse();
    }
    return Response.json({ license: await readLicense() });
  }),
);

const PUT = withWideEvent(
  withAuth(async ({ request, userId }) => {
    if (!(await isAdmin(userId))) {
      return ErrorResponse.forbidden("Only an administrator can save the license.")
        .toResponse();
    }

    const body = (await request.json().catch(() => null)) as Partial<InstallLicense> | null;
    const buyerName = String(body?.buyerName || "").trim();
    const buyerEmail = String(body?.buyerEmail || "").trim().toLowerCase();
    const company = String(body?.company || "").trim();
    const purchaseRef = String(body?.purchaseRef || "").trim() || "manual";
    const plan = body?.plan === "Team" ? "Team" : body?.plan === "Solo" ? "Solo" : null;

    if (!buyerName || !buyerEmail || !plan) {
      return ErrorResponse.badRequest(
        "buyerName, buyerEmail, and plan (Solo|Team) are required.",
      ).toResponse();
    }

    const existing = await readLicense();
    const license: InstallLicense = {
      buyerEmail,
      buyerName,
      company,
      installedAt: existing?.installedAt || new Date().toISOString(),
      plan,
      purchaseRef,
    };

    const value = JSON.stringify(license);
    await database
      .insert(appSettingsTable)
      .values({ key: INSTALL_LICENSE_SETTING, value })
      .onConflictDoUpdate({
        set: { updatedAt: new Date(), value },
        target: appSettingsTable.key,
      });

    return Response.json({ license });
  }),
);

export { GET, PUT, readLicense };
