import { convertIcsCalendar, generateIcsCalendar, generateIcsEvent } from "ts-ics";
import type { IcsCalendar, IcsEvent } from "ts-ics";
import ICAL from "ical.js";
import { HTTP_STATUS, SyncForge_USER_EVENT_SUFFIX } from "@syncforge/constants";
import { decryptPassword } from "@syncforge/database";
import { createSafeFetch } from "@syncforge/calendar/safe-fetch";
import { materializeRecurrenceEvents } from "@syncforge/calendar";
import type { SyncableEvent } from "@syncforge/calendar";
import { createDigestAwareFetch, resolveAuthMethod } from "@syncforge/calendar/digest-fetch";
import { buildZonedIcsDate, parseIcsEvents } from "@syncforge/calendar/ics";
import { createDAVClient } from "tsdav";
import { safeFetchOptions } from "@/utils/safe-fetch-options";
import type { EventInput, EventUpdateInput, EventActionResult, RsvpStatus } from "@/types";
import { resolveRepresentableIsoRange } from "./representable-range";

interface CalDAVCredentials {
  serverUrl: string;
  calendarUrl: string;
  username: string;
  encryptedPassword: string;
  encryptionKey: string;
  authMethod: string;
}

const getClient = (credentials: CalDAVCredentials) => {
  const password = decryptPassword(credentials.encryptedPassword, credentials.encryptionKey);
  const safeFetch = createSafeFetch(safeFetchOptions);
  const knownAuthMethod = resolveAuthMethod(credentials.authMethod);
  const { fetch: digestAwareFetch } = createDigestAwareFetch({
    credentials: { username: credentials.username, password },
    baseFetch: safeFetch,
    knownAuthMethod,
  });
  return createDAVClient({
    authMethod: "Custom",
    authFunction: () => Promise.resolve({}),
    credentials: { username: credentials.username, password },
    defaultAccountType: "caldav",
    // See the note in packages/calendar caldav client: tsdav only calls this, but
    // Bun's globals widen `typeof fetch` with statics a wrapper cannot carry.
    fetch: digestAwareFetch as typeof fetch,
    serverUrl: credentials.serverUrl,
  });
};

const generateUid = (): string => `${crypto.randomUUID()}${SyncForge_USER_EVENT_SUFFIX}`;

const ensureTrailingSlash = (url: string): string => {
  if (url.endsWith("/")) {
    return url;
  }
  return `${url}/`;
};

const resolveIsAllDay = (input: { isAllDay?: boolean }): boolean => {
  if (input.isAllDay === true) {
    return true;
  }
  return false;
};

const buildIcsEvent = (uid: string, input: EventInput): IcsEvent => {
  const isAllDay = resolveIsAllDay(input);
  const { endTime, startTime } = resolveRepresentableIsoRange({
    endTime: input.endTime,
    isAllDay,
    startTime: input.startTime,
  });

  const event: IcsEvent = {
    uid,
    summary: input.title,
    description: input.description,
    location: input.location,
    start: buildZonedIcsDate(new Date(startTime), input.startTimeZone, isAllDay),
    end: buildZonedIcsDate(new Date(endTime), input.startTimeZone, isAllDay),
    stamp: { date: new Date() },
  };

  if (input.availability === "free") {
    event.timeTransparent = "TRANSPARENT";
  }

  return event;
};

const buildIcsCalendar = (events: IcsEvent[]): IcsCalendar => ({
  events,
  prodId: "-//SyncForge//SyncForge Calendar//EN",
  version: "2.0",
});

interface CalDAVEventResult {
  sourceEventUid: string;
}

const extractErrorMessage = (error: unknown, fallback: string): string => {
  if (error instanceof Error) {
    return error.message;
  }
  return fallback;
};

const createCalDAVEvent = async (
  credentials: CalDAVCredentials,
  input: EventInput,
): Promise<EventActionResult & Partial<CalDAVEventResult>> => {
  try {
    const client = await getClient(credentials);
    const uid = generateUid();
    const event = buildIcsEvent(uid, input);
    const icsString = generateIcsCalendar(buildIcsCalendar([event]));

    await client.createCalendarObject({
      calendar: { url: credentials.calendarUrl },
      filename: `${uid}.ics`,
      iCalString: icsString,
    });

    return { success: true, sourceEventUid: uid };
  } catch (error) {
    return { success: false, error: extractErrorMessage(error, "CalDAV create failed.") };
  }
};

const fetchCalendarObject = async (
  client: Awaited<ReturnType<typeof createDAVClient>>,
  calendarUrl: string,
  sourceEventUid: string,
): Promise<{ url: string; data: string } | null> => {
  const objectUrl = `${ensureTrailingSlash(calendarUrl)}${sourceEventUid}.ics`;

  try {
    const objects = await client.fetchCalendarObjects({
      calendar: { url: calendarUrl },
      objectUrls: [objectUrl],
    });

    const [object] = objects;
    if (object?.data) {
      return { url: object.url, data: object.data };
    }
  } catch {
    // Object may not exist at that URL
  }

  return null;
};

// eslint-disable-next-line no-undefined -- convertIcsCalendar requires undefined as first arg for no schema
const parseIcsString = (icsString: string): IcsCalendar => convertIcsCalendar(undefined, icsString);

const resolveEventIsAllDay = (updates: EventUpdateInput, event: IcsEvent): boolean => {
  if (updates.isAllDay === true || updates.isAllDay === false) {
    return updates.isAllDay;
  }
  return event.start?.type === "DATE";
};

const resolveTransparency = (availability: string): "TRANSPARENT" | "OPAQUE" => {
  if (availability === "free") {
    return "TRANSPARENT";
  }
  return "OPAQUE";
};

const applyUpdatesToEvent = (event: IcsEvent, updates: EventUpdateInput): IcsEvent => {
  const updated = { ...event };

  // Preserve the event's existing timezone unless the update overrides it.
  const timezone = updates.startTimeZone ?? event.start?.local?.timezone;

  if ("title" in updates && typeof updates.title === "string") {
    updated.summary = updates.title;
  }
  if ("description" in updates) {
    updated.description = updates.description;
  }
  if ("location" in updates) {
    updated.location = updates.location;
  }
  const isAllDay = resolveEventIsAllDay(updates, event);
  if (typeof updates.startTime === "string" && typeof updates.endTime === "string") {
    const range = resolveRepresentableIsoRange({
      endTime: updates.endTime,
      isAllDay,
      startTime: updates.startTime,
    });
    updated.start = buildZonedIcsDate(new Date(range.startTime), timezone, isAllDay);
    updated.end = buildZonedIcsDate(new Date(range.endTime), timezone, isAllDay);
  } else if (typeof updates.startTime === "string") {
    updated.start = buildZonedIcsDate(new Date(updates.startTime), timezone, isAllDay);
  } else if (typeof updates.endTime === "string") {
    updated.end = buildZonedIcsDate(new Date(updates.endTime), timezone, isAllDay);
  }
  if ("availability" in updates && typeof updates.availability === "string") {
    updated.timeTransparent = resolveTransparency(updates.availability);
  }

  updated.stamp = { date: new Date() };

  return updated;
};

const updateCalDAVEvent = async (
  credentials: CalDAVCredentials,
  sourceEventUid: string,
  updates: EventUpdateInput,
): Promise<EventActionResult> => {
  try {
    const client = await getClient(credentials);
    const existing = await fetchCalendarObject(client, credentials.calendarUrl, sourceEventUid);

    if (!existing) {
      return { success: false, error: "Event not found on CalDAV server." };
    }

    const calendar = parseIcsString(existing.data);
    const [event] = calendar.events ?? [];

    if (!event) {
      return { success: false, error: "Could not parse event from CalDAV server." };
    }

    const updatedEvent = applyUpdatesToEvent(event, updates);
    const updatedCalendar = buildIcsCalendar([updatedEvent]);
    const icsString = generateIcsCalendar(updatedCalendar);

    await client.updateCalendarObject({
      calendarObject: {
        url: existing.url,
        data: icsString,
      },
    });

    return { success: true };
  } catch (error) {
    return { success: false, error: extractErrorMessage(error, "CalDAV update failed.") };
  }
};

const deleteCalDAVEvent = async (
  credentials: CalDAVCredentials,
  sourceEventUid: string,
): Promise<EventActionResult> => {
  try {
    const client = await getClient(credentials);
    const objectUrl = `${ensureTrailingSlash(credentials.calendarUrl)}${sourceEventUid}.ics`;

    try {
      await client.deleteCalendarObject({
        calendarObject: { url: objectUrl },
      });
    } catch (error) {
      if (error instanceof Error && "status" in error) {
        const { status } = error;
        if (status !== HTTP_STATUS.NOT_FOUND) {
          throw error;
        }
      }

      throw error;
    }

    return { success: true };
  } catch (error) {
    return { success: false, error: extractErrorMessage(error, "CalDAV delete failed.") };
  }
};

const PARTSTAT_MAP: Record<RsvpStatus, "ACCEPTED" | "DECLINED" | "TENTATIVE"> = {
  accepted: "ACCEPTED",
  declined: "DECLINED",
  tentative: "TENTATIVE",
};

const updateRsvpAttendee = (
  event: IcsEvent,
  partstat: "ACCEPTED" | "DECLINED" | "TENTATIVE",
  userEmail: string,
): IcsEvent => {
  const normalizedEmail = userEmail.toLowerCase();
  const attendees = event.attendees ?? [];
  let foundAttendee = false;
  const updatedAttendees = attendees.map((attendee) => {
    if (attendee.email.toLowerCase() === normalizedEmail) {
      foundAttendee = true;
      return { ...attendee, partstat };
    }
    return attendee;
  });
  if (!foundAttendee) {
    updatedAttendees.push({ email: userEmail, partstat });
  }
  return { ...event, attendees: updatedAttendees, stamp: { date: new Date() } };
};

type IcalComponent = ReturnType<typeof ICAL.Component.fromString>;

const findIcalEventComponent = (
  calendar: IcalComponent,
  selectedEvent: IcsEvent,
): IcalComponent | undefined => calendar.getAllSubcomponents("vevent").find((component) => {
  const event = new ICAL.Event(component);
  if (event.uid !== selectedEvent.uid) {
    return false;
  }
  if (!selectedEvent.recurrenceId) {
    return !event.isRecurrenceException();
  }
  if (!event.isRecurrenceException()) {
    return false;
  }
  const selectedRecurrence = selectedEvent.recurrenceId.value;
  if (event.recurrenceId.isDate || selectedRecurrence.type === "DATE") {
    return event.recurrenceId.isDate
      && selectedRecurrence.type === "DATE"
      && event.recurrenceId.year === selectedRecurrence.date.getUTCFullYear()
      && event.recurrenceId.month === selectedRecurrence.date.getUTCMonth() + 1
      && event.recurrenceId.day === selectedRecurrence.date.getUTCDate();
  }
  return event.recurrenceId.toUnixTime() * 1000 === selectedRecurrence.date.getTime();
});

const updateIcalRsvpAttendee = (
  event: IcalComponent,
  partstat: "ACCEPTED" | "DECLINED" | "TENTATIVE",
  userEmail: string,
): void => {
  const normalizedEmail = userEmail.toLowerCase();
  const attendee = event.getAllProperties("attendee").find((candidate) => {
    const value = candidate.getFirstValue();
    return String(value).replace(/^mailto:/iu, "").toLowerCase() === normalizedEmail;
  });
  if (attendee) {
    attendee.setParameter("partstat", partstat);
  } else {
    const addedAttendee = event.addPropertyWithValue("attendee", `mailto:${userEmail}`);
    addedAttendee.setParameter("partstat", partstat);
  }
  event.updatePropertyWithValue("dtstamp", ICAL.Time.fromJSDate(new Date(), true));
};

const createRsvpOccurrenceOverride = (
  calendar: IcsCalendar,
  master: IcsEvent,
  occurrenceStart: Date,
  partstat: "ACCEPTED" | "DECLINED" | "TENTATIVE",
  userEmail: string,
): IcsEvent | null => {
  const parsedMaster = parseIcsEvents(calendar, { includeSyncForgeEvents: true }).find(
    (event) => event.uid === master.uid && event.recurrenceRule && !event.recurrenceId,
  );
  if (!parsedMaster?.recurrenceRule) {
    return null;
  }
  const materializationInput: SyncableEvent = {
    availability: parsedMaster.availability,
    calendarId: "caldav-rsvp",
    calendarName: "CalDAV RSVP",
    calendarUrl: null,
    description: parsedMaster.description,
    endTime: parsedMaster.endTime,
    exceptionDates: parsedMaster.exceptionDates?.map((date) => date.date),
    id: "caldav-rsvp-master",
    isAllDay: parsedMaster.isAllDay,
    location: parsedMaster.location,
    recurrenceDuration: parsedMaster.recurrenceDuration,
    recurrenceRule: parsedMaster.recurrenceRule,
    sourceEventUid: parsedMaster.uid,
    startTime: parsedMaster.startTime,
    startTimeZone: parsedMaster.startTimeZone,
    summary: parsedMaster.title ?? "",
  };
  const [occurrence] = materializeRecurrenceEvents([materializationInput], {
    start: occurrenceStart,
    end: new Date(occurrenceStart.getTime() + 1),
  });
  if (!occurrence || occurrence.startTime.getTime() !== occurrenceStart.getTime()) {
    return null;
  }
  const {
    duration: _duration,
    end: _end,
    exceptionDates: _exceptionDates,
    recurrenceId: _recurrenceId,
    recurrenceRule: _recurrenceRule,
    ...eventBase
  } = master;
  const isAllDay = parsedMaster.isAllDay ?? false;
  return updateRsvpAttendee({
    ...eventBase,
    end: buildZonedIcsDate(occurrence.endTime, parsedMaster.startTimeZone, isAllDay),
    recurrenceId: {
      value: buildZonedIcsDate(occurrenceStart, parsedMaster.startTimeZone, isAllDay),
    },
    start: buildZonedIcsDate(occurrence.startTime, parsedMaster.startTimeZone, isAllDay),
  }, partstat, userEmail);
};

const rsvpCalDAVEvent = async (
  credentials: CalDAVCredentials,
  sourceEventUid: string,
  occurrenceStart: Date | null,
  status: RsvpStatus,
  userEmail: string,
): Promise<EventActionResult> => {
  try {
    const client = await getClient(credentials);
    const existing = await fetchCalendarObject(client, credentials.calendarUrl, sourceEventUid);

    if (!existing) {
      return { success: false, error: "Event not found on CalDAV server." };
    }

    const calendar = parseIcsString(existing.data);
    const icalCalendar = ICAL.Component.fromString(existing.data);
    const events = calendar.events ?? [];
    const master = events.find(
      (event) => event.uid === sourceEventUid && !event.recurrenceId,
    );
    const existingOverride = occurrenceStart && events.find(
      (event) => event.uid === sourceEventUid
        && event.recurrenceId?.value.date.getTime() === occurrenceStart.getTime(),
    );
    const event = existingOverride ?? master;
    if (!event) {
      return { success: false, error: "Could not parse event from CalDAV server." };
    }
    const icalEvent = findIcalEventComponent(icalCalendar, event);
    if (!icalEvent) {
      return { success: false, error: "Could not parse event from CalDAV server." };
    }

    const partstat = PARTSTAT_MAP[status];
    if (occurrenceStart && !existingOverride) {
      const generatedOverride = createRsvpOccurrenceOverride(
        calendar,
        event,
        occurrenceStart,
        partstat,
        userEmail,
      );
      if (!generatedOverride) {
        return { success: false, error: "Recurring occurrence not found on CalDAV server." };
      }
      icalCalendar.addSubcomponent(ICAL.Component.fromString(generateIcsEvent(generatedOverride)));
    } else {
      updateIcalRsvpAttendee(icalEvent, partstat, userEmail);
    }
    const icsString = icalCalendar.toString();

    await client.updateCalendarObject({
      calendarObject: {
        url: existing.url,
        data: icsString,
      },
    });

    return { success: true };
  } catch (error) {
    return { success: false, error: extractErrorMessage(error, "CalDAV RSVP failed.") };
  }
};

const getPendingCalDAVInvites = async (
  credentials: CalDAVCredentials,
  from: string,
  to: string,
  userEmail: string,
): Promise<{
  sourceEventUid: string;
  title: string | null;
  description: string | null;
  location: string | null;
  startTime: string;
  endTime: string;
  isAllDay: boolean;
  organizer: string | null;
}[]> => {
  try {
    const client = await getClient(credentials);
    const objects = await client.fetchCalendarObjects({
      calendar: { url: credentials.calendarUrl },
      timeRange: { start: from, end: to },
    });

    const pendingEvents: {
      sourceEventUid: string;
      title: string | null;
      description: string | null;
      location: string | null;
      startTime: string;
      endTime: string;
      isAllDay: boolean;
      organizer: string | null;
    }[] = [];

    const normalizedEmail = userEmail.toLowerCase();

    for (const object of objects) {
      if (!object.data) {
        continue;
      }

      const calendar = parseIcsString(object.data);
      const [event] = calendar.events ?? [];

      if (!event) {
        continue;
      }

      const attendees = event.attendees ?? [];
      const userAttendee = attendees.find(
        (attendee) => attendee.email.toLowerCase() === normalizedEmail,
      );

      if (!userAttendee) {
        continue;
      }

      if (userAttendee.partstat !== "NEEDS-ACTION") {
        continue;
      }

      const isAllDay = event.start?.type === "DATE";
      const organizerEmail = event.organizer?.email ?? null;
      const endTime = event.end?.date?.toISOString() ?? event.start.date.toISOString();

      pendingEvents.push({
        sourceEventUid: event.uid,
        title: event.summary ?? null,
        description: event.description ?? null,
        location: event.location ?? null,
        startTime: event.start.date.toISOString(),
        endTime,
        isAllDay,
        organizer: organizerEmail,
      });
    }

    return pendingEvents;
  } catch {
    return [];
  }
};

export { createCalDAVEvent, updateCalDAVEvent, deleteCalDAVEvent, rsvpCalDAVEvent, getPendingCalDAVInvites };
