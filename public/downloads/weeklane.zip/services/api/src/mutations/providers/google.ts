import { HTTP_STATUS } from "@syncforge/constants";
import {
  googleApiErrorSchema,
  googleEventSchema,
  googleEventWithAttendeesListSchema,
  googleEventWithAttendeesSchema,
} from "@syncforge/data-schemas";
import type { GoogleAttendee, GoogleEvent, GoogleEventWithAttendees } from "@syncforge/data-schemas";
import type {
  EventActionResult,
  EventInput,
  EventUpdateInput,
  ProviderEventReference,
  RsvpStatus,
} from "@/types";
import { resolveRepresentableIsoRange } from "./representable-range";

const GOOGLE_CALENDAR_API = "https://www.googleapis.com/calendar/v3/";

const buildHeaders = (accessToken: string): Record<string, string> => ({
  "Authorization": `Bearer ${accessToken}`,
  "Content-Type": "application/json",
});

const getCalendarId = (externalCalendarId: string | null): string =>
  externalCalendarId ?? "primary";

const handleErrorResponse = async (response: Response): Promise<string> => {
  const body = await response.json();
  const { error } = googleApiErrorSchema.assert(body);
  return error?.message ?? response.statusText;
};

interface GoogleEventResult {
  sourceEventUid: string;
}

const buildGoogleDateField = (
  dateTime: string,
  isAllDay: boolean,
): { date: string } | { dateTime: string } => {
  if (isAllDay) {
    const instant = new Date(dateTime);
    if (Number.isNaN(instant.getTime())) {
      throw new TypeError(`All-day event time is not an instant: ${dateTime}`);
    }
    return { date: instant.toISOString().slice(0, 10) };
  }

  return { dateTime };
};

const createGoogleEvent = async (
  accessToken: string,
  externalCalendarId: string | null,
  input: EventInput,
): Promise<EventActionResult & Partial<GoogleEventResult>> => {
  const calendarId = getCalendarId(externalCalendarId);
  const url = new URL(`calendars/${encodeURIComponent(calendarId)}/events`, GOOGLE_CALENDAR_API);

  const isAllDay = input.isAllDay ?? false;
  const resource: GoogleEvent = {
    summary: input.title,
    description: input.description,
    location: input.location,
  };

  const { endTime, startTime } = resolveRepresentableIsoRange({
    endTime: input.endTime,
    isAllDay,
    startTime: input.startTime,
  });

  resource.start = buildGoogleDateField(startTime, isAllDay);
  resource.end = buildGoogleDateField(endTime, isAllDay);

  if (input.availability === "free") {
    resource.transparency = "transparent";
  }

  const response = await fetch(url, {
    body: JSON.stringify(resource),
    headers: buildHeaders(accessToken),
    method: "POST",
  });

  if (!response.ok) {
    const errorMessage = await handleErrorResponse(response);
    return { success: false, error: errorMessage };
  }

  const created = googleEventSchema.assert(await response.json());
  return { success: true, sourceEventUid: created.iCalUID };
};

const findGoogleEventByUid = async (
  accessToken: string,
  externalCalendarId: string | null,
  sourceEventUid: string,
): Promise<GoogleEventWithAttendees | null> => {
  const calendarId = getCalendarId(externalCalendarId);
  const url = new URL(`calendars/${encodeURIComponent(calendarId)}/events`, GOOGLE_CALENDAR_API);
  url.searchParams.set("iCalUID", sourceEventUid);

  const response = await fetch(url, {
    headers: buildHeaders(accessToken),
    method: "GET",
  });

  if (!response.ok) {
    return null;
  }

  const body = googleEventWithAttendeesListSchema.assert(await response.json());
  const [item] = body.items ?? [];
  return item ?? null;
};

const findGoogleEventById = async (
  accessToken: string,
  externalCalendarId: string | null,
  sourceEventId: string,
): Promise<GoogleEventWithAttendees | null> => {
  const calendarId = getCalendarId(externalCalendarId);
  const url = new URL(
    `calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(sourceEventId)}`,
    GOOGLE_CALENDAR_API,
  );
  const response = await fetch(url, {
    headers: buildHeaders(accessToken),
    method: "GET",
  });

  if (!response.ok) {
    return null;
  }

  return googleEventWithAttendeesSchema.assert(await response.json());
};

const resolveGoogleEvent = (
  accessToken: string,
  externalCalendarId: string | null,
  reference: ProviderEventReference,
): Promise<GoogleEventWithAttendees | null> => {
  if (reference.sourceEventId) {
    return findGoogleEventById(
      accessToken,
      externalCalendarId,
      reference.sourceEventId,
    );
  }
  return findGoogleEventByUid(
    accessToken,
    externalCalendarId,
    reference.sourceEventUid,
  );
};

const resolveGoogleTransparency = (availability: string): string => {
  if (availability === "free") {
    return "transparent";
  }

  return "opaque";
};

const updateGoogleEvent = async (
  accessToken: string,
  externalCalendarId: string | null,
  sourceEventUid: string,
  updates: EventUpdateInput,
): Promise<EventActionResult> => {
  const existing = await findGoogleEventByUid(accessToken, externalCalendarId, sourceEventUid);

  if (!existing?.id) {
    return { success: false, error: "Event not found on Google Calendar." };
  }

  const calendarId = getCalendarId(externalCalendarId);
  const url = new URL(
    `calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(existing.id)}`,
    GOOGLE_CALENDAR_API,
  );

  const patch: Record<string, unknown> = {};
  if ("title" in updates) {
    patch.summary = updates.title;
  }
  if ("description" in updates) {
    patch.description = updates.description;
  }
  if ("location" in updates) {
    patch.location = updates.location;
  }

  const hasExistingDateStart = existing.start && "date" in existing.start;
  const isAllDay = updates.isAllDay ?? (hasExistingDateStart === true);
  if (updates.startTime && updates.endTime) {
    const { endTime, startTime } = resolveRepresentableIsoRange({
      endTime: updates.endTime,
      isAllDay,
      startTime: updates.startTime,
    });
    patch.start = buildGoogleDateField(startTime, isAllDay);
    patch.end = buildGoogleDateField(endTime, isAllDay);
  } else if (updates.startTime) {
    patch.start = buildGoogleDateField(updates.startTime, isAllDay);
  } else if (updates.endTime) {
    patch.end = buildGoogleDateField(updates.endTime, isAllDay);
  }
  if ("availability" in updates && updates.availability) {
    patch.transparency = resolveGoogleTransparency(updates.availability);
  }

  const response = await fetch(url, {
    body: JSON.stringify(patch),
    headers: buildHeaders(accessToken),
    method: "PATCH",
  });

  if (!response.ok) {
    const errorMessage = await handleErrorResponse(response);
    return { success: false, error: errorMessage };
  }

  await response.json();
  return { success: true };
};

const deleteGoogleEvent = async (
  accessToken: string,
  externalCalendarId: string | null,
  sourceEventUid: string,
): Promise<EventActionResult> => {
  const existing = await findGoogleEventByUid(accessToken, externalCalendarId, sourceEventUid);

  if (!existing?.id) {
    return { success: true };
  }

  const calendarId = getCalendarId(externalCalendarId);
  const url = new URL(
    `calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(existing.id)}`,
    GOOGLE_CALENDAR_API,
  );

  const response = await fetch(url, {
    headers: buildHeaders(accessToken),
    method: "DELETE",
  });

  if (!response.ok && response.status !== HTTP_STATUS.NOT_FOUND) {
    const errorMessage = await handleErrorResponse(response);
    return { success: false, error: errorMessage };
  }

  await response.body?.cancel?.();
  return { success: true };
};

const rsvpGoogleEvent = async (
  accessToken: string,
  externalCalendarId: string | null,
  reference: ProviderEventReference,
  status: RsvpStatus,
  userEmail: string,
): Promise<EventActionResult> => {
  const existing = await resolveGoogleEvent(accessToken, externalCalendarId, reference);

  if (!existing?.id) {
    return { success: false, error: "Event not found on Google Calendar." };
  }

  const calendarId = getCalendarId(externalCalendarId);
  const url = new URL(
    `calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(existing.id)}`,
    GOOGLE_CALENDAR_API,
  );

  const attendees = existing.attendees ?? [];
  const normalizedEmail = userEmail.toLowerCase();

  const isMatchingAttendee = (attendee: GoogleAttendee): boolean => {
    const attendeeEmail = (attendee.email ?? "").toLowerCase();
    return attendeeEmail === normalizedEmail || attendee.self === true;
  };

  const hasMatch = attendees.some((attendee) => isMatchingAttendee(attendee));

  const updatedAttendees = attendees.map((attendee) => {
    if (isMatchingAttendee(attendee)) {
      return { ...attendee, responseStatus: status };
    }
    return attendee;
  });

  if (!hasMatch) {
    updatedAttendees.push({
      email: userEmail,
      responseStatus: status,
      self: true,
    });
  }

  const response = await fetch(url, {
    body: JSON.stringify({ attendees: updatedAttendees }),
    headers: buildHeaders(accessToken),
    method: "PATCH",
  });

  if (!response.ok) {
    const errorMessage = await handleErrorResponse(response);
    return { success: false, error: errorMessage };
  }

  await response.json();
  return { success: true };
};

interface PendingGoogleEvent {
  sourceEventUid: string;
  title: string | null;
  description: string | null;
  location: string | null;
  startTime: string;
  endTime: string;
  isAllDay: boolean;
  organizer: string | null;
}

const parseGooglePendingEvent = (event: GoogleEventWithAttendees): PendingGoogleEvent | null => {
  const selfAttendee = (event.attendees ?? []).find(
    (attendee) => attendee.self === true,
  );

  if (!selfAttendee) {
    return null;
  }

  if (selfAttendee.responseStatus !== "needsAction") {
    return null;
  }

  if (!event.iCalUID) {
    return null;
  }

  const startTime = event.start?.dateTime ?? event.start?.date;
  const endTime = event.end?.dateTime ?? event.end?.date;

  if (!startTime || !endTime) {
    return null;
  }

  const isAllDay = Boolean(event.start && "date" in event.start);

  return {
    sourceEventUid: event.iCalUID,
    title: event.summary ?? null,
    description: event.description ?? null,
    location: event.location ?? null,
    startTime,
    endTime,
    isAllDay,
    organizer: event.organizer?.email ?? null,
  };
};

const fetchGoogleEventsPage = async (
  accessToken: string,
  calendarId: string,
  from: string,
  to: string,
  pageToken: string | null,
): Promise<{ items: GoogleEventWithAttendees[]; nextPageToken: string | null }> => {
  const url = new URL(`calendars/${encodeURIComponent(calendarId)}/events`, GOOGLE_CALENDAR_API);
  url.searchParams.set("timeMin", from);
  url.searchParams.set("timeMax", to);
  url.searchParams.set("singleEvents", "true");
  url.searchParams.set("maxResults", "250");
  if (pageToken) {
    url.searchParams.set("pageToken", pageToken);
  }

  const response = await fetch(url, {
    headers: buildHeaders(accessToken),
    method: "GET",
  });

  if (!response.ok) {
    return { items: [], nextPageToken: null };
  }

  const body = googleEventWithAttendeesListSchema.assert(await response.json());

  return {
    items: body.items ?? [],
    nextPageToken: body.nextPageToken ?? null,
  };
};

const getPendingGoogleInvites = async (
  accessToken: string,
  externalCalendarId: string | null,
  from: string,
  to: string,
): Promise<PendingGoogleEvent[]> => {
  const calendarId = getCalendarId(externalCalendarId);
  const pendingEvents: PendingGoogleEvent[] = [];

  let pageToken: string | null = null;

  do {
    const page = await fetchGoogleEventsPage(accessToken, calendarId, from, to, pageToken);

    for (const event of page.items) {
      const parsed = parseGooglePendingEvent(event);
      if (parsed) {
        pendingEvents.push(parsed);
      }
    }

    pageToken = page.nextPageToken;
  } while (pageToken);

  return pendingEvents;
};

export { createGoogleEvent, updateGoogleEvent, deleteGoogleEvent, rsvpGoogleEvent, getPendingGoogleInvites };
