const HEALTH_URL = "https://localhost/api/health";
const JOB_NAME = "keep-railway-awake";

const text = await Bun.file(new URL("../.env", import.meta.url)).text();
const line = text.split(/\r?\n/).find((row) => row.startsWith("DATABASE_URL="));
if (!line) {
  throw new Error("DATABASE_URL missing");
}

const sql = new Bun.SQL(line.slice("DATABASE_URL=".length).trim());

try {
  await sql.unsafe("create extension if not exists pg_cron");
  await sql.unsafe("create extension if not exists pg_net");
  await sql.unsafe(
    "select cron.unschedule(jobid) from cron.job where jobname in ('keep-sealos-awake', 'keep-railway-awake')",
  );
  await sql.unsafe(
    `select cron.schedule('${JOB_NAME}', '*/5 * * * *', $$select net.http_get(url := '${HEALTH_URL}', timeout_milliseconds := 30000);$$)`,
  );
  await sql.unsafe(
    `select net.http_get(url := '${HEALTH_URL}', timeout_milliseconds := 30000)`,
  );
  await Bun.sleep(12000);
  const jobs = await sql.unsafe(
    `select jobname, schedule, active from cron.job where jobname = '${JOB_NAME}'`,
  );
  const pings = await sql.unsafe(
    "select status_code, error_msg from net._http_response order by id desc limit 3",
  );
  console.log(JSON.stringify({ jobs, pings }));
} finally {
  await sql.close();
}
