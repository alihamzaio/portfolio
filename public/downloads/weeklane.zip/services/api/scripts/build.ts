import { Glob, build } from "bun";

const entrypoints = [
  ...new Glob("src/routes/**/*.ts")
    .scanSync()
    .filter((filePath) => !/\.(test|spec)\.ts$/.test(filePath)),
  ...new Glob("src/scripts/**/*.ts").scanSync(),
  ...new Glob("src/index.ts").scanSync(),
];

await build({
  entrypoints,
  outdir: "./dist",
  root: "src",
  splitting: true,
  target: "bun",
  // Native / worker packages break if bun inlines them into dist.
  // Subpaths must be listed; "pdfjs-dist" alone still bundles legacy/build/*.mjs
  // which then inlines @napi-rs/canvas .node files for the build machine OS.
  external: [
    "msgpackr-extract",
    "pino-opentelemetry-transport",
    "@napi-rs/canvas",
    "pdfjs-dist",
    "pdfjs-dist/legacy/build/pdf.mjs",
    "pdfjs-dist/legacy/build/pdf.worker.min.mjs",
    "tesseract.js",
  ],
});
