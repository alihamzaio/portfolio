#!/bin/sh
set -e

export OTEL_SERVICE_NAME=SyncForge-cron

exec bun services/cron/dist/index.js 2>&1 | syncforge-otelemetry
