import { createRegistrarContextFactory } from "@syncforge/calendar";
import { database, refreshLockRedis, refreshLockStore, webhookConfig } from "@/context";
import env from "@/env";

const createRegistrarContext = createRegistrarContextFactory({
  database,
  googleClientId: env.GOOGLE_CLIENT_ID,
  googleClientSecret: env.GOOGLE_CLIENT_SECRET,
  rateLimiterRedis: refreshLockRedis,
  refreshLockStore,
  webhookConfig,
});

export { createRegistrarContext };
