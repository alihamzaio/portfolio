import type { SafeFetchOptions } from "@syncforge/calendar/safe-fetch";
import { PROVIDER_INGEST_REQUEST_TIMEOUT_MS } from "@syncforge/constants";
import env from "@/env";

const parseSafeFetchOptions = (): SafeFetchOptions => {
  const options: SafeFetchOptions = {
    blockPrivateResolution: env.BLOCK_PRIVATE_RESOLUTION === true,
    timeoutMs: PROVIDER_INGEST_REQUEST_TIMEOUT_MS,
  };

  if (env.PRIVATE_RESOLUTION_WHITELIST) {
    const hosts = env.PRIVATE_RESOLUTION_WHITELIST
      .split(",")
      .map((host) => host.trim())
      .filter((host) => host.length > 0);

    options.allowedPrivateHosts = new Set(hosts);
  }

  return options;
};

const safeFetchOptions = parseSafeFetchOptions();

export { safeFetchOptions };
