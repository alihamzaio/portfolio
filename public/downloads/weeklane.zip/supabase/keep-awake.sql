-- Ping the Railway app every 5 minutes from always-on Supabase.
-- pg_cron + pg_net are free. A GitHub Action every 5 minutes is not: this repo is private
-- and would burn the monthly Actions minutes, then Docker builds would stop.

create extension if not exists pg_cron;
create extension if not exists pg_net;

select cron.unschedule(jobid)
from cron.job
where jobname in ('keep-sealos-awake', 'keep-railway-awake');

select cron.schedule(
  'keep-railway-awake',
  '*/5 * * * *',
  $$select net.http_get(
    url := 'https://localhost/api/health',
    timeout_milliseconds := 30000
  );$$
);
