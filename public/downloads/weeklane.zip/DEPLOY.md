# Install

Weeklane runs on the buyer's own computer or a small private server. It is not hosted for them.

1. Install Docker and Bun.
2. Copy `services/api/.env.template` to `services/api/.env`.
3. Fill `BETTER_AUTH_SECRET` and `ENCRYPTION_KEY` with long random values.
4. Fill the license lines with this sale: `LICENSE_BUYER_NAME`, `LICENSE_BUYER_EMAIL`, and `LICENSE_PURCHASE_REF` (the Gumroad order id). `LICENSE_COMPANY` can stay empty. `LICENSE_PLAN` is `Solo` or `Team`.
5. Start the database:

```bash
docker compose up -d
```

6. Start the API (`services/api`) and the dashboard (`applications/dashboard`). See the README. Dashboard: port 3010. API: port 3020.
7. Sign in with the first administrator from the env file, then change that email and password on Profile.

Health check: `/api/health`.

Google Calendar is optional. The buyer creates their own Google Cloud OAuth app and pastes the client id and secret in Settings. Redirect: `{dashboard address}/api/sources/callback/google`. Outlook is an ICS link on the Calendars page, not a Microsoft login.

A reset is an empty database (delete the Docker volume and start again). The env file creates the administrator and the license again. If either is already stored, a later start leaves it alone.
