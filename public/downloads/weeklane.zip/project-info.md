# Weeklane - Project Overview

Private multi-company schedule aggregator for teams that juggle Google and Outlook calendars.

**Product:** Weeklane (personal edition by Ali Hamza; Scopefirst product family)  
**Problem:** Many company calendars, invisible conflicts, unsafe share links  
**Solution:** One color-coded team board; public page strips join links and descriptions  
**First install:** Docker creates the first administrator. They change email and password on Profile.  

See [README.md](./README.md) for deploy and local run.
