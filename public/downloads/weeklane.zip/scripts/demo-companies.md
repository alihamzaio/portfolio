# Demo companies (portfolio-safe)

Use **only** these fake labels when seeding or screenshotting Weeklane:

| Company | Suggested color |
|---------|-----------------|
| Acme Corp | blue |
| Contoso | green |
| Northwind | amber |

Meeting titles: Standup, Sprint review, Client sync, Office half-day.

Never seed real client, agency, or personal calendar names into this repo or public screenshots.
